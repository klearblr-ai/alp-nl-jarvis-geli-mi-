@echo off
setlocal
cd /d "%~dp0..\.."
echo JARVIS Lite Windows calisiyor...
py -3 --version >nul 2>nul
if %errorlevel%==0 (
    py -3 -m pip install google-genai
    py -3 platform_builds\cross_platform\jarvis_lite.py
) else (
    python -m pip install google-genai
    python platform_builds\cross_platform\jarvis_lite.py
)
pause
