$ErrorActionPreference = "Stop"

$Root = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$Source = Join-Path $Root "platform_builds\cross_platform\jarvis_lite.py"
$Venv = Join-Path $Root ".venv-windows-build"

Write-Host "JARVIS Windows EXE build basliyor..."
Write-Host "Kaynak: $Source"

$Python = "py"
try {
    & py -3 --version | Out-Null
} catch {
    $Python = "python"
}

if ($Python -eq "py") {
    & py -3 -m venv $Venv
} else {
    & python -m venv $Venv
}

$VenvPython = Join-Path $Venv "Scripts\python.exe"
& $VenvPython -m pip install --upgrade pip
& $VenvPython -m pip install google-genai pyinstaller
& $VenvPython -m PyInstaller --noconfirm --onefile --windowed --name "JARVIS-Windows" $Source

Write-Host ""
Write-Host "Bitti. EXE burada:"
Write-Host (Join-Path $Root "dist\JARVIS-Windows.exe")
