JARVIS Windows

Bu klasor Windows icindir.

Hizli calistirma:
1. Windows'ta Python 3 kurulu olsun.
2. run_windows.bat dosyasina cift tikla.

EXE uretme:
1. PowerShell'i ac.
2. Bu komutu calistir:
   Set-ExecutionPolicy -Scope Process Bypass
3. Sonra:
   .\build_windows_exe.ps1
4. Cikan dosya:
   dist\JARVIS-Windows.exe

Not:
- Bu Mac ortaminda Windows .exe dogrudan imzali/yerel uretilemez; EXE Windows uzerinde bu scriptle uretilir.
- Windows surumu JARVIS Lite'tir: metinli AI asistanidir. macOS HomeKit, AppleScript, kamera guvenlik ve Apple izinleri Mac ana surumunde kalir.
