JARVIS Linux

Hizli calistirma:
1. Python 3 ve python3-venv kurulu olsun.
2. Terminalde:
   chmod +x run_linux.sh
   ./run_linux.sh

Linux binary uretme:
1. Terminalde:
   chmod +x build_linux_binary.sh
   ./build_linux_binary.sh
2. Cikan dosya:
   dist/JARVIS-Linux

Not:
- Linux surumu JARVIS Lite'tir: metinli AI asistanidir.
- macOS HomeKit, AppleScript, Mesajlar ve Apple izinleri Linux'ta dogal olarak yoktur.
