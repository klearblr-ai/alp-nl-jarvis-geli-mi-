#!/usr/bin/env python3
from __future__ import annotations

import json
import threading
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

try:
    from google import genai
except Exception:
    genai = None


APP_DIR = Path.home() / ".jarvis_lite"
CONFIG_PATH = APP_DIR / "config.json"
MODEL = "models/gemini-2.0-flash"


def load_config() -> dict:
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_config(config: dict) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")


class JarvisLite:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("JARVIS Lite")
        self.root.geometry("860x620")
        self.root.minsize(620, 440)
        self.config = load_config()
        self.history: list[str] = []
        self._build_ui()

    def _build_ui(self) -> None:
        bg = "#05080d"
        panel = "#08131c"
        text = "#eafcff"
        cyan = "#00f5ff"
        muted = "#91c9d2"
        self.root.configure(bg=bg)

        top = tk.Frame(self.root, bg=bg)
        top.pack(fill="x", padx=14, pady=(14, 8))
        tk.Label(top, text="JARVIS Lite", bg=bg, fg=cyan, font=("Helvetica", 20, "bold")).pack(anchor="w")
        tk.Label(
            top,
            text="Windows, Linux, iPhone/iPad/Android companion mantığı için hafif AI asistanı. API key cihazda kalır.",
            bg=bg,
            fg=muted,
            font=("Helvetica", 10),
        ).pack(anchor="w", pady=(3, 0))

        api_row = tk.Frame(self.root, bg=bg)
        api_row.pack(fill="x", padx=14, pady=(0, 10))
        tk.Label(api_row, text="Gemini API Key", bg=bg, fg=muted).pack(side="left")
        self.api_entry = tk.Entry(api_row, show="*", bg=panel, fg=text, insertbackground=text, relief="flat")
        self.api_entry.pack(side="left", fill="x", expand=True, padx=10, ipady=7)
        self.api_entry.insert(0, str(self.config.get("gemini_api_key", "") or ""))
        tk.Button(api_row, text="Kaydet", command=self._save_key, bg="#0b6f7f", fg="white", relief="flat", padx=14).pack(side="left")

        self.log = tk.Text(self.root, bg=panel, fg=text, insertbackground=text, relief="flat", wrap="word")
        self.log.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        self.log.insert("end", "JARVIS hazır. Mesaj yazıp Enter'a bas.\n\n")
        self.log.configure(state="disabled")

        bottom = tk.Frame(self.root, bg=bg)
        bottom.pack(fill="x", padx=14, pady=(0, 14))
        self.prompt_entry = tk.Entry(bottom, bg=panel, fg=text, insertbackground=text, relief="flat")
        self.prompt_entry.pack(side="left", fill="x", expand=True, ipady=10)
        self.prompt_entry.bind("<Return>", lambda _event: self.send())
        tk.Button(bottom, text="Gönder", command=self.send, bg="#0b6f7f", fg="white", relief="flat", padx=16, pady=8).pack(side="left", padx=(10, 0))
        tk.Button(bottom, text="Temizle", command=self.clear, bg="#17232e", fg="white", relief="flat", padx=16, pady=8).pack(side="left", padx=(8, 0))

    def _save_key(self) -> None:
        self.config["gemini_api_key"] = self.api_entry.get().strip()
        save_config(self.config)
        self.append("SYS", "API key kaydedildi.")

    def append(self, who: str, message: str) -> None:
        def do_append() -> None:
            self.log.configure(state="normal")
            self.log.insert("end", f"{who}: {message}\n\n")
            self.log.see("end")
            self.log.configure(state="disabled")
        self.root.after(0, do_append)

    def clear(self) -> None:
        self.history.clear()
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.insert("end", "JARVIS hazır. Mesaj yazıp Enter'a bas.\n\n")
        self.log.configure(state="disabled")

    def send(self) -> None:
        prompt = self.prompt_entry.get().strip()
        if not prompt:
            return
        self.prompt_entry.delete(0, "end")
        self.append("Sen", prompt)
        threading.Thread(target=self._ask_model, args=(prompt,), daemon=True).start()

    def _ask_model(self, prompt: str) -> None:
        api_key = self.api_entry.get().strip()
        if not api_key:
            self.append("SYS", "Önce Gemini API key girip Kaydet'e bas.")
            return
        if genai is None:
            self.append("SYS", "google-genai paketi yok. Kurulum scriptini çalıştır veya pip install google-genai yap.")
            return
        try:
            self.history.append(f"Kullanıcı: {prompt}")
            context = "\n".join(self.history[-10:])
            system_prompt = (
                "Sen JARVIS Lite'sın. Türkçe konuş, kısa ve net yanıt ver. "
                "Bu sürüm Windows/Linux/mobil companion için hafif metin asistanıdır; "
                "macOS HomeKit/kamera/Apple izinleri sadece Mac ana sürümünde vardır.\n\n"
            )
            client = genai.Client(api_key=api_key)
            response = client.models.generate_content(
                model=MODEL,
                contents=system_prompt + context,
            )
            answer = str(getattr(response, "text", "") or "").strip() or "Boş cevap geldi."
            self.history.append(f"JARVIS: {answer}")
            self.append("JARVIS", answer)
        except Exception as exc:
            self.append("SYS", f"Hata: {exc}")


def main() -> None:
    root = tk.Tk()
    try:
        JarvisLite(root)
        root.mainloop()
    except Exception as exc:
        messagebox.showerror("JARVIS Lite", str(exc))


if __name__ == "__main__":
    main()
