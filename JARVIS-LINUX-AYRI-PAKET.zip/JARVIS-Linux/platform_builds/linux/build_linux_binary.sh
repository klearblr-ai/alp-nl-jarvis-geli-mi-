#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."

python3 -m venv .venv-linux-build
source .venv-linux-build/bin/activate
python -m pip install --upgrade pip
python -m pip install google-genai pyinstaller
python -m PyInstaller --noconfirm --onefile --windowed --name JARVIS-Linux platform_builds/cross_platform/jarvis_lite.py

echo
echo "Bitti. Linux binary:"
echo "$(pwd)/dist/JARVIS-Linux"
