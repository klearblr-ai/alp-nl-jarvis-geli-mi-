JARVIS iPhone + iPad + Watch Native Companion

Bu klasor HTML degildir; SwiftUI native app kaynak iskeletidir.

Ne yapar?
- Ayni Gemini API key ile Mac JARVIS esleme kodu uretir.
- iPhone, iPad ve Watch icin tek SwiftUI arayuz mantigi verir.
- Sesli komut, cihaz transferi ve Mac'e komut gonderme icin temel siniflari icerir.

Kurulum:
1. Xcode'da yeni iOS App projesi olustur.
2. Destination/Supported Destinations icinde iPhone ve iPad acik kalsin.
3. Watch App target ekle.
3. Sources klasorundeki Swift dosyalarini iOS target'a ekle.
4. WatchSources klasorundeki Swift dosyalarini Watch target'a ekle.
5. Bundle ID ve Apple Developer imzani sec.
6. API key'i app icinde kullanici girisinden kaydet; koda gomulu anahtar koyma.

Not:
- iPhone/iPad/Watch .app veya .ipa dosyasini burada imzasiz uretemem; Apple imzasi ve Xcode build gerekir.
- Kisiler, Foto, Konum, Mikrofon gibi izinler iOS/watchOS tarafinda kullanici onayina baglidir.
- iPad icin ayrica HTML/WebView degil, ayni SwiftUI native kod buyuk ekrana uyarlanir.
