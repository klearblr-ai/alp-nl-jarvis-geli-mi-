import SwiftUI

@main
struct JARVISWatchApp: App {
    @StateObject private var session = JARVISWatchSession()

    var body: some Scene {
        WindowGroup {
            WatchContentView()
                .environmentObject(session)
        }
    }
}
