import Foundation

final class JARVISWatchSession: ObservableObject {
    @Published var status: String = "Hazir"
}
