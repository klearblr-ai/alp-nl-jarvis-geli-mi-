import SwiftUI

struct WatchContentView: View {
    @EnvironmentObject var session: JARVISWatchSession

    var body: some View {
        VStack(spacing: 10) {
            Text("JARVIS")
                .font(.headline)
            Text(session.status)
                .font(.caption)
            Button("Hey JARVIS") {
                session.status = "Komut transferi hazir"
            }
        }
        .padding()
    }
}
