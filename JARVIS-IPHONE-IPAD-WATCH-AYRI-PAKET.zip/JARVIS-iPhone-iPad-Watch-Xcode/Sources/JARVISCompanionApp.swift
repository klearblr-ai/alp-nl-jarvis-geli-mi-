import SwiftUI

@main
struct JARVISCompanionApp: App {
    @StateObject private var session = JARVISDeviceSession()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(session)
        }
    }
}
