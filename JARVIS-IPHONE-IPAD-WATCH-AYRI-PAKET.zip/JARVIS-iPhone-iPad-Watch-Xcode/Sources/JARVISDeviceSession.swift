import Foundation
import CryptoKit

final class JARVISDeviceSession: ObservableObject {
    @Published var pairCode: String = "api-key-yok"
    @Published var status: String = "Hazir"
    @Published var lastCommand: String = ""

    func configure(apiKey: String) {
        let trimmed = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            pairCode = "api-key-yok"
            status = "API key girilmedi"
            return
        }
        let digest = SHA256.hash(data: Data(trimmed.utf8))
        pairCode = digest.compactMap { String(format: "%02x", $0) }.joined().prefix(16).description
        status = "Ayni API key ile esleme hazir"
    }
}
