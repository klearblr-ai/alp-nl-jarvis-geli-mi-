import SwiftUI

struct ContentView: View {
    @EnvironmentObject var session: JARVISDeviceSession
    @State private var apiKey = ""
    @State private var command = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("API Key") {
                    SecureField("Gemini API key", text: $apiKey)
                    Button("Ayni API Key ile Esle") {
                        session.configure(apiKey: apiKey)
                    }
                }

                Section("Cihaz") {
                    Text("Esleme kodu: \(session.pairCode)")
                    Text("Durum: \(session.status)")
                }

                Section("Komut Transfer") {
                    TextField("Mac JARVIS komutu", text: $command)
                    Button("Komutu Hazirla") {
                        session.lastCommand = command
                        session.status = "Komut hazirlandi: \(command)"
                    }
                }
            }
            .navigationTitle("JARVIS")
        }
    }
}
