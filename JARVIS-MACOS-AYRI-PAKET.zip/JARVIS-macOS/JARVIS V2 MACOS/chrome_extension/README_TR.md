JARVIS Chrome Güvenli İçerik Filtresi

Kurulum:
1. Chrome'da chrome://extensions sayfasını aç.
2. Sağ üstten Developer mode'u aç.
3. Load unpacked düğmesine bas.
4. Bu klasörü seç: JARVIS V2 MACOS/chrome_extension

Ne yapar?
- 18+, korku ve aşırı şiddet işaretleri görürse sayfayı blur/gizle/karart/metin maskele modlarından biriyle kapatır.
- Görselleri, videoları ve sayfa metnini ekranda saklar.
- Web sitesindeki içeriği silmez; sadece senin Chrome ekranında görünmesini engeller.
- İzin verilen site listesi uzantının içinde tutulur.

JARVIS uygulamasına bağlama:
- JARVIS açıkken "20 güvenli özellik" veya "Chrome uzantısı tokenini göster" de.
- Çıkan JARVIS köprü tokenini uzantı popup'ındaki Token alanına yaz.
- Bundan sonra uzantı JARVIS'e risk uyarısı gönderebilir, JARVIS filtresini aç/kapatabilir ve token ile güvenli uygulama açma komutu gönderebilir.
- Köprü sadece bu Mac içinde 127.0.0.1:8787 adresinden çalışır.
