const BRIDGE_URL = "http://127.0.0.1:8787";

async function getBridgeToken() {
  const { bridgeToken } = await chrome.storage.sync.get(["bridgeToken"]);
  return String(bridgeToken || "").trim();
}

async function bridgeFetch(path, payload = null) {
  const token = await getBridgeToken();
  if (!token) {
    return { ok: false, error: "JARVIS tokeni girilmedi." };
  }
  const options = {
    method: payload ? "POST" : "GET",
    headers: {
      "Content-Type": "application/json",
      "X-JARVIS-Token": token
    }
  };
  if (payload) {
    options.body = JSON.stringify({ ...payload, token });
  }
  try {
    const response = await fetch(`${BRIDGE_URL}${path}`, options);
    return await response.json();
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "JARVIS_CONTENT_EVENT") {
    bridgeFetch("/content-event", message.payload).then(sendResponse);
    return true;
  }
  if (message?.type === "JARVIS_BRIDGE_COMMAND") {
    bridgeFetch("/command", message.payload).then(sendResponse);
    return true;
  }
  if (message?.type === "JARVIS_BRIDGE_STATUS") {
    bridgeFetch("/status").then(sendResponse);
    return true;
  }
});
