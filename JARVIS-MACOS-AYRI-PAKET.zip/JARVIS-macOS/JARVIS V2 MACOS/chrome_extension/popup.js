const DEFAULTS = {
  enabled: true,
  mode: "blur",
  sensitivity: "normal",
  bridgeToken: ""
};

const $ = (id) => document.getElementById(id);

async function load() {
  const stored = await chrome.storage.sync.get(Object.keys(DEFAULTS));
  const cfg = { ...DEFAULTS, ...stored };
  $("enabled").checked = Boolean(cfg.enabled);
  $("mode").value = cfg.mode;
  $("sensitivity").value = cfg.sensitivity;
  $("bridgeToken").value = cfg.bridgeToken || "";
}

async function saveSetting(key, value) {
  await chrome.storage.sync.set({ [key]: value });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: "JARVIS_SCAN_NOW" }).catch(() => {});
  }
}

function setStatus(text) {
  $("statusText").textContent = text;
}

function sendBridge(payload) {
  return chrome.runtime.sendMessage({ type: "JARVIS_BRIDGE_COMMAND", payload });
}

$("enabled").addEventListener("change", (event) => saveSetting("enabled", event.target.checked));
$("mode").addEventListener("change", (event) => saveSetting("mode", event.target.value));
$("sensitivity").addEventListener("change", (event) => saveSetting("sensitivity", event.target.value));

$("saveToken").addEventListener("click", async () => {
  await chrome.storage.sync.set({ bridgeToken: $("bridgeToken").value.trim() });
  setStatus("Token kaydedildi.");
});

$("status").addEventListener("click", async () => {
  const result = await chrome.runtime.sendMessage({ type: "JARVIS_BRIDGE_STATUS" });
  setStatus(result?.ok ? `Bağlandı. Filtre: ${result.content_filter_enabled ? "açık" : "kapalı"}` : `Bağlanamadı: ${result?.error || "bilinmiyor"}`);
});

$("scan").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    await chrome.tabs.sendMessage(tab.id, { type: "JARVIS_SCAN_NOW" }).catch(() => {});
    setStatus("Sayfa tekrar kontrol edildi.");
  }
});

$("openApp").addEventListener("click", async () => {
  const appName = $("appName").value.trim();
  const result = await sendBridge({ action: "open_app", app_name: appName });
  setStatus(result?.message || result?.error || "Komut gönderildi.");
});

$("filterOn").addEventListener("click", async () => {
  const result = await sendBridge({ action: "content_filter_on" });
  setStatus(result?.message || result?.error || "Komut gönderildi.");
});

$("filterOff").addEventListener("click", async () => {
  const result = await sendBridge({ action: "content_filter_off" });
  setStatus(result?.message || result?.error || "Komut gönderildi.");
});

load();
