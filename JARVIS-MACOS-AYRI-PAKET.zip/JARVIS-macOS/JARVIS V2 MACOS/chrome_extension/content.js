const JARVIS_DEFAULTS = {
  enabled: true,
  mode: "blur",
  sensitivity: "normal",
  allowList: []
};

const KEYWORDS = {
  adult: [
    "porn", "porno", "xxx", "adult", "18+", "nsfw", "onlyfans", "nude",
    "çıplak", "ciplak", "erotik", "sex", "seks"
  ],
  horror: [
    "horror", "korku", "jumpscare", "creepy", "şeytan", "seytan", "cin",
    "zombi", "slasher", "paranormal", "lanet"
  ],
  violence: [
    "gore", "blood", "kan", "ölüm", "olum", "cinayet", "işkence",
    "iskence", "vahşet", "vahset", "katliam", "decapitation"
  ]
};

let jarvisState = { ...JARVIS_DEFAULTS };
let lastSignature = "";
let snoozeUntil = 0;
let observer = null;
let scanTimer = null;

function normalize(value) {
  return String(value || "").toLocaleLowerCase("tr-TR");
}

function pageHost() {
  return location.hostname.replace(/^www\./, "");
}

function isAllowed() {
  const host = pageHost();
  return (jarvisState.allowList || []).some((item) => host === item || host.endsWith(`.${item}`));
}

function collectText() {
  const parts = [
    document.title,
    location.href,
    document.querySelector('meta[name="description"]')?.content || "",
    document.querySelector('meta[property="og:title"]')?.content || "",
    document.querySelector('meta[property="og:description"]')?.content || ""
  ];
  const bodyText = document.body ? document.body.innerText.slice(0, 12000) : "";
  parts.push(bodyText);
  return normalize(parts.join(" "));
}

function classify(text) {
  const hits = [];
  const sensitivityBoost = jarvisState.sensitivity === "high";
  for (const [category, words] of Object.entries(KEYWORDS)) {
    const found = words.filter((word) => text.includes(normalize(word)));
    if (found.length >= 1 && (sensitivityBoost || found.length >= 2 || category !== "adult")) {
      hits.push({ category, words: found.slice(0, 4) });
    }
  }
  if (!hits.length) {
    return { block: false };
  }
  return {
    block: true,
    category: hits.map((hit) => hit.category).join(","),
    reason: hits.map((hit) => `${hit.category}: ${hit.words.join(", ")}`).join(" | ")
  };
}

function applyMode(mode) {
  const root = document.documentElement;
  root.classList.remove("jarvis-filter-blur", "jarvis-filter-hide", "jarvis-filter-dim", "jarvis-filter-text");
  root.classList.add(`jarvis-filter-${mode || "blur"}`);
}

function clearFilter() {
  document.documentElement.classList.remove("jarvis-filter-blur", "jarvis-filter-hide", "jarvis-filter-dim", "jarvis-filter-text");
  document.getElementById("jarvis-content-shield")?.remove();
}

function showShield(result) {
  applyMode(jarvisState.mode);
  let shield = document.getElementById("jarvis-content-shield");
  if (!shield) {
    shield = document.createElement("div");
    shield.id = "jarvis-content-shield";
    shield.innerHTML = `
      <div class="jarvis-panel">
        <h1>JARVIS içerik gizledi</h1>
        <p id="jarvis-shield-reason"></p>
        <button id="jarvis-snooze">15 sn göster</button>
        <button id="jarvis-allow" class="secondary">Bu siteye izin ver</button>
        <button id="jarvis-hide" class="secondary">Gizli kalsın</button>
      </div>`;
    document.documentElement.appendChild(shield);
    shield.querySelector("#jarvis-snooze").addEventListener("click", () => {
      snoozeUntil = Date.now() + 15000;
      clearFilter();
    });
    shield.querySelector("#jarvis-hide").addEventListener("click", () => showShield(result));
    shield.querySelector("#jarvis-allow").addEventListener("click", async () => {
      const host = pageHost();
      const allowList = Array.from(new Set([...(jarvisState.allowList || []), host]));
      await chrome.storage.sync.set({ allowList });
      jarvisState.allowList = allowList;
      clearFilter();
    });
  }
  const reason = shield.querySelector("#jarvis-shield-reason");
  if (reason) {
    reason.textContent = `${result.category || "risk"} algılandı. Sayfa bulanıklaştırıldı/gizlendi.`;
  }
}

function sendEvent(result) {
  const signature = `${location.href}|${result.category}|${result.reason}`;
  if (signature === lastSignature) {
    return;
  }
  lastSignature = signature;
  chrome.runtime.sendMessage({
    type: "JARVIS_CONTENT_EVENT",
    payload: {
      category: result.category,
      reason: result.reason,
      title: document.title,
      url: location.href
    }
  }).catch(() => {});
}

function scan() {
  if (!jarvisState.enabled || isAllowed() || Date.now() < snoozeUntil) {
    clearFilter();
    return;
  }
  const result = classify(collectText());
  if (result.block) {
    showShield(result);
    sendEvent(result);
  } else {
    clearFilter();
  }
}

async function loadState() {
  const stored = await chrome.storage.sync.get(Object.keys(JARVIS_DEFAULTS));
  jarvisState = { ...JARVIS_DEFAULTS, ...stored };
}

function startObserver() {
  observer?.disconnect();
  observer = new MutationObserver(() => {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, 600);
  });
  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
}

chrome.storage.onChanged.addListener(async () => {
  await loadState();
  scan();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "JARVIS_SCAN_NOW") {
    scan();
    sendResponse({ ok: true });
  }
});

(async () => {
  await loadState();
  startObserver();
  scan();
})();
