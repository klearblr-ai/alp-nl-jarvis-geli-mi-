#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.app_file_manager import app_file_manager
print(app_file_manager("open_downloads"))
PY
