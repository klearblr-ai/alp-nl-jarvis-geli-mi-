#!/bin/bash

cd "$(dirname "$0")" || exit 1

if [ -d "venv" ]; then
    source venv/bin/activate
fi

PYTHON_BIN="python"
if ! command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python3"
fi

"$PYTHON_BIN" - <<'PY'
from actions.smart_home import smart_home_control

print("Bluetooth cihazları taranıyor...")
print("")
print(smart_home_control("bluetooth_scan"))
print("")
input("Kapatmak için Enter'a bas...")
PY
