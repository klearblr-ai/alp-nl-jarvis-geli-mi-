#!/bin/bash

cd "$(dirname "$0")" || exit 1

if [ -d "venv" ]; then
    source venv/bin/activate
fi

PYTHON_BIN="python"
if ! command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python3"
fi

"$PYTHON_BIN" - <<'PY'
from app_config import save_app_config

save_app_config({
    "audio_input_device": "",
    "audio_input_gain": 2.6,
    "far_field_microphone": True,
    "sound_detection_enabled": True,
    "sound_detection_threshold": 350,
    "trusted_voice_phrase": "jarvis",
})
print("JARVIS uzak ses modu açıldı.")
print("Odanın öbür ucundan konuşmayı daha iyi yakalamak için mikrofon sesi yükseltilecek.")
print("Güvenli çağrı cümlesi: jarvis")
input("Kapatmak için Enter'a bas...")
PY
