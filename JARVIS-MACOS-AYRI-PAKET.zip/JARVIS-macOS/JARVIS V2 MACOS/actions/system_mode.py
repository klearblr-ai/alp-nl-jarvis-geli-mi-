from __future__ import annotations

import subprocess

from app_config import save_app_config


def system_mode(action: str = "low_power_on") -> str:
    action = (action or "low_power_on").strip().lower()
    if action in {"low_power_on", "dusuk_guc", "düşük_güç", "dusuk_guc_ac", "düşük güç"}:
        save_app_config({
            "webcam_ai_vision": False,
            "far_field_microphone": False,
            "sound_detection_enabled": False,
            "audio_input_gain": 1.0,
        })
        pmset_note = ""
        try:
            result = subprocess.run(["pmset", "-a", "lowpowermode", "1"], capture_output=True, text=True, timeout=8)
            if result.returncode != 0:
                pmset_note = " macOS düşük güç ayarı izin istemiş olabilir."
        except Exception:
            pmset_note = " macOS düşük güç ayarı uygulanamadı."
        return "JARVIS düşük güç modu açıldı: AI kamera akışı, uzak mikrofon güçlendirme ve ses algılama kapatıldı." + pmset_note

    if action in {"low_power_off", "normal", "dusuk_guc_kapat", "düşük güç kapat"}:
        save_app_config({
            "webcam_ai_vision": True,
            "far_field_microphone": True,
            "sound_detection_enabled": True,
            "audio_input_gain": 2.2,
        })
        try:
            subprocess.run(["pmset", "-a", "lowpowermode", "0"], capture_output=True, text=True, timeout=8)
        except Exception:
            pass
        return "JARVIS normal moda döndü."

    return "Sistem modu: low_power_on veya low_power_off kullan."
