from __future__ import annotations

import datetime as dt
import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parents[1]
SPENDING_PATH = BASE_DIR / "config" / "daily_spending.json"


def _load() -> dict:
    try:
        raw = json.loads(SPENDING_PATH.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            raw.setdefault("entries", [])
            raw.setdefault("budgets", {})
            return raw
    except Exception:
        pass
    return {"entries": [], "budgets": {}}


def _save(data: dict) -> None:
    SPENDING_PATH.parent.mkdir(parents=True, exist_ok=True)
    SPENDING_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _today() -> str:
    return dt.date.today().isoformat()


def daily_spending(action: str = "summary", amount: float = 0, category: str = "", note: str = "", date: str = "", budget: float = 0) -> str:
    action = (action or "summary").strip().lower()
    data = _load()
    entries = data["entries"]
    target_date = (date or _today()).strip()

    if action in {"add", "ekle", "spend", "harcama_ekle"}:
        try:
            value = float(amount)
        except Exception:
            return "Harcama tutarı geçersiz."
        if value <= 0:
            return "Harcama tutarı 0'dan büyük olmalı."
        entry = {
            "date": target_date,
            "amount": round(value, 2),
            "category": (category or "genel").strip(),
            "note": (note or "").strip(),
            "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        }
        entries.append(entry)
        _save(data)
        return f"Harcama eklendi: {entry['amount']:.2f} TL - {entry['category']}."

    if action in {"budget", "butce", "bütçe"}:
        try:
            value = float(budget or amount)
        except Exception:
            return "Bütçe tutarı geçersiz."
        data["budgets"][target_date] = round(value, 2)
        _save(data)
        return f"{target_date} günlük bütçesi {value:.2f} TL olarak ayarlandı."

    if action in {"clear_today", "bugunu_sil", "bugünü_sil"}:
        before = len(entries)
        data["entries"] = [item for item in entries if item.get("date") != target_date]
        _save(data)
        return f"{before - len(data['entries'])} harcama kaydı silindi."

    if action in {"summary", "ozet", "özet", "today"}:
        todays = [item for item in entries if item.get("date") == target_date]
        total = sum(float(item.get("amount", 0) or 0) for item in todays)
        by_cat: dict[str, float] = {}
        for item in todays:
            cat = str(item.get("category") or "genel")
            by_cat[cat] = by_cat.get(cat, 0.0) + float(item.get("amount", 0) or 0)
        budget_value = data.get("budgets", {}).get(target_date)
        lines = [f"{target_date} harcama toplamı: {total:.2f} TL."]
        if budget_value is not None:
            remain = float(budget_value) - total
            lines.append(f"Bütçe: {float(budget_value):.2f} TL, kalan: {remain:.2f} TL.")
        for cat, value in sorted(by_cat.items(), key=lambda kv: kv[1], reverse=True):
            lines.append(f"- {cat}: {value:.2f} TL")
        if not todays:
            lines.append("Bugün için harcama kaydı yok.")
        return "\n".join(lines)

    return "Günlük harcama: add, summary, budget veya clear_today kullan."
