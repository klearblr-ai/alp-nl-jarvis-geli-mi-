from __future__ import annotations

import json
import asyncio
import shlex
import socket
import subprocess
from pathlib import Path
from string import Template
from urllib.parse import quote


BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config" / "smart_home_devices.json"

BLOCKED_COMMAND_PARTS = (
    "rm -rf",
    "sudo ",
    "mkfs",
    "dd if=",
    "shutdown",
    "reboot",
    "halt",
    "diskutil erase",
    "chmod ",
    "chown ",
)


def _default_config() -> dict:
    return {
        "shortcuts": {
            "homekit_device": "JARVIS HomeKit Cihaz",
            "homekit_scene": "JARVIS HomeKit Sahne",
            "ir_remote": "JARVIS IR Kumanda",
            "bluetooth_bridge": "JARVIS Bluetooth Köprü",
        },
        "devices": {
            "salon_lamba": {
                "name": "Salon lamba",
                "type": "homekit",
                "aliases": ["salon ışığı", "salon lambası", "lamba"],
                "actions": {
                    "on": {"adapter": "shortcut", "shortcut": "JARVIS HomeKit Cihaz", "input": "on|$device|$room"},
                    "off": {"adapter": "shortcut", "shortcut": "JARVIS HomeKit Cihaz", "input": "off|$device|$room"},
                    "brightness": {"adapter": "shortcut", "shortcut": "JARVIS HomeKit Cihaz", "input": "brightness|$device|$brightness"},
                    "color": {"adapter": "shortcut", "shortcut": "JARVIS HomeKit Cihaz", "input": "color|$device|$color"},
                },
            },
            "lg_akilsiz_tv": {
                "name": "LG akılsız TV",
                "type": "ir_tv",
                "aliases": ["lg tv", "lg televizyon", "akılsız lg tv"],
                "actions": {
                    "power": {"adapter": "ir", "brand": "lg", "command": "power"},
                    "on": {"adapter": "ir", "brand": "lg", "command": "power"},
                    "off": {"adapter": "ir", "brand": "lg", "command": "power"},
                    "volume_up": {"adapter": "ir", "brand": "lg", "command": "volume_up"},
                    "volume_down": {"adapter": "ir", "brand": "lg", "command": "volume_down"},
                    "mute": {"adapter": "ir", "brand": "lg", "command": "mute"},
                    "channel_up": {"adapter": "ir", "brand": "lg", "command": "channel_up"},
                    "channel_down": {"adapter": "ir", "brand": "lg", "command": "channel_down"},
                },
            },
            "samsung_akilsiz_tv": {
                "name": "Samsung akılsız TV",
                "type": "ir_tv",
                "aliases": ["samsung tv", "samsung televizyon", "akılsız samsung tv"],
                "actions": {
                    "power": {"adapter": "ir", "brand": "samsung", "command": "power"},
                    "on": {"adapter": "ir", "brand": "samsung", "command": "power"},
                    "off": {"adapter": "ir", "brand": "samsung", "command": "power"},
                    "volume_up": {"adapter": "ir", "brand": "samsung", "command": "volume_up"},
                    "volume_down": {"adapter": "ir", "brand": "samsung", "command": "volume_down"},
                    "mute": {"adapter": "ir", "brand": "samsung", "command": "mute"},
                    "channel_up": {"adapter": "ir", "brand": "samsung", "command": "channel_up"},
                    "channel_down": {"adapter": "ir", "brand": "samsung", "command": "channel_down"},
                },
            },
            "akilli_tv": {
                "name": "Akıllı TV",
                "type": "smart_tv",
                "aliases": ["smart tv", "televizyon", "tv"],
                "actions": {
                    "open_url": {"adapter": "open_url", "url": "$raw_command"},
                    "wake": {"adapter": "wol", "mac": "AA:BB:CC:DD:EE:FF"},
                    "power": {"adapter": "shortcut", "shortcut": "JARVIS Akıllı TV", "input": "$action|$raw_command"},
                    "volume_up": {"adapter": "shortcut", "shortcut": "JARVIS Akıllı TV", "input": "volume_up"},
                    "volume_down": {"adapter": "shortcut", "shortcut": "JARVIS Akıllı TV", "input": "volume_down"},
                },
            },
            "bluetooth_cakma_cihaz": {
                "name": "Bluetooth çakma cihaz",
                "type": "bluetooth_generic",
                "aliases": ["bluetooth cihaz", "çakma bluetooth", "bt cihaz"],
                "address": "",
                "notes": "Önce smart_home_control(action='bluetooth_scan') ile cihaz adresini bul. BLE ise characteristic_uuid ve hex komutları doldur.",
                "actions": {
                    "on": {"adapter": "bluetooth_shortcut", "shortcut": "JARVIS Bluetooth Köprü", "input": "on|$device|$raw_command"},
                    "off": {"adapter": "bluetooth_shortcut", "shortcut": "JARVIS Bluetooth Köprü", "input": "off|$device|$raw_command"},
                    "ble_on": {"adapter": "bluetooth_ble", "characteristic_uuid": "", "hex": "01"},
                    "ble_off": {"adapter": "bluetooth_ble", "characteristic_uuid": "", "hex": "00"}
                },
            },
            "direkt_ble_cihaz": {
                "name": "Direkt BLE cihaz",
                "type": "direct_bluetooth",
                "aliases": ["direkt bluetooth", "köprüsüz bluetooth", "ble cihaz"],
                "address": "",
                "characteristic_uuid": "",
                "notes": "Köprüsüz direkt BLE kontrol. Bluetooth tarama ile address, servis bilgisi ile characteristic_uuid doldur.",
                "actions": {
                    "on": {"adapter": "bluetooth_ble", "hex": "01"},
                    "off": {"adapter": "bluetooth_ble", "hex": "00"},
                    "brightness": {"adapter": "bluetooth_ble", "hex": "02 $brightness_hex"},
                    "color": {"adapter": "bluetooth_ble", "text": "$color"},
                },
            },
            "direkt_wifi_cihaz": {
                "name": "Direkt Wi-Fi cihaz",
                "type": "direct_http",
                "aliases": ["direkt wifi", "köprüsüz wifi", "wifi cihaz"],
                "notes": "Cihazın yerel HTTP API adresini girersen köprüsüz kontrol eder.",
                "actions": {
                    "on": {"adapter": "http", "method": "POST", "url": "http://192.168.1.50/on"},
                    "off": {"adapter": "http", "method": "POST", "url": "http://192.168.1.50/off"},
                    "brightness": {"adapter": "http", "method": "POST", "url": "http://192.168.1.50/brightness", "body": {"value": "$brightness"}},
                    "color": {"adapter": "http", "method": "POST", "url": "http://192.168.1.50/color", "body": {"value": "$color"}},
                },
            },
            "direkt_pc": {
                "name": "Direkt PC",
                "type": "direct_lan",
                "aliases": ["köprüsüz pc", "direkt bilgisayar", "lan pc"],
                "actions": {
                    "wake": {"adapter": "wol", "mac": "AA:BB:CC:DD:EE:FF"},
                    "open_url": {"adapter": "open_url", "url": "$raw_command"},
                },
            },
        },
    }


def ensure_default_config() -> None:
    if CONFIG_PATH.exists():
        return
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(_default_config(), indent=4, ensure_ascii=False),
        encoding="utf-8",
    )


def _load_config() -> dict:
    ensure_default_config()
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else _default_config()
    except Exception as exc:
        data = _default_config()
        data["_error"] = f"Akıllı ev ayar dosyası okunamadı: {exc}"
        return data


def _norm(value: str) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _render(value, variables: dict):
    if isinstance(value, str):
        return Template(value).safe_substitute(variables)
    if isinstance(value, list):
        return [_render(item, variables) for item in value]
    if isinstance(value, dict):
        return {key: _render(item, variables) for key, item in value.items()}
    return value


def _byte_hex(value) -> str:
    try:
        number = max(0, min(255, int(value)))
        return f"{number:02x}"
    except Exception:
        return "00"


def _run_shortcut(name: str, input_text: str = "") -> str:
    if not name:
        return "Kestirme adı eksik."
    cmd = ["shortcuts", "run", name]
    if input_text:
        cmd.extend(["--input-path", "-"])
    result = subprocess.run(
        cmd,
        input=input_text if input_text else None,
        capture_output=True,
        text=True,
        timeout=25,
    )
    output = (result.stdout + result.stderr).strip()
    if result.returncode == 0:
        return output or f"{name} kestirmesi çalıştı."
    return output or f"{name} kestirmesi çalıştırılamadı."


async def _ble_scan_async(seconds: float) -> str:
    try:
        from bleak import BleakScanner
    except Exception:
        return "Bluetooth tarama için bleak paketi gerekli. KUR.command yeniden çalıştırılınca kurulur."

    devices = await BleakScanner.discover(timeout=seconds)
    if not devices:
        return "Yakında Bluetooth LE cihaz bulunamadı."

    lines = []
    for dev in devices[:30]:
        name = dev.name or "Adsız cihaz"
        lines.append(f"- {name} | {dev.address}")
    return "\n".join(lines)


def _ble_scan(seconds: float = 6.0) -> str:
    return asyncio.run(_ble_scan_async(seconds))


async def _ble_info_async(address: str) -> str:
    try:
        from bleak import BleakClient
    except Exception:
        return "Bluetooth bilgi için bleak paketi gerekli. KUR.command yeniden çalıştırılınca kurulur."

    if not address:
        return "Bluetooth cihaz adresi eksik. Önce 'Bluetooth cihazları tara' de."

    async with BleakClient(address, timeout=12.0) as client:
        if not client.is_connected:
            return "Bluetooth cihaza bağlanılamadı."
        services = client.services
        lines = []
        for service in services:
            lines.append(f"Servis: {service.uuid}")
            for char in service.characteristics:
                props = ",".join(char.properties or [])
                lines.append(f"  Karakteristik: {char.uuid} [{props}]")
    return "\n".join(lines) if lines else "BLE servis bilgisi bulunamadı."


def _ble_info(address: str) -> str:
    return asyncio.run(_ble_info_async(address))


async def _ble_write_async(address: str, characteristic_uuid: str, payload: bytes, response: bool) -> str:
    try:
        from bleak import BleakClient
    except Exception:
        return "Bluetooth kontrol için bleak paketi gerekli. KUR.command yeniden çalıştırılınca kurulur."

    if not address:
        return "Bluetooth cihaz adresi eksik. Önce 'Bluetooth cihazları tara' de."
    if not characteristic_uuid:
        return "BLE characteristic_uuid eksik. Bu marka/model için yazılacak karakteristik config dosyasına girilmeli."

    async with BleakClient(address, timeout=12.0) as client:
        if not client.is_connected:
            return "Bluetooth cihaza bağlanılamadı."
        await client.write_gatt_char(characteristic_uuid, payload, response=response)
    return "Bluetooth komutu gönderildi."


def _run_bluetooth_ble(spec: dict, device: dict, variables: dict) -> str:
    address = _render(spec.get("address") or device.get("address", ""), variables)
    characteristic_uuid = _render(
        spec.get("characteristic_uuid") or device.get("characteristic_uuid", ""),
        variables,
    )
    hex_value = _render(spec.get("hex", ""), variables).replace(" ", "")
    text_value = _render(spec.get("text", ""), variables)
    response = bool(spec.get("response", False))

    if hex_value:
        try:
            payload = bytes.fromhex(hex_value)
        except ValueError:
            return "Bluetooth hex komutu geçersiz."
    elif text_value:
        payload = text_value.encode("utf-8")
    else:
        return "Bluetooth komutu eksik: hex veya text verilmeli."

    return asyncio.run(_ble_write_async(address, characteristic_uuid, payload, response))


def _run_bluetooth_shortcut(spec: dict, config: dict, variables: dict) -> str:
    shortcut = (
        spec.get("shortcut")
        or (config.get("shortcuts") or {}).get("bluetooth_bridge")
        or "JARVIS Bluetooth Köprü"
    )
    input_text = _render(spec.get("input", "$action|$device|$raw_command"), variables)
    return _run_shortcut(shortcut, input_text)


def _run_http(spec: dict, variables: dict) -> str:
    try:
        import requests
    except Exception:
        return "HTTP kontrol için requests paketi gerekli. KUR.command çalıştırıldığında otomatik kurulur."

    method = str(spec.get("method", "POST")).upper()
    url = _render(spec.get("url", ""), variables)
    headers = _render(spec.get("headers", {}), variables)
    body = _render(spec.get("body"), variables)
    if not url:
        return "HTTP adresi eksik."
    response = requests.request(
        method,
        url,
        headers=headers,
        json=body if isinstance(body, (dict, list)) else None,
        data=body if isinstance(body, str) else None,
        timeout=float(spec.get("timeout", 8) or 8),
    )
    if 200 <= response.status_code < 300:
        return response.text.strip()[:500] or "Cihaz komutu gönderildi."
    return f"HTTP hata {response.status_code}: {response.text[:300]}"


def _run_shell(command: str) -> str:
    if not command:
        return "Komut eksik."
    lowered = command.lower()
    if any(part in lowered for part in BLOCKED_COMMAND_PARTS):
        return "Güvenlik: Bu cihaz komutu engellendi."
    result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=25)
    output = (result.stdout + result.stderr).strip()
    if result.returncode == 0:
        return output or "Komut çalıştı."
    return output or "Komut başarısız."


def _open_url(url: str, variables: dict) -> str:
    rendered = _render(url, variables)
    if not rendered:
        return "URL eksik."
    result = subprocess.run(["open", rendered], capture_output=True, text=True, timeout=10)
    if result.returncode == 0:
        return "URL açıldı."
    return (result.stderr or result.stdout or "URL açılamadı.").strip()


def _wake_on_lan(mac: str, broadcast: str = "255.255.255.255", port: int = 9) -> str:
    clean = mac.replace("-", "").replace(":", "").strip()
    if len(clean) != 12:
        return "Wake-on-LAN için geçerli MAC adresi gerekli."
    packet = bytes.fromhex("ff" * 6 + clean * 16)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.sendto(packet, (broadcast, int(port)))
        return "Uyandırma paketi gönderildi."
    finally:
        sock.close()


def _find_device(config: dict, name: str) -> tuple[str | None, dict | None]:
    wanted = _norm(name)
    for key, spec in (config.get("devices") or {}).items():
        aliases = [key, spec.get("name", ""), *(spec.get("aliases") or [])]
        if wanted in {_norm(alias) for alias in aliases if alias}:
            return key, spec
    return None, None


def _list_devices(config: dict) -> str:
    lines = []
    for key, spec in (config.get("devices") or {}).items():
        actions = ", ".join(sorted((spec.get("actions") or {}).keys()))
        lines.append(f"- {spec.get('name') or key}: {actions}")
    return "\n".join(lines) if lines else "Kayıtlı cihaz yok."


def _direct_capabilities(device: dict) -> list[str]:
    direct = []
    for name, spec in (device.get("actions") or {}).items():
        adapter = _norm(spec.get("adapter", ""))
        if adapter in {"bluetooth_ble", "http", "wol", "open_url", "shell"}:
            direct.append(name)
    return direct


def _direct_status(config: dict) -> str:
    lines = []
    for key, device in (config.get("devices") or {}).items():
        direct = _direct_capabilities(device)
        if direct:
            lines.append(f"- {device.get('name') or key}: direkt uygun -> {', '.join(sorted(direct))}")
        else:
            lines.append(f"- {device.get('name') or key}: direkt kanal yok, köprü/donanım/protokol gerekir")
    return "\n".join(lines) if lines else "Kayıtlı cihaz yok."


def _no_direct_message(device_name: str, device: dict) -> str:
    adapters = sorted({
        _norm(spec.get("adapter", ""))
        for spec in (device.get("actions") or {}).values()
        if spec.get("adapter")
    })
    adapters_text = ", ".join(adapters) if adapters else "tanımlı adaptör yok"
    return (
        f"{device.get('name', device_name)} için köprüsüz direkt kontrol kanalı yok. "
        f"Mevcut tanım: {adapters_text}. Direkt kontrol için cihazın Bluetooth LE karakteristiği, "
        "yerel HTTP API'si, Wake-on-LAN MAC adresi veya başka açık bir protokolü config dosyasına girilmeli."
    )


def smart_home_control(
    action: str,
    device_name: str = "",
    room: str = "",
    brightness: int | None = None,
    color: str = "",
    scene_name: str = "",
    raw_command: str = "",
) -> str:
    config = _load_config()
    if config.get("_error"):
        return config["_error"]

    action = _norm(action).replace(" ", "_")
    if action in {"list", "liste", "devices", "cihazlar"}:
        return _list_devices(config)
    if action in {"direct_status", "direkt_durum", "direct_list", "direkt_liste"}:
        return _direct_status(config)
    if action in {"bluetooth_scan", "bluetooth_tara", "bt_scan", "bt_tara"}:
        return _ble_scan()
    if action in {"bluetooth_info", "bluetooth_bilgi", "bt_info", "bt_bilgi"}:
        _, info_device = _find_device(config, device_name)
        address = raw_command or (info_device or {}).get("address", "") or device_name
        return _ble_info(address)

    variables = {
        "action": action,
        "device": device_name,
        "room": room,
        "brightness": "" if brightness is None else str(int(brightness)),
        "brightness_hex": "" if brightness is None else _byte_hex(brightness),
        "color": color,
        "scene": scene_name,
        "raw_command": raw_command,
        "quoted_device": quote(device_name),
        "quoted_color": quote(color),
        "quoted_scene": quote(scene_name),
        "quoted_raw_command": quote(raw_command),
    }

    if action in {"scene", "sahne", "run_scene"}:
        shortcut = (config.get("shortcuts") or {}).get("homekit_scene", "JARVIS HomeKit Sahne")
        return _run_shortcut(shortcut, scene_name or raw_command)

    _, device = _find_device(config, device_name)
    if not device:
        return (
            f"{device_name or 'Bu cihaz'} kayıtlı değil. "
            "config/smart_home_devices.json içine HomeKit, IR, HTTP, Kestirme veya Wake-on-LAN ayarı ekle."
        )

    actions = device.get("actions") or {}
    aliases = {
        "aç": "on",
        "ac": "on",
        "kapat": "off",
        "parlaklık": "brightness",
        "parlaklik": "brightness",
        "renk": "color",
        "ses_arttır": "volume_up",
        "ses_artir": "volume_up",
        "ses_kıs": "volume_down",
        "ses_kis": "volume_down",
        "kanal_arttır": "channel_up",
        "kanal_artir": "channel_up",
        "kanal_kıs": "channel_down",
        "kanal_kis": "channel_down",
    }
    spec = actions.get(action) or actions.get(aliases.get(action, ""))
    if not spec:
        if action in {"direct", "direkt", "direct_on", "direkt_ac", "direkt_aç"}:
            direct = _direct_capabilities(device)
            if direct:
                preferred = "on" if "on" in direct else direct[0]
                spec = actions.get(preferred)
                action = preferred
            else:
                return _no_direct_message(device_name, device)
        else:
            return f"{device.get('name', device_name)} için '{action}' eylemi tanımlı değil."

    if action in {"direct", "direkt", "direct_on", "direkt_ac", "direkt_aç"} and _norm(spec.get("adapter", "")) not in {
        "bluetooth_ble", "http", "wol", "open_url", "shell"
    }:
        return _no_direct_message(device_name, device)

    if _norm(spec.get("adapter", "")) in {"shortcut", "ir", "bluetooth_shortcut"} and str(raw_command).lower() in {
        "direct", "direkt", "köprüsüz", "koprusuz"
    }:
        return _no_direct_message(device_name, device)

    if not spec:
        return f"{device.get('name', device_name)} için '{action}' eylemi tanımlı değil."

    adapter = _norm(spec.get("adapter", "shortcut"))
    if adapter == "shortcut":
        return _run_shortcut(spec.get("shortcut", ""), _render(spec.get("input", "$action|$device"), variables))
    if adapter == "ir":
        shortcut = spec.get("shortcut") or (config.get("shortcuts") or {}).get("ir_remote", "JARVIS IR Kumanda")
        brand = spec.get("brand", device.get("brand", "generic"))
        command = spec.get("command", action)
        return _run_shortcut(shortcut, f"{brand}|{command}|{device.get('name', device_name)}")
    if adapter == "http":
        return _run_http(spec, variables)
    if adapter == "bluetooth_ble":
        return _run_bluetooth_ble(spec, device, variables)
    if adapter == "bluetooth_shortcut":
        return _run_bluetooth_shortcut(spec, config, variables)
    if adapter == "shell":
        return _run_shell(_render(spec.get("command", ""), variables))
    if adapter == "open_url":
        return _open_url(spec.get("url", ""), variables)
    if adapter == "wol":
        return _wake_on_lan(
            spec.get("mac", ""),
            spec.get("broadcast", "255.255.255.255"),
            int(spec.get("port", 9) or 9),
        )

    return f"Bilinmeyen adaptör: {adapter}"
