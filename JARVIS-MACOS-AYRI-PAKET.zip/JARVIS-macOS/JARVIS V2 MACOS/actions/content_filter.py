from __future__ import annotations

import json
import subprocess
from pathlib import Path

from google import genai
from google.genai import types

from app_config import get_app_config_value, save_app_config
from actions.screen_vision import (
    _build_image_part,
    _image_looks_blank,
    _parse_capture_payload,
    _run_helper,
)


ADULT_WORDS = (
    "porn", "porno", "xxx", "adult", "18+", "nsfw", "onlyfans", "nude", "çıplak", "ciplak",
)
HORROR_WORDS = (
    "horror", "korku", "jumpscare", "creepy", "cin", "şeytan", "seytan", "zombi", "slasher",
)
VIOLENCE_WORDS = (
    "gore", "blood", "kan", "ölüm", "olum", "cinayet", "işkence", "iskence", "vahşet", "vahset",
)


def content_filter_control(action: str = "on", auto_close: bool | None = None) -> str:
    action = (action or "on").strip().lower()
    if action in {"on", "enable", "ac", "aç", "filtre_ac", "filtre_aç"}:
        updates = {"content_filter_enabled": True}
        if auto_close is not None:
            updates["content_filter_auto_close"] = bool(auto_close)
        save_app_config(updates)
        return "İçerik filtresi açıldı. 18+, korku ve aşırı şiddet içeriklerini kalkanla gizlemeye çalışacağım."
    if action in {"off", "disable", "kapat", "filtre_kapat"}:
        save_app_config({"content_filter_enabled": False})
        return "İçerik filtresi kapatıldı."
    if action in {"status", "durum"}:
        enabled = bool(get_app_config_value("content_filter_enabled", False))
        interval = get_app_config_value("content_filter_interval_seconds", 5)
        auto = bool(get_app_config_value("content_filter_auto_close", False))
        return f"İçerik filtresi: {'açık' if enabled else 'kapalı'}, kontrol aralığı {interval} sn, otomatik kapatma {'açık' if auto else 'kapalı'}."
    return "İçerik filtresi komutu: on, off veya status kullan."


def _keyword_classify(owner_name: str, window_title: str) -> tuple[bool, str, str]:
    text = f"{owner_name} {window_title}".lower()
    groups = []
    if bool(get_app_config_value("content_filter_block_adult", True)) and any(word in text for word in ADULT_WORDS):
        groups.append("adult")
    if bool(get_app_config_value("content_filter_block_horror", True)) and any(word in text for word in HORROR_WORDS):
        groups.append("horror")
    if bool(get_app_config_value("content_filter_block_violence", True)) and any(word in text for word in VIOLENCE_WORDS):
        groups.append("violence")
    if groups:
        return True, ",".join(groups), "Pencere başlığında riskli içerik işareti var."
    return False, "safe", ""


def _gemini_classify(image_path: Path, owner_name: str, window_title: str) -> tuple[bool, str, str]:
    api_key = str(get_app_config_value("gemini_api_key", "") or "").strip()
    if not api_key:
        return False, "unknown", "API key yok; sadece başlık filtresi yapıldı."

    prompt = (
        "Bu ekran görüntüsünü çocuk/ergen güvenliği filtresi için sınıflandır.\n"
        "Sadece JSON döndür: {\"block\": true/false, \"category\": \"adult|horror|violence|safe|unknown\", \"reason\": \"kısa Türkçe sebep\"}.\n"
        "Yetişkin/18+ çıplaklık veya cinsel içerik varsa block=true.\n"
        "Korku, jumpscare, rahatsız edici canavar/şeytan/zombi içerik varsa block=true.\n"
        "Aşırı kan, vahşet veya şiddet varsa block=true.\n"
        f"Pencere: {owner_name} / {window_title}"
    )
    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model="models/gemini-2.0-flash",
        contents=[types.Part.from_text(text=prompt), _build_image_part(image_path)],
        config=types.GenerateContentConfig(temperature=0.0),
    )
    text = str(getattr(response, "text", "") or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text.replace("json\n", "", 1).strip()
    try:
        payload = json.loads(text)
    except Exception:
        return False, "unknown", "Görsel sınıflandırma okunamadı."
    block = bool(payload.get("block", False))
    category = str(payload.get("category", "unknown") or "unknown")
    reason = str(payload.get("reason", "") or "").strip()
    return block, category, reason


def check_active_content() -> dict:
    ok, raw = _run_helper("capture_active_window", timeout=20)
    if not ok:
        return {"ok": False, "block": False, "category": "error", "reason": raw}
    parsed_ok, detail, payload = _parse_capture_payload(raw)
    if not parsed_ok or not payload:
        return {"ok": False, "block": False, "category": "error", "reason": detail}

    image_path = Path(payload["image_path"])
    owner_name = str(payload.get("owner_name", "") or "").strip()
    window_title = str(payload.get("window_title", "") or "").strip()
    try:
        blocked, category, reason = _keyword_classify(owner_name, window_title)
        if not blocked and image_path.exists() and image_path.stat().st_size > 0 and not _image_looks_blank(image_path):
            try:
                blocked, category, reason = _gemini_classify(image_path, owner_name, window_title)
            except Exception as exc:
                reason = f"Görsel filtre tamamlanamadı: {exc}"
        return {
            "ok": True,
            "block": bool(blocked),
            "category": category,
            "reason": reason,
            "owner_name": owner_name,
            "window_title": window_title,
        }
    finally:
        try:
            if image_path.exists():
                image_path.unlink()
        except Exception:
            pass


def close_active_window() -> str:
    try:
        script = 'tell application "System Events" to keystroke "w" using command down'
        subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=5)
        return "Aktif pencereyi kapatmayı denedim."
    except Exception as exc:
        return f"Aktif pencere kapatılamadı: {exc}"
