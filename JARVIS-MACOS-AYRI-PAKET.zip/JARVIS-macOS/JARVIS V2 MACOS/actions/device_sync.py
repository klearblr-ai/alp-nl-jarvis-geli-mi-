from __future__ import annotations

import hashlib
import json
import platform
import socket
from pathlib import Path

from app_config import get_app_config_value


BASE_DIR = Path(__file__).resolve().parents[1]
DEVICES_PATH = BASE_DIR / "config" / "paired_devices.json"


def _api_pair_code() -> str:
    key = str(get_app_config_value("gemini_api_key", "") or "")
    if not key:
        return "no-api-key"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def _load() -> dict:
    try:
        raw = json.loads(DEVICES_PATH.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            raw.setdefault("devices", [])
            return raw
    except Exception:
        pass
    return {"pair_code": _api_pair_code(), "devices": []}


def _save(data: dict) -> None:
    DEVICES_PATH.parent.mkdir(parents=True, exist_ok=True)
    data["pair_code"] = _api_pair_code()
    DEVICES_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def device_sync(action: str = "status", device_name: str = "", device_type: str = "", command: str = "") -> str:
    action = (action or "status").strip().lower()
    data = _load()
    devices = data["devices"]

    if action in {"status", "pair_code", "durum"}:
        host = socket.gethostname()
        code = _api_pair_code()
        return (
            f"Bu Mac cihaz kodu: {code}. Cihaz: {host} ({platform.system()}). "
            "iPhone/Watch companion aynı API key ile bu kodu eşleştirme için kullanır."
        )

    if action in {"register", "add_device", "cihaz_ekle"}:
        name = (device_name or socket.gethostname()).strip()
        dtype = (device_type or "unknown").strip()
        code = _api_pair_code()
        existing = next((d for d in devices if d.get("name") == name), None)
        payload = {"name": name, "type": dtype, "pair_code": code}
        if existing:
            existing.update(payload)
        else:
            devices.append(payload)
        _save(data)
        return f"Cihaz eşlendi: {name} ({dtype})."

    if action in {"list", "cihazlari_listele", "cihazları_listele"}:
        if not devices:
            return "Eşlenmiş cihaz yok. Aynı API key kullanan companion cihazı önce kaydet."
        return "Eşlenmiş cihazlar:\n" + "\n".join(f"- {d.get('name')} ({d.get('type')})" for d in devices)

    if action in {"control", "kontrol"}:
        if not device_name:
            return "Kontrol için cihaz adı gerekli."
        match = next((d for d in devices if d.get("name", "").lower() == device_name.lower()), None)
        if not match:
            return "Bu cihaz eşlenmemiş. Önce aynı API key ile eşleştir."
        return (
            f"{device_name} için komut hazırlandı: {command or 'durum'}. "
            "Tam uzaktan kontrol için companion uygulamanın arka plan bağlantısı açık olmalı."
        )

    return "Cihaz senkron: status, register, list veya control kullan."
