from __future__ import annotations

import datetime as dt
import json
import os
import shlex
import subprocess
from pathlib import Path

from actions.open_app import open_app
from actions.sys_info import sys_info
from actions.calendar import get_calendar_events
from actions.reminders import get_reminders, add_reminder
from actions.smart_home import smart_home_control


def _run(args: list[str], timeout: int = 20) -> str:
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        output = (result.stdout + result.stderr).strip()
        return output[:1200] if output else ""
    except subprocess.TimeoutExpired:
        return "İşlem zaman aşımına uğradı."
    except Exception as exc:
        return f"Hata: {exc}"


def _osascript(script: str, timeout: int = 20) -> str:
    return _run(["osascript", "-e", script], timeout=timeout)


def _open_url(url: str) -> str:
    out = _run(["open", url], timeout=10)
    return out or "Açıldı."


def _safe_shell(command: str) -> str:
    if not command:
        return "Komut eksik."
    blocked = (
        "rm ",
        "rm\t",
        "rm -",
        "sudo ",
        "mkfs",
        "dd if=",
        "diskutil erase",
        "shutdown",
        "reboot",
        "halt",
        "chmod ",
        "chown ",
        ":(){",
        "killall ",
    )
    lowered = command.lower()
    if any(token in lowered for token in blocked):
        return "Güvenlik: Bu PC komutu doğrudan çalıştırılmadı."
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=20)
        output = (result.stdout + result.stderr).strip()
        return output[:1200] if output else "Komut çalıştı."
    except subprocess.TimeoutExpired:
        return "Komut zaman aşımına uğradı."
    except Exception as exc:
        return f"Hata: {exc}"


def _notes(action: str, query: str, content: str) -> str:
    if action in {"create_note", "not_ekle", "note_create"}:
        title = query or "JARVIS Notu"
        body = content or query or ""
        script = (
            'tell application "Notes"\n'
            'activate\n'
            f'make new note at default account with properties {{name:{json.dumps(title)}, body:{json.dumps(body)}}}\n'
            "end tell"
        )
        return _osascript(script) or "Not eklendi."

    if action in {"notes", "notlar", "list_notes", "not_listele"}:
        script = (
            'tell application "Notes"\n'
            'set outText to ""\n'
            'repeat with n in notes\n'
            'set outText to outText & name of n & linefeed\n'
            'if (count of paragraphs of outText) > 12 then exit repeat\n'
            'end repeat\n'
            'return outText\n'
            'end tell'
        )
        return _osascript(script) or "Notlar okunamadı veya izin gerekiyor."

    return open_app("Notes")


def _contacts(query: str) -> str:
    if not query:
        return open_app("Contacts")
    script = (
        'tell application "Contacts"\n'
        f'set q to {json.dumps(query)}\n'
        'set outText to ""\n'
        'repeat with p in people\n'
        'set nm to name of p as text\n'
        'if nm contains q then\n'
        'set outText to outText & nm\n'
        'try\n'
        'repeat with ph in phones of p\n'
        'set outText to outText & " | " & value of ph\n'
        'end repeat\n'
        'end try\n'
        'try\n'
        'repeat with em in emails of p\n'
        'set outText to outText & " | " & value of em\n'
        'end repeat\n'
        'end try\n'
        'set outText to outText & linefeed\n'
        'end if\n'
        'end repeat\n'
        'return outText\n'
        'end tell'
    )
    return _osascript(script) or "Kişi bulunamadı veya Kişiler izni gerekiyor."


def _search_files(query: str, kind: str = "") -> str:
    if not query:
        return "Aranacak dosya adı eksik."
    predicate = query
    if kind == "photos":
        predicate = f"{query} image"
    output = _run(["mdfind", predicate], timeout=15)
    if not output:
        return "Dosya bulunamadı veya Spotlight izni/indeksi yok."
    lines = [line for line in output.splitlines() if line.strip()]
    return "\n".join(lines[:12])


def _photos(action: str, query: str) -> str:
    if action in {"open_photos", "fotograflar", "fotoğraflar"}:
        return open_app("Photos")
    if action in {"search_photos", "foto_ara", "photo_search"}:
        return _search_files(query or "image", "photos")
    return open_app("Photos")


def _location() -> str:
    # macOS konumunu doğrudan okuma izni her sistemde farklıdır; Kestirme en temiz yol.
    out = _osascript('tell application "Shortcuts Events" to run shortcut "JARVIS Konum"', timeout=20)
    if out:
        return out
    return (
        "Konum için 'JARVIS Konum' adlı Kestirme oluştur veya Haritalar uygulamasına izin ver. "
        "Konumu izinsiz okuyamam."
    )


def _apple_account() -> str:
    # Apple ID bilgilerini/şifreleri okumaz; sadece güvenli ayar ekranını açar.
    _open_url("x-apple.systempreferences:com.apple.preferences.AppleIDPrefPane")
    return "Apple Hesabı ayarları açıldı. Şifre veya gizli hesap verisi okunmaz."


def _devices() -> str:
    bt = _run(["system_profiler", "SPBluetoothDataType"], timeout=20)
    home = smart_home_control("list")
    parts = ["Home/akıllı cihaz tanımları:", home]
    if bt:
        parts.extend(["", "Bluetooth özeti:", bt[:1200]])
    return "\n".join(parts)


def _daily_briefing(location: str = "") -> str:
    now = dt.datetime.now()
    try:
        from actions.weather import get_weather_summary
        weather = get_weather_summary(location or None)
    except Exception:
        weather = "Hava durumu bilgisi şu anda alınamadı."
    sections = [
        f"Bugün: {now.strftime('%d.%m.%Y %H:%M')}",
        weather,
        "Takvim: " + get_calendar_events("today", 5),
        "Anımsatıcılar: " + get_reminders("today", 6),
        "Aygıtlar: " + smart_home_control("direct_status"),
    ]
    return "\n\n".join(sections)


def _pc_control(action: str, query: str, content: str) -> str:
    action = (action or "").strip().lower()
    if action in {"pc_info", "pc_bilgi", "system"}:
        return sys_info("all")
    if action in {"open_app", "app_ac", "uygulama_ac"}:
        return open_app(query)
    if action in {"open_path", "dosya_ac"}:
        path = os.path.expanduser(query or "")
        if not path:
            return "Açılacak dosya/klasör eksik."
        return _run(["open", path], timeout=10) or "Açıldı."
    if action in {"search_files", "dosya_ara"}:
        return _search_files(query)
    if action in {"lock", "kilitle"}:
        return _run(["/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession", "-suspend"], timeout=10) or "Mac kilitlendi."
    if action in {"sleep_display", "ekrani_uyut"}:
        return _run(["pmset", "displaysleepnow"], timeout=10) or "Ekran uyutuldu."
    if action in {"volume", "ses"}:
        try:
            volume = max(0, min(100, int(query or content or 80)))
        except Exception:
            volume = 80
        out = _run(["osascript", "-e", f"set volume output volume {volume}"], timeout=5)
        if out and "syntax error" in out.lower():
            _open_url("x-apple.systempreferences:com.apple.Sound-Settings.extension")
            return "Ses ayarı ekranı açıldı. Bu Mac'te AppleScript ses komutu desteklenmedi."
        return out or f"Ses {volume} yapıldı."
    if action in {"safe_command", "komut"}:
        return _safe_shell(content or query)
    return "PC kontrol için: pc_info, open_app, open_path, search_files, lock, sleep_display, volume, safe_command."


def day_assistant(
    action: str,
    query: str = "",
    content: str = "",
    location: str = "",
) -> str:
    action = (action or "daily_briefing").strip().lower()

    if action in {"daily", "daily_briefing", "gun_ozeti", "gün_özeti", "briefing"}:
        return _daily_briefing(location)
    if action in {"notes", "notlar", "list_notes", "not_listele", "create_note", "not_ekle", "note_create", "open_notes"}:
        return _notes(action, query, content)
    if action in {"contacts", "kisiler", "kişiler", "contact_search", "kisi_ara", "kişi_ara"}:
        return _contacts(query)
    if action in {"photos", "fotolar", "fotoğraflar", "open_photos", "search_photos", "foto_ara"}:
        return _photos(action, query)
    if action in {"files", "dosyalar", "search_files", "dosya_ara"}:
        return _search_files(query)
    if action in {"location", "konum"}:
        return _location()
    if action in {"devices", "aygitlar", "aygıtlar", "homekit", "home"}:
        return _devices()
    if action in {"apple_account", "apple_hesap", "icloud"}:
        return _apple_account()
    if action in {"pc", "pc_control", "pc_kontrol", "mac_control", "mac_kontrol"}:
        return _pc_control(query, content, location)

    # PC control sub-actions can be passed directly as action too.
    if action in {"pc_info", "pc_bilgi", "open_app", "app_ac", "uygulama_ac", "open_path", "dosya_ac", "search_files", "dosya_ara", "lock", "kilitle", "sleep_display", "ekrani_uyut", "volume", "ses", "safe_command", "komut"}:
        return _pc_control(action, query, content)

    return "Gün asistanı hazır: daily_briefing, notes, contacts, photos, files, location, devices, apple_account, pc_control."
