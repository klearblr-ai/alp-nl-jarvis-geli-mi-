from __future__ import annotations

import subprocess


def _osascript(script: str, timeout: int = 15) -> str:
    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if result.returncode != 0:
        return (result.stderr or result.stdout or "Apple komutu tamamlanamadi.").strip()
    return (result.stdout or "").strip()


def apple_integration(action: str = "open_shortcuts", shortcut_name: str = "", input_text: str = "") -> str:
    action = (action or "open_shortcuts").strip().lower()
    shortcut_name = (shortcut_name or "").strip()
    input_text = (input_text or "").strip()

    if action in {"open_shortcuts", "shortcuts", "kestirmeler"}:
        subprocess.run(["open", "-a", "Shortcuts"], capture_output=True, timeout=8)
        return "Kestirmeler uygulaması açıldı."

    if action in {"open_siri_settings", "siri_settings", "siri_ayar"}:
        subprocess.run(["open", "x-apple.systempreferences:com.apple.Siri-Settings.extension"], capture_output=True, timeout=8)
        return "Siri ayarları açıldı."

    if action in {"run_shortcut", "shortcut_run", "kestirme_calistir", "kestirme_çalıştır"}:
        if not shortcut_name:
            return "Çalıştırılacak kestirme adı gerekli."
        if input_text:
            script = f'''
tell application "Shortcuts Events"
    run shortcut "{shortcut_name}" with input "{input_text}"
end tell
'''
        else:
            script = f'''
tell application "Shortcuts Events"
    run shortcut "{shortcut_name}"
end tell
'''
        out = _osascript(script, timeout=30)
        return out or f"Kestirme çalıştırıldı: {shortcut_name}"

    if action in {"create_hint", "siri_hint", "kurulum"}:
        return (
            "Siri entegrasyonu için Kestirmeler'de bir kestirme oluştur: adı 'Hey JARVIS' olabilir. "
            "Sonra Siri'de bu kestirmeyi adıyla çağırabilirsin. JARVIS içinden de apple_integration run_shortcut ile çalışır."
        )

    return "Apple entegrasyonu: open_shortcuts, open_siri_settings, run_shortcut veya create_hint kullan."
