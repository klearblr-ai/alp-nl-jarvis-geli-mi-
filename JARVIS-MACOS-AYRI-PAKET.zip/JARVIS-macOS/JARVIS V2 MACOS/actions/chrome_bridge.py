from __future__ import annotations

import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable
from urllib.parse import parse_qs, urlparse

from app_config import get_app_config_value, save_app_config


StatusProvider = Callable[[], dict]
PayloadHandler = Callable[[dict], dict]


def get_or_create_chrome_bridge_token() -> str:
    token = str(get_app_config_value("chrome_bridge_token", "") or "").strip()
    if token:
        return token
    token = secrets.token_urlsafe(24)
    save_app_config({"chrome_bridge_token": token})
    return token


class ChromeBridgeServer:
    def __init__(
        self,
        port: int,
        token: str,
        status_provider: StatusProvider,
        on_content_event: PayloadHandler,
        on_command: PayloadHandler,
    ):
        self.port = int(port or 8787)
        self.token = token
        self.status_provider = status_provider
        self.on_content_event = on_content_event
        self.on_command = on_command
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> str:
        if self._server:
            return "already_active"

        outer = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "JarvisChromeBridge/1.0"

            def log_message(self, fmt, *args):
                return

            def _headers(self, status: int = 200):
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, X-JARVIS-Token")
                self.end_headers()

            def _send(self, payload: dict, status: int = 200):
                self._headers(status)
                self.wfile.write(json.dumps(payload, ensure_ascii=False).encode("utf-8"))

            def _read_json(self) -> dict:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0:
                    return {}
                raw = self.rfile.read(min(length, 1024 * 128))
                try:
                    payload = json.loads(raw.decode("utf-8"))
                    return payload if isinstance(payload, dict) else {}
                except Exception:
                    return {}

            def _token_from_request(self, payload: dict | None = None) -> str:
                parsed = urlparse(self.path)
                query_token = parse_qs(parsed.query).get("token", [""])[0]
                header_token = self.headers.get("X-JARVIS-Token", "")
                body_token = ""
                if isinstance(payload, dict):
                    body_token = str(payload.get("token", "") or "")
                return str(header_token or query_token or body_token or "").strip()

            def _authorized(self, payload: dict | None = None) -> bool:
                supplied = self._token_from_request(payload)
                return bool(outer.token) and secrets.compare_digest(supplied, outer.token)

            def do_OPTIONS(self):
                self._headers(204)

            def do_GET(self):
                parsed = urlparse(self.path)
                if parsed.path == "/health":
                    self._send({"ok": True, "app": "JARVIS"})
                    return
                if parsed.path != "/status":
                    self._send({"ok": False, "error": "unknown endpoint"}, 404)
                    return
                if not self._authorized({}):
                    self._send({"ok": False, "error": "unauthorized"}, 401)
                    return
                try:
                    payload = dict(outer.status_provider() or {})
                    payload.update({"ok": True, "app": "JARVIS"})
                    self._send(payload)
                except Exception as exc:
                    self._send({"ok": False, "error": str(exc)}, 500)

            def do_POST(self):
                parsed = urlparse(self.path)
                payload = self._read_json()
                if not self._authorized(payload):
                    self._send({"ok": False, "error": "unauthorized"}, 401)
                    return
                try:
                    if parsed.path == "/content-event":
                        self._send(dict(outer.on_content_event(payload) or {"ok": True}))
                    elif parsed.path == "/command":
                        self._send(dict(outer.on_command(payload) or {"ok": True}))
                    else:
                        self._send({"ok": False, "error": "unknown endpoint"}, 404)
                except Exception as exc:
                    self._send({"ok": False, "error": str(exc)}, 500)

        self._server = ThreadingHTTPServer(("127.0.0.1", self.port), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return "ok"

    def stop(self) -> None:
        if not self._server:
            return
        try:
            self._server.shutdown()
            self._server.server_close()
        finally:
            self._server = None
            self._thread = None
