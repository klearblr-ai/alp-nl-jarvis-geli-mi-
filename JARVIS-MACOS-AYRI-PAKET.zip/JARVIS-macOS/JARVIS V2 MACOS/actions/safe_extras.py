from __future__ import annotations

import datetime as dt
import hashlib
import secrets
import string
import subprocess
from pathlib import Path

import psutil

from actions.reminders import add_reminder
from app_config import load_app_config
from actions.chrome_bridge import get_or_create_chrome_bridge_token


def _open(url: str) -> None:
    try:
        subprocess.run(["open", url], capture_output=True, timeout=8)
    except Exception:
        pass


def _human_size(value: int) -> str:
    size = float(value)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


def _resolve_user_path(raw: str) -> Path:
    value = (raw or "").strip()
    if not value:
        raise ValueError("Dosya yolu belirtilmedi.")
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = Path.home() / path
    return path


def _lock_screen() -> str:
    commands = [
        ["/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession", "-suspend"],
        ["pmset", "displaysleepnow"],
    ]
    for command in commands:
        try:
            subprocess.run(command, capture_output=True, timeout=5)
            return "macOS kilit ekranına geçiliyor."
        except Exception:
            continue
    return "Kilit ekranı komutu çalışmadı."


def _duplicate_preview() -> str:
    roots = [Path.home() / "Downloads", Path.home() / "Desktop"]
    groups: dict[tuple[str, int], list[Path]] = {}
    for root in roots:
        if not root.exists():
            continue
        for item in root.rglob("*"):
            try:
                if item.is_file():
                    stat = item.stat()
                    key = (item.name.lower(), int(stat.st_size))
                    groups.setdefault(key, []).append(item)
            except Exception:
                pass
    duplicates = [paths for paths in groups.values() if len(paths) > 1]
    if not duplicates:
        return "Downloads ve Desktop içinde aynı ad+boyutta kopya dosya bulmadım."
    lines = ["Kopya dosya adayları (silmedim, sadece gösteriyorum):"]
    for paths in duplicates[:8]:
        lines.append("- " + " | ".join(str(path) for path in paths[:3]))
    return "\n".join(lines)


def safe_extra_feature(action: str = "menu", query: str = "", amount: int = 0) -> str:
    action = (action or "menu").strip().lower()
    query = (query or "").strip()

    if action in {"menu", "list", "hepsi"}:
        return (
            "20 güvenli ekstra: password, focus_timer, privacy_settings, clipboard_clear, "
            "cleanup_preview, battery_tip, app_usage, export_settings, emergency_card, network_panel, "
            "virustotal, chrome_extension, permission_check, file_hash, quick_note, break_timer, "
            "duplicate_preview, safe_folder, lock_screen, app_quit."
        )

    if action == "password":
        length = max(12, min(64, int(amount or 20)))
        alphabet = string.ascii_letters + string.digits + "!@#$%*-_=+"
        password = "".join(secrets.choice(alphabet) for _ in range(length))
        return f"Güvenli parola üretildi: {password}"

    if action == "focus_timer":
        minutes = max(5, min(180, int(amount or 25)))
        due = dt.datetime.now() + dt.timedelta(minutes=minutes)
        return add_reminder(f"Odak süresi bitti ({minutes} dk)", due.isoformat(timespec="minutes"))

    if action == "privacy_settings":
        _open("x-apple.systempreferences:com.apple.preference.security?Privacy")
        return "Gizlilik ve güvenlik ayarları açıldı."

    if action == "clipboard_clear":
        try:
            subprocess.run("pbcopy </dev/null", shell=True, capture_output=True, timeout=5)
            return "Pano temizlendi."
        except Exception as exc:
            return f"Pano temizlenemedi: {exc}"

    if action == "cleanup_preview":
        roots = [Path.home() / "Downloads", Path.home() / "Desktop"]
        files = []
        for root in roots:
            if not root.exists():
                continue
            for item in root.rglob("*"):
                try:
                    if item.is_file():
                        files.append((item.stat().st_size, item))
                except Exception:
                    pass
        files.sort(reverse=True)
        if not files:
            return "Temizlenecek büyük dosya bulamadım."
        lines = ["En büyük dosyalar (silmedim, sadece gösteriyorum):"]
        for size, path in files[:10]:
            lines.append(f"- {_human_size(size)} {path}")
        return "\n".join(lines)

    if action == "battery_tip":
        battery = psutil.sensors_battery()
        if not battery:
            return "Pil bilgisi alınamadı."
        plugged = "şarjda" if battery.power_plugged else "bataryada"
        return f"Pil %{battery.percent:.0f}, {plugged}. Düşük güç için 'düşük güce al' diyebilirsin."

    if action == "app_usage":
        procs = []
        for proc in psutil.process_iter(["name", "cpu_percent", "memory_info"]):
            try:
                info = proc.info
                mem = int(getattr(info.get("memory_info"), "rss", 0) or 0)
                procs.append((mem, info.get("name") or "unknown"))
            except Exception:
                pass
        procs.sort(reverse=True)
        return "En çok RAM kullananlar:\n" + "\n".join(f"- {_human_size(mem)} {name}" for mem, name in procs[:8])

    if action == "export_settings":
        cfg = dict(load_app_config())
        if cfg.get("gemini_api_key"):
            cfg["gemini_api_key"] = "***"
        out = Path.home() / "Desktop" / "JARVIS-ayar-ozeti.txt"
        lines = [f"{key}: {value}" for key, value in sorted(cfg.items())]
        out.write_text("\n".join(lines), encoding="utf-8")
        return f"Ayar özeti masaüstüne yazıldı: {out}"

    if action == "emergency_card":
        cfg = load_app_config()
        phone = cfg.get("owner_phone") or cfg.get("home_security_phone") or ""
        email = cfg.get("owner_email") or ""
        return f"Acil kart: Telefon {phone or 'yok'}, E-posta {email or 'yok'}."

    if action == "network_panel":
        _open("x-apple.systempreferences:com.apple.Network-Settings.extension")
        return "Ağ ayarları açıldı."

    if action == "virustotal":
        _open("https://www.virustotal.com/gui/home/upload")
        return "VirusTotal yükleme sayfası açıldı: https://www.virustotal.com/gui/home/upload"

    if action == "chrome_extension":
        folder = Path(__file__).resolve().parent.parent / "chrome_extension"
        token = get_or_create_chrome_bridge_token()
        return (
            f"Chrome uzantı klasörü: {folder}\n"
            f"JARVIS köprü tokeni: {token}\n"
            "Chrome'da chrome://extensions aç, Developer mode'u aç, Load unpacked ile bu klasörü seç."
        )

    if action == "permission_check":
        return (
            "İzin kontrol listesi: Kamera, Mikrofon, Erişilebilirlik, Ekran Kaydı, "
            "Takvim, Anımsatıcılar, Kişiler, Fotoğraflar, Konum ve Mesajlar izinlerini "
            "Sistem Ayarları > Gizlilik ve Güvenlik bölümünden kontrol et."
        )

    if action == "file_hash":
        try:
            path = _resolve_user_path(query)
            if not path.is_file():
                return f"Dosya bulunamadı: {path}"
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
            return f"SHA-256: {digest.hexdigest()}\nDosya: {path}"
        except Exception as exc:
            return f"Dosya hash alınamadı: {exc}"

    if action == "quick_note":
        text = query.strip()
        if not text:
            return "Not metni belirtmedin."
        folder = Path.home() / "Documents" / "JARVIS"
        folder.mkdir(parents=True, exist_ok=True)
        out = folder / "quick-notes.txt"
        line = f"{dt.datetime.now().isoformat(timespec='minutes')} - {text}\n"
        with out.open("a", encoding="utf-8") as handle:
            handle.write(line)
        return f"Hızlı not eklendi: {out}"

    if action == "break_timer":
        minutes = max(5, min(180, int(amount or 20)))
        due = dt.datetime.now() + dt.timedelta(minutes=minutes)
        return add_reminder(f"Göz ve duruş molası ({minutes} dk)", due.isoformat(timespec="minutes"))

    if action == "duplicate_preview":
        return _duplicate_preview()

    if action == "safe_folder":
        folder = Path.home() / "Documents" / "JARVIS-Safe"
        folder.mkdir(parents=True, exist_ok=True)
        _open(str(folder))
        return f"Güvenli çalışma klasörü hazır: {folder}"

    if action == "lock_screen":
        return _lock_screen()

    if action == "app_quit":
        app = query.strip().replace('"', "")
        if not app:
            return "Kapatılacak uygulama adını yaz."
        try:
            script = f'tell application "{app}" to quit'
            result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=8)
            if result.returncode == 0:
                return f"{app} kapatma komutu gönderildi."
            return f"{app} kapatılamadı: {result.stderr.strip() or result.stdout.strip()}"
        except Exception as exc:
            return f"{app} kapatılamadı: {exc}"

    return "Bilinmeyen ekstra. '20 güvenli özellik' de, listeyi göstereyim."
