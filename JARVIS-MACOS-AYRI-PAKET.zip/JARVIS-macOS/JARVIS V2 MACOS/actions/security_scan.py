from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parents[1]
QUARANTINE_DIR = BASE_DIR / "quarantine"

SUSPICIOUS_SUFFIXES = {
    ".command",
    ".pkg",
    ".dmg",
    ".sh",
    ".app",
    ".scpt",
    ".py",
    ".js",
}

SUSPICIOUS_MARKERS = (
    "curl ",
    "wget ",
    "base64",
    "chmod +x",
    "osascript",
    "launchctl",
    "rm -rf",
    "nc ",
    "netcat",
    "python -c",
    "python3 -c",
)


def _safe_scan_roots(path: str = "") -> list[Path]:
    raw = (path or "").strip()
    if raw:
        root = Path(raw).expanduser().resolve()
        home = Path.home().resolve()
        if root == Path("/").resolve() or str(root) in {"/System", "/bin", "/usr", "/Library"}:
            return [home / "Downloads", home / "Desktop", home / "Documents"]
        return [root]
    home = Path.home()
    return [home / "Downloads", home / "Desktop", home / "Documents", BASE_DIR]


def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 512), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def _looks_suspicious(path: Path) -> tuple[bool, str]:
    try:
        if path.is_dir():
            return path.suffix.lower() == ".app", "app paketi kontrol edilmeli"
        if path.stat().st_size > 8 * 1024 * 1024:
            return False, ""
        suffix = path.suffix.lower()
        if suffix not in SUSPICIOUS_SUFFIXES:
            return False, ""
        text = path.read_text(encoding="utf-8", errors="ignore").lower()
        hits = [marker for marker in SUSPICIOUS_MARKERS if marker in text]
        if len(hits) >= 2:
            return True, "supheli komutlar: " + ", ".join(hits[:4])
        if os.access(path, os.X_OK) and suffix in {".sh", ".command", ".py", ".js"} and hits:
            return True, "calistirilabilir dosyada supheli komut: " + hits[0]
    except Exception:
        return False, ""
    return False, ""


def _quarantine(path: Path, reason: str) -> str:
    QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)
    target = QUARANTINE_DIR / f"{path.name}.{_hash_file(path) if path.is_file() else 'app'}.quarantine"
    try:
        shutil.move(str(path), str(target))
        try:
            subprocess.run(["xattr", "-w", "com.apple.quarantine", "0081;JARVIS;SecurityScan;", str(target)], capture_output=True, timeout=5)
        except Exception:
            pass
        return f"Karantinaya alındı: {path} -> {target} ({reason})"
    except Exception as exc:
        return f"Karantinaya alınamadı: {path} ({exc})"


def security_scan(action: str = "scan", path: str = "", quarantine: bool = True, max_files: int = 800) -> str:
    action = (action or "scan").strip().lower()
    if action in {"open_quarantine", "karantina"}:
        QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)
        subprocess.run(["open", str(QUARANTINE_DIR)], capture_output=True, timeout=5)
        return f"Karantina klasörü açıldı: {QUARANTINE_DIR}"

    if action not in {"scan", "tara", "quarantine", "temizle", "clean"}:
        return "Güvenlik tarama: scan, clean veya open_quarantine kullan."

    should_quarantine = bool(quarantine) or action in {"quarantine", "temizle", "clean"}
    scanned = 0
    found: list[tuple[Path, str]] = []
    roots = [root for root in _safe_scan_roots(path) if root.exists()]
    for root in roots:
        for item in root.rglob("*"):
            if scanned >= max_files:
                break
            try:
                if QUARANTINE_DIR in item.parents:
                    continue
                if item.is_file() or item.suffix.lower() == ".app":
                    scanned += 1
                    suspicious, reason = _looks_suspicious(item)
                    if suspicious:
                        found.append((item, reason))
            except Exception:
                continue

    if not found:
        return f"Tarama tamam: {scanned} dosya bakıldı, belirgin şüpheli dosya bulmadım."

    lines = [f"Tarama tamam: {scanned} dosya bakıldı, {len(found)} şüpheli öğe bulundu."]
    if should_quarantine:
        for item, reason in found[:20]:
            lines.append("- " + _quarantine(item, reason))
        lines.append("Not: Sistem dosyası silmedim; şüphelileri karantinaya aldım.")
    else:
        for item, reason in found[:20]:
            lines.append(f"- {item} ({reason})")
    return "\n".join(lines)
