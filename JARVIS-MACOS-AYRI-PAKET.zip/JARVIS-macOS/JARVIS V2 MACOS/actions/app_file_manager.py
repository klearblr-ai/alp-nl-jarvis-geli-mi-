from __future__ import annotations

import os
import shutil
import subprocess
import urllib.parse
import urllib.request
from pathlib import Path


DOWNLOAD_DIR = Path.home() / "Downloads" / "JARVIS"
TRASH_DIR = Path.home() / ".Trash"

BLOCKED_DELETE_ROOTS = {
    Path("/"),
    Path("/System"),
    Path("/Library"),
    Path("/usr"),
    Path("/bin"),
    Path("/sbin"),
    Path("/private"),
    Path("/Applications"),
}


def _open_path(path: Path) -> None:
    try:
        subprocess.run(["open", str(path)], capture_output=True, timeout=8)
    except Exception:
        pass


def _safe_filename_from_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    name = Path(urllib.parse.unquote(parsed.path)).name
    if not name or "." not in name:
        name = "jarvis-download"
    return "".join(ch for ch in name if ch.isalnum() or ch in "._- ")[:120] or "jarvis-download"


def app_file_manager(action: str = "app_store_search", url: str = "", app_name: str = "", open_after: bool = True) -> str:
    action = (action or "app_store_search").strip().lower()
    url = (url or "").strip()
    app_name = (app_name or "").strip()

    if action in {"app_store_search", "appstore", "uygulama_ara", "uygulama_indir"}:
        query = app_name or url
        if not query:
            subprocess.run(["open", "-a", "App Store"], capture_output=True, timeout=8)
            return "App Store açıldı."
        search_url = "macappstore://search.itunes.apple.com/WebObjects/MZSearch.woa/wa/search?media=software&term=" + urllib.parse.quote(query)
        subprocess.run(["open", search_url], capture_output=True, timeout=8)
        return f"App Store araması açıldı: {query}"

    if action in {"download_url", "indir", "download"}:
        if not url.lower().startswith(("https://", "http://")):
            return "İndirmek için güvenli bir http/https linki gerekli."
        DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
        name = _safe_filename_from_url(url)
        target = DOWNLOAD_DIR / name
        counter = 1
        while target.exists():
            target = DOWNLOAD_DIR / f"{Path(name).stem}-{counter}{Path(name).suffix}"
            counter += 1
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "JARVIS/1.0"})
            with urllib.request.urlopen(req, timeout=45) as response, target.open("wb") as out:
                shutil.copyfileobj(response, out)
        except Exception as exc:
            return f"Dosya indirilemedi: {exc}"
        if open_after:
            _open_path(target)
        return f"Dosya indirildi: {target}"

    if action in {"open_downloads", "indirilenleri_ac", "indirilenleri_aç"}:
        DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
        _open_path(DOWNLOAD_DIR)
        return f"JARVIS indirilenler klasörü açıldı: {DOWNLOAD_DIR}"

    return "Uygulama indirme: app_store_search, download_url veya open_downloads kullan."


def _is_blocked_delete_path(path: Path) -> bool:
    try:
        resolved = path.expanduser().resolve()
    except Exception:
        return True
    for blocked in BLOCKED_DELETE_ROOTS:
        try:
            if resolved == blocked or blocked in resolved.parents:
                return True
        except Exception:
            continue
    return False


def file_delete(action: str = "trash", path: str = "", confirmation: str = "") -> str:
    action = (action or "trash").strip().lower()
    raw_path = (path or "").strip()
    if not raw_path:
        return "Silinecek dosya yolu gerekli."
    target = Path(raw_path).expanduser()
    if not target.exists():
        return f"Dosya bulunamadı: {target}"
    if _is_blocked_delete_path(target):
        return "Bu yol güvenlik için engellendi. Sistem, uygulama veya kök klasörleri silemem."

    if action in {"trash", "cope_at", "çöpe_at", "sil"}:
        TRASH_DIR.mkdir(exist_ok=True)
        dest = TRASH_DIR / target.name
        counter = 1
        while dest.exists():
            dest = TRASH_DIR / f"{target.stem}-{counter}{target.suffix}"
            counter += 1
        try:
            shutil.move(str(target), str(dest))
            return f"Dosya çöp kutusuna taşındı: {dest}"
        except Exception as exc:
            return f"Dosya çöp kutusuna taşınamadı: {exc}"

    if action in {"permanent_delete", "kalici_sil", "kalıcı_sil"}:
        normalized = confirmation.strip().lower()
        if normalized not in {"kalıcı silmeyi onaylıyorum", "kalici silmeyi onayliyorum", "permanent delete confirmed"}:
            return "Kalıcı silme için confirmation alanına 'kalıcı silmeyi onaylıyorum' yazılmalı."
        try:
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
            return f"Dosya kalıcı silindi: {target}"
        except Exception as exc:
            return f"Kalıcı silme başarısız: {exc}"

    return "Dosya silme: trash veya permanent_delete kullan."
