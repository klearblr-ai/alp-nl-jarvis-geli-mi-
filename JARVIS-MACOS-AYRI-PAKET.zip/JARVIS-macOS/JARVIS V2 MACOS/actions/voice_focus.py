from __future__ import annotations

from app_config import get_app_config_value, save_app_config


def voice_focus_control(action: str = "on", hold_seconds: int = 14, noise_gate: int = 650) -> str:
    action = (action or "on").strip().lower()
    if action in {"on", "enable", "focus", "sesime_odaklan", "sesime odaklan"}:
        hold = max(5, min(60, int(hold_seconds or 14)))
        gate = max(200, min(6000, int(noise_gate or 650)))
        save_app_config({
            "voice_focus_enabled": True,
            "voice_focus_requires_wake": True,
            "voice_focus_hold_seconds": hold,
            "voice_focus_noise_gate": gate,
            "sound_detection_enabled": True,
            "sound_detection_threshold": gate,
            "far_field_microphone": True,
        })
        return (
            "Sesime odaklan modu açıldı. JARVIS artık özellikle 'hey jarvis' tetiklemesinden sonra "
            f"{hold} saniye ses kabul edecek ve düşük/uzak gürültüleri filtreleyecek."
        )

    if action in {"ultra", "maximum", "max", "maksimum", "maksimumu_kir", "maksimumu kır"}:
        save_app_config({
            "voice_focus_enabled": True,
            "voice_focus_requires_wake": False,
            "voice_focus_hold_seconds": 60,
            "voice_focus_noise_gate": 120,
            "voice_focus_max_rms": 32767,
            "sound_detection_enabled": True,
            "sound_detection_threshold": 120,
            "far_field_microphone": True,
            "audio_input_gain": 4.0,
        })
        return "Ultra ses algılama açıldı. Mikrofon kazancı yükseldi, eşik düştü; çok uzaktaki sesleri bile yakalamaya çalışacağım."

    if action in {"off", "disable", "normal", "kapat"}:
        save_app_config({
            "voice_focus_enabled": False,
            "voice_focus_requires_wake": False,
            "sound_detection_threshold": 450,
        })
        return "Ses odak modu kapatıldı. Normal dinleme moduna döndüm."

    if action in {"status", "durum"}:
        enabled = bool(get_app_config_value("voice_focus_enabled", False))
        hold = get_app_config_value("voice_focus_hold_seconds", 14)
        gate = get_app_config_value("voice_focus_noise_gate", 650)
        return f"Ses odak modu: {'açık' if enabled else 'kapalı'}. Bekleme: {hold} sn, gürültü eşiği: {gate}."

    return "Ses odak komutu: on, off veya status kullan."
