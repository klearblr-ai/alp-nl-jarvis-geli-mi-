#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.safe_extras import safe_extra_feature
print(safe_extra_feature("chrome_extension"))
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
