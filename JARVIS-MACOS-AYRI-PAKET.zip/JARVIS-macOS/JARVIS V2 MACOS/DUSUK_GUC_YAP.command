#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.system_mode import system_mode
print(system_mode("low_power_on"))
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
