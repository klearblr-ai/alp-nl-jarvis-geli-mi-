#!/bin/bash

cd "$(dirname "$0")" || exit 1

if [ -d "venv" ]; then
    source venv/bin/activate
fi

PYTHON_BIN="python"
if ! command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python3"
fi

"$PYTHON_BIN" - <<'PY'
import pyaudio

pya = pyaudio.PyAudio()
try:
    try:
        default_index = int(pya.get_default_input_device_info().get("index"))
    except Exception:
        default_index = -1

    print("Mikrofonlar:")
    print("")
    found = False
    for idx in range(pya.get_device_count()):
        info = pya.get_device_info_by_index(idx)
        channels = int(info.get("maxInputChannels", 0) or 0)
        if channels <= 0:
            continue
        found = True
        mark = "  <- varsayılan" if idx == default_index else ""
        print(f"{idx}: {info.get('name', '')} ({channels} kanal){mark}")
    if not found:
        print("Mikrofon bulunamadı.")
finally:
    pya.terminate()

print("")
print("Belirli mikrofon adı istersen config/api_keys.json içinde audio_input_device alanına cihaz adının bir parçasını yaz.")
input("Kapatmak için Enter'a bas...")
PY
