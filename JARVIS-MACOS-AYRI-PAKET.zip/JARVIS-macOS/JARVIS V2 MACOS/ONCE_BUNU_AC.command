#!/bin/bash
# JARVIS kolay başlatıcı

cd "$(dirname "$0")" || exit 1

clear
echo "JARVIS kolay başlatıcı"
echo ""

xattr -r -d com.apple.quarantine "$(pwd)" 2>/dev/null || true
chmod +x ./*.command ./*.sh 2>/dev/null || true

if [ ! -d "venv" ]; then
    echo "JARVIS kurulmamış görünüyor."
    echo "Kurulum biraz sürebilir; internet gerekebilir."
    echo ""
    read -p "Şimdi kurulsun mu? (e/h): " choice
    if [[ "$choice" == "e" || "$choice" == "E" ]]; then
        ./KUR.command
    else
        echo "Kurulum yapılmadı."
        read -p "Kapatmak için Enter'a bas..."
        exit 1
    fi
else
    ./BASLAT.command
fi
