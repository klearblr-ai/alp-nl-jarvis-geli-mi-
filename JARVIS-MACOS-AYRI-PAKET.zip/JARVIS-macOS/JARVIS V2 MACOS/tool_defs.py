"""
JARVIS — Gemini Live araç (tool) tanımları
Masaüstü (main.py) ve web sunucusu (jarvis_web/server.py) ortak kullanır.
"""

TOOL_DECLARATIONS = [
    {
        "name": "open_app",
        "description": "macOS'ta herhangi bir uygulamayı açar. Spotify, Safari, Terminal, Finder, VS Code vb.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "app_name": {
                    "type": "STRING",
                    "description": "Uygulama adı (örn. 'Spotify', 'Safari', 'Terminal')"
                }
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "sys_info",
        "description": "Sistem bilgisi alır: pil durumu, CPU, RAM, disk, saat, tarih, ağ bağlantısı.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "battery | cpu | ram | disk | time | date | network | all"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_weather",
        "description": (
            "Anlik hava durumunu ozetler. Varsayilan konum Istanbul'dur. "
            "Kullanici hava durumunu, sicakligi veya yagmur durumunu sordugunda kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "location": {
                    "type": "STRING",
                    "description": "Sehir veya konum. Bos birakilirsa Istanbul kullanilir."
                }
            }
        }
    },
    {
        "name": "get_calendar_events",
        "description": (
            "Apple Calendar takvimini okur. "
            "Bugun, yarin, siradaki etkinlik veya yaklasan ajandayi ozetler. "
            "Kullanici toplanti, takvim, ajanda, etkinlik veya gunluk programini sordugunda kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": (
                        "today | tomorrow | next | agenda | week veya dogal dilde "
                        "'onumuzdeki 30 gun', '2 hafta', 'bu ay', 'gelecek ay'"
                    )
                },
                "limit": {
                    "type": "NUMBER",
                    "description": "Maksimum etkinlik sayisi"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "add_calendar_event",
        "description": (
            "Apple Calendar takvimine yeni etkinlik ekler. "
            "Kullanici toplanti, randevu, takvime ekleme veya etkinlik olusturma isterse kullan. "
            "Baslangic tarihini gercek tarih/saat olarak ver; bitis verilmezse varsayilan sure kullanilir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Etkinlik basligi. Ornek: 'Disci Randevusu'"
                },
                "start_iso": {
                    "type": "STRING",
                    "description": "Baslangic tarih/saat. ISO veya yyyy-MM-dd HH:mm formatinda."
                },
                "end_iso": {
                    "type": "STRING",
                    "description": "Bitis tarih/saat. Opsiyonel."
                },
                "location": {
                    "type": "STRING",
                    "description": "Etkinlik konumu. Opsiyonel."
                },
                "notes": {
                    "type": "STRING",
                    "description": "Etkinlik notlari. Opsiyonel."
                },
                "calendar_name": {
                    "type": "STRING",
                    "description": "Eklenecek takvim adi. Opsiyonel."
                },
                "all_day": {
                    "type": "BOOLEAN",
                    "description": "true ise tum gun etkinligi olusturur."
                }
            },
            "required": ["title", "start_iso"]
        }
    },
    {
        "name": "delete_calendar_event",
        "description": (
            "Apple Calendar takviminden etkinlik siler. "
            "Kullanici bir toplantiyi, randevuyu veya takvim kaydini silmek istediginde kullan. "
            "Ayni ada birden fazla etkinlik varsa dogru kaydi bulmak icin baslangic tarihini gercek tarih/saat olarak ver."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Silinecek etkinlik basligi. Ornek: 'Disci Randevusu'"
                },
                "start_iso": {
                    "type": "STRING",
                    "description": "Opsiyonel tarih/saat. Ayni isimli birden fazla etkinligi ayirt etmek icin kullan."
                },
                "calendar_name": {
                    "type": "STRING",
                    "description": "Opsiyonel takvim adi"
                },
                "delete_all_matches": {
                    "type": "BOOLEAN",
                    "description": "true ise eslesen tum etkinlikleri siler"
                }
            },
            "required": ["title"]
        }
    },
    {
        "name": "get_reminders",
        "description": (
            "Apple Animsaticilar listesini okur. "
            "Bugunku, yaklasan, geciken veya tum acik animsaticilari ozetler. "
            "Kullanici hatirlatma, animsatici, reminder veya yapilacaklar listesini sordugunda kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "today | upcoming | overdue | all | next"
                },
                "limit": {
                    "type": "NUMBER",
                    "description": "Maksimum animsatici sayisi"
                },
                "list_name": {
                    "type": "STRING",
                    "description": "Istenirse belirli bir animsatici listesi adi"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "add_reminder",
        "description": (
            "Apple Animsaticilar uygulamasina yeni bir animsatici ekler. "
            "Kullanici 'hatirlat', 'animsatici ekle', 'reminder kur' dediginde kullan. "
            "Goreli zaman ifadelerini bugunku tarih baglamina gore due_iso alanina ISO formatinda cevir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Animsatici basligi"
                },
                "due_iso": {
                    "type": "STRING",
                    "description": "Opsiyonel tarih/saat. Ornek: 2026-04-13T09:00 veya tum gun icin 2026-04-13"
                },
                "notes": {
                    "type": "STRING",
                    "description": "Opsiyonel not"
                },
                "list_name": {
                    "type": "STRING",
                    "description": "Opsiyonel animsatici listesi"
                },
                "priority": {
                    "type": "STRING",
                    "description": "low | medium | high"
                },
                "all_day": {
                    "type": "BOOLEAN",
                    "description": "Tum gun animsatici ise true"
                }
            },
            "required": ["title"]
        }
    },
    {
        "name": "delete_reminder",
        "description": (
            "Apple Animsaticilar uygulamasindan animsatici siler veya tamamlandi isaretler. "
            "Kullanici 'animsaticiyi sil', 'hatirlatmayi kaldir', 'reminder sil' dediginde kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Silinecek animsatici basligi"
                },
                "list_name": {
                    "type": "STRING",
                    "description": "Opsiyonel animsatici listesi"
                },
                "delete_all_matches": {
                    "type": "BOOLEAN",
                    "description": "true ise eslesen tum animsaticilari siler"
                },
                "complete_only": {
                    "type": "BOOLEAN",
                    "description": "true ise silmek yerine tamamlandi isaretler"
                }
            },
            "required": ["title"]
        }
    },
    {
        "name": "browser_control",
        "description": "Tarayıcıda URL açar, Google'da arama yapar veya YouTube'da ilk sonucu doğrudan oynatır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "open_url | search | play_youtube"},
                "url":    {"type": "STRING", "description": "Açılacak URL (open_url için)"},
                "query":  {"type": "STRING", "description": "Arama sorgusu (search veya play_youtube için)"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "shell_run",
        "description": "macOS terminal komutu çalıştırır. Dosya işlemleri, sistem yönetimi.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "command": {
                    "type": "STRING",
                    "description": "Çalıştırılacak bash komutu"
                }
            },
            "required": ["command"]
        }
    },
    {
        "name": "toggle_webcam",
        "description": (
            "PC/Mac kamerasını güvenli canlı modda açar veya kapatır. "
            "Kayıt yapmaz ve dosyaya görüntü yazmaz. Kullanıcı 'beni gör', 'kamerayı aç', "
            "'odaya bak', 'ne görüyorsun' derse start kullan. "
            "'fotoğraf çek', 'foto çek' derse capture_photo kullan. "
            "'yüz karesi al' derse capture_face_frame; 'video karesi al' derse capture_video_frame kullan. "
            "'video kaydı al', 'kayıt al' derse record_video kullan. "
            "'kim bu yüz', 'yüz kim' derse identify_face kullan. "
            "'JARVIS gizlilik', 'kamerayı kapat', 'artık bakma' derse privacy kullan. "
            "'gece görüşü', 'gece görüş modu' derse night_vision_on; 'gece görüşü kapat' derse night_vision_off kullan. "
            "'eve yabancı girme', 'ev güvenlik modu', 'odaya biri girerse haber ver' derse security_on kullan. "
            "'yüz ekle', 'bu yüzü tanı', 'tanıdık yüz kaydet' derse enroll_face kullan. "
            "'yüz test', 'yüz algılıyor mu' derse test_face kullan. "
            "'tanıdık yüzleri sil' derse clear_faces, 'tanıdık yüzleri listele' derse list_faces kullan. "
            "security_on aktifken tanıdık olmayan yüz algılanırsa JARVIS acil uyarı verir ve ayarlı numaraya SMS/Mesaj dener."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "start | capture_photo | capture_face_frame | capture_video_frame | record_video | identify_face | privacy | stop | night_vision_on | night_vision_off | security_on | security_off | enroll_face | test_face | list_faces | clear_faces"
                },
                "label": {
                    "type": "STRING",
                    "description": "Yüz kaydedilirken verilecek isteğe bağlı isim/etiket"
                },
                "duration_seconds": {
                    "type": "NUMBER",
                    "description": "Video kaydi icin saniye; varsayilan 10, en fazla 60"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "apple_integration",
        "description": (
            "Apple Kestirmeler ve Siri ayarlari entegrasyonu yapar. "
            "Kullanici Siri ayari, Kestirmeler, Apple entegrasyon veya belirli bir kestirmeyi calistirmak isterse kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "open_shortcuts | open_siri_settings | run_shortcut | create_hint"
                },
                "shortcut_name": {
                    "type": "STRING",
                    "description": "run_shortcut icin kestirme adi"
                },
                "input_text": {
                    "type": "STRING",
                    "description": "Kestirmeye gonderilecek opsiyonel metin"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "security_scan",
        "description": (
            "Mac'te guvenlik taramasi yapar. Supheli dosyalari bulur ve istenirse JARVIS karantina klasorune tasir. "
            "Kullanici 'virus tara', 'virusu temizle', 'guvenli yap', 'karantinaya al' derse kullan. "
            "Sistem dosyalarini rastgele silmez; supheli kullanici dosyalarini karantinaya alir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "scan | clean | open_quarantine"
                },
                "path": {
                    "type": "STRING",
                    "description": "Opsiyonel taranacak klasor; bos ise Downloads/Desktop/Documents/JARVIS taranir"
                },
                "quarantine": {
                    "type": "BOOLEAN",
                    "description": "true ise supheli dosyalari karantinaya alir"
                },
                "max_files": {
                    "type": "NUMBER",
                    "description": "En fazla taranacak dosya sayisi"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "daily_spending",
        "description": (
            "Gunluk para/harcama hesabi tutar. Harcama ekler, bugunku harcama ozetini verir, gunluk butce ayarlar."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "add | summary | budget | clear_today"
                },
                "amount": {
                    "type": "NUMBER",
                    "description": "Harcama veya butce tutari"
                },
                "category": {
                    "type": "STRING",
                    "description": "Kategori: yemek, ulasim, oyun, okul vb."
                },
                "note": {
                    "type": "STRING",
                    "description": "Opsiyonel not"
                },
                "date": {
                    "type": "STRING",
                    "description": "YYYY-MM-DD; bos ise bugun"
                },
                "budget": {
                    "type": "NUMBER",
                    "description": "Gunluk butce tutari"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "system_mode",
        "description": (
            "JARVIS guc modunu degistirir. Kullanici 'dusuk guce al', 'dusuk guc modu', 'normal moda don' derse kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "low_power_on | low_power_off"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "app_file_manager",
        "description": (
            "Uygulama indirme ve dosya indirme yardimcisidir. "
            "Kullanici 'uygulama indir', 'App Store'da ara', 'bu linki indir' derse kullan. "
            "App Store icin arama acabilir; dogrudan URL verilirse Downloads/JARVIS klasorune indirir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "app_store_search | download_url | open_downloads"
                },
                "url": {
                    "type": "STRING",
                    "description": "download_url icin http/https linki veya arama metni"
                },
                "app_name": {
                    "type": "STRING",
                    "description": "App Store'da aranacak uygulama adi"
                },
                "open_after": {
                    "type": "BOOLEAN",
                    "description": "Indirme sonrasi dosyayi/klasoru ac"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "file_delete",
        "description": (
            "Dosyayi cope tasir veya cok acik onay varsa kalici siler. "
            "Kullanici 'dosyayi sil' derse varsayilan olarak trash kullan. "
            "Kalici silme sadece kullanici tam dosya yolu verip acikca 'kalıcı silmeyi onaylıyorum' dediyse permanent_delete ile kullan. "
            "Sistem, Applications, Library, usr, bin veya kok klasorleri silinmez."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "trash | permanent_delete"
                },
                "path": {
                    "type": "STRING",
                    "description": "Silinecek dosya veya klasorun tam yolu"
                },
                "confirmation": {
                    "type": "STRING",
                    "description": "Kalici silme icin tam olarak: kalıcı silmeyi onaylıyorum"
                }
            },
            "required": ["action", "path"]
        }
    },
    {
        "name": "voice_focus_control",
        "description": (
            "Sesime odaklan modunu acar/kapatir. AirPods veya diger mikrofonlarda sistem mikrofon girisini kullanir, "
            "hey jarvis tetiginden sonra kisa sure ses kabul eder ve diger sesleri/gurultuyu filtrelemeye calisir. "
            "Gercek biyometrik ses kimligi iddiasi yapmaz."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "on | off | status | ultra"
                },
                "hold_seconds": {
                    "type": "NUMBER",
                    "description": "Hey jarvis sonrasi ses kabul suresi"
                },
                "noise_gate": {
                    "type": "NUMBER",
                    "description": "Gurultu esigi; yuksek deger daha secici olur"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "device_sync",
        "description": (
            "Ayni API key kullanan Mac/iPhone/Watch companion cihazlari icin esleme durumunu, cihaz listesini "
            "ve komut hazirlamayi yonetir. Tam uzaktan kontrol companion app arka plan baglantisi gerektirir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "status | register | list | control"
                },
                "device_name": {
                    "type": "STRING",
                    "description": "Cihaz adi"
                },
                "device_type": {
                    "type": "STRING",
                    "description": "mac | iphone | watch"
                },
                "command": {
                    "type": "STRING",
                    "description": "Esli cihaza hazirlanacak komut"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "content_filter_control",
        "description": (
            "JARVIS açıkken 18+, korku ve aşırı şiddet içeriklerini ekranda gizlemek için güvenli içerik filtresini açar/kapatır. "
            "Riskli içerik yakalanırsa kullanıcıyı uyarır ve tam ekran kalkanla görüntüyü kapatır."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "on | off | status"
                },
                "auto_close": {
                    "type": "BOOLEAN",
                    "description": "true ise riskli aktif pencereyi Command-W ile kapatmayı dener"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "guardian_lock_control",
        "description": (
            "Yabancı yüz algılanınca JARVIS güvenli kilit modunu yönetir. "
            "Klavye/mouse rehin alma veya yanlış kodda PC kapatma yapmaz; güvenli kalkan ve macOS kilit ekranı kullanır. "
            "Kullanıcı 'kilidi çıkar 1234' derse unlock kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "enable | disable | lock | unlock | status"
                },
                "code": {
                    "type": "STRING",
                    "description": "unlock için güvenlik kodu"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "safe_extra_feature",
        "description": (
            "JARVIS'e eklenen 20 güvenli mini özellik: parola üretme, odak zamanlayıcı, gizlilik ayarı, pano temizleme, "
            "temizlik önizleme, pil ipucu, uygulama kullanım özeti, ayar özeti, acil kart, ağ ayarları, VirusTotal, "
            "Chrome uzantısı/token, izin kontrol listesi, dosya hash, hızlı not, mola zamanlayıcı, kopya dosya önizleme, "
            "güvenli klasör, ekran kilidi ve uygulama kapatma."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "menu | password | focus_timer | privacy_settings | clipboard_clear | cleanup_preview | battery_tip | app_usage | export_settings | emergency_card | network_panel | virustotal | chrome_extension | permission_check | file_hash | quick_note | break_timer | duplicate_preview | safe_folder | lock_screen | app_quit"
                },
                "query": {
                    "type": "STRING",
                    "description": "Dosya yolu, not metni veya uygulama adı gibi opsiyonel metin"
                },
                "amount": {
                    "type": "NUMBER",
                    "description": "Parola uzunluğu veya odak dakikası"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "play_media",
        "description": (
            "YouTube, Spotify veya Apple Music/Music uygulamasında şarkı, müzik veya video açar. "
            "Kullanıcı belirli bir platform söylerse onu kullan. "
            "Belirtmezse uygun olanı dene. "
            "Kullanıcı 'çal', 'oynat', 'aç' diyorsa autoplay=true kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "Şarkı, sanatçı, albüm veya video arama ifadesi"
                },
                "provider": {
                    "type": "STRING",
                    "description": "auto | youtube | spotify | apple_music"
                },
                "autoplay": {
                    "type": "BOOLEAN",
                    "description": "true ise mümkünse doğrudan oynatır"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_youtube_channel_report",
        "description": (
            "YouTube kanalinin public istatistiklerini ve son videolarin performansini raporlar. "
            "Kullanici kanal istatistiklerini, abone sayisini, son videolarini, buyume hizini "
            "veya YouTube analizini sordugunda kullan. Bu arac Studio yerine public YouTube Data API verisini kullanir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": (
                        "Dogal dilde analiz istegi. Ornek: "
                        "'YouTube istatistiklerim nasil', 'son videolarimi analiz et', "
                        "'kanal buyumemi ozetle'"
                    )
                },
                "handle": {
                    "type": "STRING",
                    "description": (
                        "Opsiyonel kanal handle'i, kanal linki veya kanal ID'si. "
                        "Bos birakilirsa ayarlardaki youtube_channel_handle kullanilir."
                    )
                },
                "video_limit": {
                    "type": "NUMBER",
                    "description": "Analize dahil edilecek son video sayisi. Varsayilan 6."
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "analyze_screen",
        "description": (
            "Aktif pencerenin ekran goruntusunu alip Gemini vision ile analiz eder. "
            "Kullanici ekranda ne oldugunu, bir hatayi, gorunen metni, butonlari veya pencere icerigini sordugunda kullan. "
            "Bu surum yalnizca aktif pencereyi destekler."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "Kullanicinin ekranla ilgili sorusu. Ornek: 'Bu hatayi oku', 'Ekranda ne var?'"
                },
                "target": {
                    "type": "STRING",
                    "description": "Su an sadece active_window desteklenir."
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "smart_home_control",
        "description": (
            "HomeKit aksesuarlari, HomeKit sahneleri, akilli ev cihazlari, akilsiz LG/Samsung TV, "
            "akilli TV, desteklenmeyen cihazlar, Bluetooth/BLE cihazlar, cin cakma marka cihazlar, "
            "IR kumanda koprusu, Wake-on-LAN, HTTP veya macOS Kestirmeler uzerinden cihaz kontrolu yapar. "
            "Koprüsüz direkt modda yalnizca cihazda acik Bluetooth/BLE, Wi-Fi/HTTP, LAN/Wake-on-LAN "
            "veya bilinen yerel protokol varsa kontrol eder; fiziksel/protokol kanali yoksa bunu soyler. "
            "Kamera erisimi kullanmaz. Bluetooth cihazlari tarayabilir; bilinmeyen marka cihazlarda protokol "
            "icin BLE characteristic/hex komutu veya Kestirme koprusu gerekebilir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": (
                        "on | off | power | brightness | color | scene | list | direct_status | direct | wake | open_url | "
                        "bluetooth_scan | bluetooth_info | ble_on | ble_off | volume_up | volume_down | mute | "
                        "channel_up | channel_down veya config'teki eylem"
                    )
                },
                "device_name": {
                    "type": "STRING",
                    "description": "Cihaz adi. Ornek: 'Salon lamba', 'LG akılsız TV', 'Samsung TV', 'Akıllı TV'"
                },
                "room": {
                    "type": "STRING",
                    "description": "Oda adi. Opsiyonel."
                },
                "brightness": {
                    "type": "NUMBER",
                    "description": "Parlaklik yuzdesi. 0-100."
                },
                "color": {
                    "type": "STRING",
                    "description": "Renk adi veya HEX degeri. Ornek: 'mavi', '#00aaff'"
                },
                "scene_name": {
                    "type": "STRING",
                    "description": "HomeKit sahne adi. action=scene icin kullan."
                },
                "raw_command": {
                    "type": "STRING",
                    "description": "Desteklenmeyen cihaz adaptoru icin URL, komut veya ek veri."
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "day_assistant",
        "description": (
            "Gün asistanı ve kişisel Mac erişim aracı. Günlük bilgi özeti, Apple Notes, "
            "Apple Contacts/Kişiler, fotoğraflar, dosyalar, konum Kestirmesi, HomeKit/aygıtlar, "
            "Apple Hesabı ayar ekranı ve güvenli PC/Mac kontrol işlemlerini yapar. "
            "macOS izinleri gerektiren yerlerde izin ister; Apple hesabı şifresi veya gizli verileri okunmaz."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": (
                        "daily_briefing | notes | create_note | contacts | photos | search_photos | "
                        "files | search_files | location | devices | apple_account | pc_control | "
                        "pc_info | open_app | open_path | lock | sleep_display | volume | safe_command"
                    )
                },
                "query": {
                    "type": "STRING",
                    "description": "Arama ifadesi, kişi adı, dosya adı, uygulama adı, yol veya PC alt komutu."
                },
                "content": {
                    "type": "STRING",
                    "description": "Not içeriği, güvenli komut veya ek metin."
                },
                "location": {
                    "type": "STRING",
                    "description": "Hava durumu konumu veya PC kontrolünde ek değer."
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "save_memory",
        "description": "Kullanıcı hakkında önemli bilgiyi kalıcı belleğe kaydeder. İsim, tercihler, projeler vb. duyunca sessizce çağır.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {
                    "type": "STRING",
                    "description": "identity | preferences | projects | notes"
                },
                "key":   {"type": "STRING", "description": "Kısa anahtar (örn. 'name')"},
                "value": {"type": "STRING", "description": "Değer (İngilizce)"}
            },
            "required": ["category", "key", "value"]
        }
    },
    {
        "name": "delete_memory",
        "description": (
            "Kalici hafizadaki bir kaydi siler. "
            "Kullanici 'bunu hafizandan kaldir', 'unut', 'sil' gibi bir sey derse kullan. "
            "Mumkunse category ve key ile sil; emin degilsen match_text ile ilgili kaydi bulup kaldir."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {
                    "type": "STRING",
                    "description": "Kaydin kategorisi. Ornek: notes | identity | preferences | projects"
                },
                "key": {
                    "type": "STRING",
                    "description": "Silinecek anahtar. Ornek: claude_limit_refresh"
                },
                "match_text": {
                    "type": "STRING",
                    "description": "Kaydi bulmak icin kullanilacak dogal dil parcasi. Ornek: 'claude ai limit yenilenmesi'"
                }
            }
        }
    },
    {
        "name": "send_whatsapp_message",
        "description": (
            "WhatsApp Desktop veya WhatsApp Web üzerinden mesaj taslağı açar veya mesajı gönderir. "
            "Kişi adı veya telefon numarasıyla çalışabilir. "
            "Telefon numarası verilmemişse kişi adını önce kayıtlı WhatsApp kişileri ve içe aktarılan telefon rehberinde ara. "
            "Kullanıcı 'gönder', 'yolla', 'ile', 'hemen gönder' gibi açık bir gönderme niyeti söylüyorsa "
            "ekstra onay istemeden send_now=true kullan. "
            "Yalnızca 'hazırla', 'taslak aç', 'yaz ama gönderme' diyorsa send_now=false kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "recipient_name": {
                    "type": "STRING",
                    "description": "Kişi adı. Örn: 'Anne', 'Ahmet', 'Ece'"
                },
                "phone_number": {
                    "type": "STRING",
                    "description": "Uluslararası telefon numarası. Örn: +905551112233"
                },
                "message": {
                    "type": "STRING",
                    "description": "Gönderilecek mesaj içeriği"
                },
                "app_target": {
                    "type": "STRING",
                    "description": "desktop | web | auto. Varsayılan auto, tercihen desktop."
                },
                "send_now": {
                    "type": "BOOLEAN",
                    "description": "true ise sohbet açıldıktan sonra mesajı otomatik gönderir"
                }
            },
            "required": ["message"]
        }
    },
    {
        "name": "save_whatsapp_contact",
        "description": (
            "Sık kullanılan bir WhatsApp kişisini adı ve telefon numarasıyla kalıcı belleğe kaydeder. "
            "Kullanıcı bir kişiyi 'annem', 'Ahmet', 'iş ortağım' gibi tekrar kullanılacak şekilde tanımladığında kullan."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "display_name": {
                    "type": "STRING",
                    "description": "Kaydedilecek kişi adı. Örn: 'Annem', 'Ahmet'"
                },
                "phone_number": {
                    "type": "STRING",
                    "description": "Uluslararası telefon numarası. Örn: +905551112233"
                },
                "aliases": {
                    "type": "STRING",
                    "description": "Virgülle ayrılmış alternatif hitaplar. Örn: 'anne, annem, mom'"
                }
            },
            "required": ["display_name", "phone_number"]
        }
    }
]
