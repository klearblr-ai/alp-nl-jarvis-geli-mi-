#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.spending import daily_spending
print(daily_spending("summary"))
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
