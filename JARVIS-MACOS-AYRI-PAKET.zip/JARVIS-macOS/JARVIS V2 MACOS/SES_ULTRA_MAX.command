#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.voice_focus import voice_focus_control
print(voice_focus_control("ultra"))
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
