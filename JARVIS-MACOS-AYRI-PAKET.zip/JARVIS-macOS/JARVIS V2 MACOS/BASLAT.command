#!/bin/bash
# ╔══════════════════════════════════════════════════════════╗
# ║   J.A.R.V.I.S — ÇİFT TIKLA BAŞLAT (macOS)                 ║
# ╚══════════════════════════════════════════════════════════╝

cd "$(dirname "$0")" || exit 1

# Kurulum yapılmış mı?
if [ ! -d "venv" ]; then
    clear
    echo ""
    echo "⚠️  JARVIS henüz kurulmamış."
    echo "   Şimdi kurulumu başlatabilirim."
    echo ""
    read -p "KUR.command çalışsın mı? (e/h): " kur_choice
    if [[ "$kur_choice" == "e" || "$kur_choice" == "E" ]]; then
        if [ -x "./KUR.command" ]; then
            ./KUR.command
        else
            bash ./KUR.command
        fi
    else
        echo ""
        echo "Tamam. Sonra bu klasördeki KUR.command dosyasını açabilirsin."
        read -p "Kapatmak için Enter'a bas..."
        exit 1
    fi
fi

source venv/bin/activate
clear
echo "🚀 JARVIS başlatılıyor..."
python main.py
STATUS=$?

if [ "$STATUS" -ne 0 ]; then
    echo ""
    echo "❌ JARVIS açılırken hata verdi. Kod: $STATUS"
    echo ""
    if [ -f "jarvis_error.log" ]; then
        echo "Son hata kaydı:"
        tail -80 "jarvis_error.log"
        echo ""
    fi
    echo "Bunu bana aynen atarsan direkt nokta atışı düzeltirim."
    read -p "Kapatmak için Enter'a bas..."
    exit "$STATUS"
fi

# ── JARVIS kapandı → bu Terminal penceresini otomatik kapat ──
# python bittiği için pencerede çalışan başka işlem kalmaz; macOS
# "işlem çalışıyor" uyarısı vermeden kendi penceremizi kapatabiliriz.
MY_TTY="$(tty)"
osascript >/dev/null 2>&1 <<OSA || true
tell application "Terminal"
    repeat with w in windows
        repeat with t in tabs of w
            try
                if tty of t is "$MY_TTY" then
                    close w
                end if
            end try
        end repeat
    end repeat
end tell
OSA
