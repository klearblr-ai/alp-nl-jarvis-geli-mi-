#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from app_config import save_app_config
save_app_config({
    "guardian_lock_enabled": True,
    "guardian_auto_camera": True,
    "guardian_local_camera_only": True,
})
print("Güvenli kilit açıldı. JARVIS'i başlatınca kamera yerel olarak yabancı yüz izleyecek.")
print("Kilidi çözmek için: kilidi çıkar <güvenlik kodu>")
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
