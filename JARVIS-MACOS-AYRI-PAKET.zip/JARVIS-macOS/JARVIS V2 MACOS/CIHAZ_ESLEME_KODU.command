#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.device_sync import device_sync
print(device_sync("status"))
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
