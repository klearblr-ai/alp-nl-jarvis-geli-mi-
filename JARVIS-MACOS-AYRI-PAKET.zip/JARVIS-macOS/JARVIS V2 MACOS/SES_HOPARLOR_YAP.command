#!/bin/bash

cd "$(dirname "$0")" || exit 1

if [ -d "venv" ]; then
    source venv/bin/activate
fi

PYTHON_BIN="python"
if ! command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python3"
fi

"$PYTHON_BIN" - <<'PY'
from app_config import save_app_config

save_app_config({
    "audio_output_device": "speaker",
    "audio_output_volume": 85,
})
print("JARVIS ses çıkışı hoparlör tercihli yapıldı.")
print("Mac Sistem Ayarları > Ses > Çıkış kısmında hoparlör seçiliyse JARVIS sesi oradan gelir.")
input("Kapatmak için Enter'a bas...")
PY
