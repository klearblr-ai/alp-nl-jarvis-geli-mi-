#!/usr/bin/env python3
"""
JARVIS macOS — Gercek zamanli sesli yardimci cekirdegi
macOS ortamina uyarlanmis calisma akisi
"""

import asyncio
import datetime
import json
import threading
import traceback
import os
import subprocess
import time
import re
import urllib.parse
from array import array
from pathlib import Path

import pyaudio
import psutil
from google import genai
from google.genai import types

from app_config import get_app_config_value, save_app_config
from ui import JarvisUI
from memory.memory_manager import load_memory, update_memory, delete_memory, format_memory_for_prompt
from actions.open_app import open_app
from actions.sys_info  import sys_info
from actions.calendar import get_calendar_events, add_calendar_event, delete_calendar_event
from actions.reminders import get_reminders, add_reminder, delete_reminder
from actions.browser   import browser_control
from actions.shell     import shell_run
from actions.whatsapp  import send_whatsapp_message, save_whatsapp_contact
from actions.media     import play_media
from actions.weather   import get_weather_summary
from actions.screen_vision import analyze_screen
from actions.youtube_stats import get_youtube_channel_report
from actions.smart_home import smart_home_control
from actions.day_assistant import day_assistant
from actions.apple_integration import apple_integration
from actions.security_scan import security_scan
from actions.spending import daily_spending
from actions.system_mode import system_mode
from actions.app_file_manager import app_file_manager, file_delete
from actions.voice_focus import voice_focus_control
from actions.device_sync import device_sync
from actions.content_filter import check_active_content, close_active_window, content_filter_control
from actions.safe_extras import safe_extra_feature
from actions.chrome_bridge import ChromeBridgeServer, get_or_create_chrome_bridge_token
try:
    from wake_word import WakeWordListener
except Exception:
    WakeWordListener = None

# ── Paths ───────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).resolve().parent
PROMPT_PATH     = BASE_DIR / "core" / "prompt.txt"
TRUSTED_FACES_PATH = BASE_DIR / "config" / "trusted_faces.json"


# ── WebcamStreamer ──────────────────────────────────────────────────────────
class WebcamStreamer:
    """
    Webcam'dan sürekli kare çeker ve en güncel JPEG'i bellekte tutar.
    Queue yerine tek bir 'latest frame' yaklaşımı — eski kare birikimi olmaz.
    """

    JPEG_QUALITY = 72
    MAX_DIM      = 640
    WARMUP       = 6

    def __init__(self):
        self._latest: bytes | None = None
        self._lock   = threading.Lock()
        self._active = False
        self._night_vision = bool(get_app_config_value("webcam_night_vision", False))
        self._thread: threading.Thread | None = None

    @property
    def is_active(self) -> bool:
        return self._active

    def get_latest_frame(self) -> bytes | None:
        """Thread-safe, her zaman en güncel kareyi döner."""
        with self._lock:
            return self._latest

    def start(self) -> str:
        with self._lock:
            if self._active:
                return "already_active"
            self._active = True
            self._latest = None
        t = threading.Thread(target=self._run, daemon=True)
        self._thread = t
        t.start()
        return "ok"

    def stop(self):
        with self._lock:
            self._active = False
            self._latest = None

    def set_night_vision(self, enabled: bool) -> None:
        with self._lock:
            self._night_vision = bool(enabled)

    @staticmethod
    def _apply_night_vision(frame):
        try:
            import cv2
            import numpy as np
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (3, 3), 0)
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
            enhanced = clahe.apply(gray)
            gamma = 0.55
            table = np.array([((i / 255.0) ** gamma) * 255 for i in range(256)]).astype("uint8")
            enhanced = cv2.LUT(enhanced, table)
            green = np.zeros_like(frame)
            green[:, :, 1] = enhanced
            green[:, :, 0] = (enhanced * 0.18).astype("uint8")
            green[:, :, 2] = (enhanced * 0.08).astype("uint8")
            return green
        except Exception:
            return frame

    def _run(self):
        try:
            import cv2
        except ImportError:
            print("[Webcam] opencv-python yüklü değil.")
            with self._lock:
                self._active = False
            return

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("[Webcam] Kamera açılamadı.")
            with self._lock:
                self._active = False
            return

        # Isınma — sensörün otomatik pozlaması oturuncaya kadar bekle
        for _ in range(self.WARMUP):
            cap.read()

        enc_params = [cv2.IMWRITE_JPEG_QUALITY, self.JPEG_QUALITY]

        try:
            while True:
                with self._lock:
                    if not self._active:
                        break

                ret, frame = cap.read()
                if not ret:
                    break

                h, w = frame.shape[:2]
                if max(h, w) > self.MAX_DIM:
                    s = self.MAX_DIM / max(h, w)
                    frame = cv2.resize(frame, (int(w * s), int(h * s)))

                frame = cv2.flip(frame, 1)  # yatay ayna — hem UI hem AI tutarlı
                with self._lock:
                    night_vision = self._night_vision
                if night_vision:
                    frame = self._apply_night_vision(frame)
                ok, buf = cv2.imencode(".jpg", frame, enc_params)
                if ok:
                    with self._lock:
                        self._latest = buf.tobytes()

                # ~33 FPS yakala → 24 FPS UI her zaman taze kare bulur
                time.sleep(0.03)
        finally:
            cap.release()
            with self._lock:
                self._active = False
                self._latest = None
            print("[Webcam] Kamera serbest bırakıldı.")


class TrustedFaceStore:
    """
    Tanidik yuzleri fotograf olarak degil, kucuk sayisal imza olarak saklar.
    Bu profesyonel biyometrik kimlik dogrulama degildir; ev modu alarm filtresidir.
    """

    VECTOR_SIZE = 32

    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()

    def _load(self) -> list[dict]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            faces = raw.get("faces", []) if isinstance(raw, dict) else []
            return [f for f in faces if isinstance(f, dict) and isinstance(f.get("vector"), list)]
        except Exception:
            return []

    def _save(self, faces: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "note": "JARVIS trusted face signatures. No photos are stored here.",
            "faces": faces,
        }
        self.path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        try:
            os.chmod(self.path, 0o600)
        except Exception:
            pass

    @staticmethod
    def _detect_faces(gray):
        try:
            import cv2
            import numpy as np
        except Exception:
            return []

        try:
            min_size = int(get_app_config_value("trusted_face_min_size", 30) or 30)
        except Exception:
            min_size = 30
        min_size = max(24, min(96, min_size))

        cascades = [
            "haarcascade_frontalface_default.xml",
            "haarcascade_frontalface_alt2.xml",
            "haarcascade_frontalface_alt.xml",
            "haarcascade_profileface.xml",
        ]
        variants = [gray]
        try:
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            variants.append(clahe.apply(gray))
        except Exception:
            pass
        try:
            h, w = gray.shape[:2]
            if min(h, w) < 900:
                big = cv2.resize(gray, None, fx=1.6, fy=1.6, interpolation=cv2.INTER_CUBIC)
                variants.append(big)
                try:
                    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
                    variants.append(clahe.apply(big))
                except Exception:
                    pass
            gamma_table = np.array([((i / 255.0) ** 0.65) * 255 for i in range(256)]).astype("uint8")
            variants.append(cv2.LUT(gray, gamma_table))
        except Exception:
            pass
        try:
            h, w = gray.shape[:2]
            center = (w // 2, h // 2)
            for angle in (-8, 8):
                matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
                variants.append(cv2.warpAffine(gray, matrix, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE))
        except Exception:
            pass

        found = []
        base_dir = getattr(cv2.data, "haarcascades", "")
        for variant in variants:
            for cascade_name in cascades:
                detector = cv2.CascadeClassifier(base_dir + cascade_name)
                if detector.empty():
                    continue
                for scale, neighbors in ((1.03, 2), (1.05, 3), (1.08, 4), (1.12, 5)):
                    faces = detector.detectMultiScale(
                        variant,
                        scaleFactor=scale,
                        minNeighbors=neighbors,
                        minSize=(min_size, min_size),
                    )
                    scale_x = gray.shape[1] / max(1, variant.shape[1])
                    scale_y = gray.shape[0] / max(1, variant.shape[0])
                    for x, y, w, h in faces:
                        found.append((
                            int(x * scale_x),
                            int(y * scale_y),
                            int(w * scale_x),
                            int(h * scale_y),
                        ))

        # Ayni yuzu birden fazla cascade bulursa en buyuk/net kutuyu tut.
        unique = []
        for face in sorted(found, key=lambda item: item[2] * item[3], reverse=True):
            x, y, w, h = face
            duplicate = False
            for ux, uy, uw, uh in unique:
                ix1 = max(x, ux)
                iy1 = max(y, uy)
                ix2 = min(x + w, ux + uw)
                iy2 = min(y + h, uy + uh)
                inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
                area = max(1, w * h)
                if inter / area > 0.45:
                    duplicate = True
                    break
            if not duplicate:
                unique.append(face)
        return unique

    @staticmethod
    def _face_quality_from_jpeg(jpeg: bytes) -> tuple[int, float]:
        try:
            import cv2
            import numpy as np
            arr = np.frombuffer(jpeg, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if frame is None:
                return 0, 0.0
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = TrustedFaceStore._detect_faces(gray)
            if not faces:
                return 0, 0.0
            h, w = gray.shape[:2]
            x, y, fw, fh = max(faces, key=lambda item: item[2] * item[3])
            crop = gray[max(0, y):min(h, y + fh), max(0, x):min(w, x + fw)]
            sharpness = float(cv2.Laplacian(crop, cv2.CV_64F).var()) if crop.size else 0.0
            area_score = float(fw * fh) / float(max(1, w * h))
            brightness = float(crop.mean()) if crop.size else 0.0
            light_score = 1.0 - min(1.0, abs(brightness - 120.0) / 120.0)
            return len(faces), (area_score * 1000.0) + (sharpness * 0.04) + light_score
        except Exception:
            return 0, 0.0

    @staticmethod
    def _extract_signature(jpeg: bytes):
        try:
            import cv2
            import numpy as np
        except Exception:
            return None, 0
        try:
            arr = np.frombuffer(jpeg, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if frame is None:
                return None, 0
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = TrustedFaceStore._detect_faces(gray)
            if len(faces) == 0:
                return None, 0
            x, y, w, h = max(faces, key=lambda item: item[2] * item[3])
            pad_x = int(w * 0.12)
            pad_y = int(h * 0.16)
            x1 = max(0, x - pad_x)
            y1 = max(0, y - pad_y)
            x2 = min(gray.shape[1], x + w + pad_x)
            y2 = min(gray.shape[0], y + h + pad_y)
            face = gray[y1:y2, x1:x2]
            face = cv2.equalizeHist(face)
            face = cv2.resize(face, (TrustedFaceStore.VECTOR_SIZE, TrustedFaceStore.VECTOR_SIZE))
            vec = face.astype("float32").reshape(-1)
            vec = (vec - float(vec.mean())) / (float(vec.std()) + 1e-6)
            return vec, len(faces)
        except Exception:
            return None, 0

    @staticmethod
    def _similarity(vec, saved: list[float]) -> float:
        try:
            import numpy as np
            other = np.array(saved, dtype="float32")
            denom = float(np.linalg.norm(vec) * np.linalg.norm(other)) + 1e-6
            return float(np.dot(vec, other) / denom)
        except Exception:
            return 0.0

    def enroll_from_jpeg(self, jpeg: bytes, label: str = "") -> str:
        vec, face_count = self._extract_signature(jpeg)
        if vec is None:
            return "Yüz eklenemedi: kamerada net bir yüz göremedim."
        label = (label or f"tanidik-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}").strip()
        entry = {
            "label": label,
            "created_at": datetime.datetime.now().isoformat(timespec="seconds"),
            "vector": [round(float(x), 6) for x in vec.tolist()],
        }
        with self._lock:
            faces = self._load()
            faces.append(entry)
            self._save(faces)
        extra = " Birden fazla yüz vardı; en büyük/net görünen yüz kaydedildi." if face_count > 1 else ""
        return f"Tanıdık yüz kaydedildi: {label}.{extra} Fotoğraf saklamadım, sadece yerel yüz imzası tuttum."

    def clear(self) -> str:
        with self._lock:
            self._save([])
        return "Kayıtlı tanıdık yüzler temizlendi."

    def list_labels(self) -> str:
        faces = self._load()
        if not faces:
            return "Kayıtlı tanıdık yüz yok."
        labels = ", ".join(str(f.get("label", "isimsiz")) for f in faces)
        return f"Kayıtlı tanıdık yüzler: {labels}"

    def is_trusted_jpeg(self, jpeg: bytes, threshold: float) -> tuple[bool, str]:
        vec, face_count = self._extract_signature(jpeg)
        if vec is None:
            return False, "face_not_found"
        faces = self._load()
        best_label = ""
        best_score = -1.0
        for face in faces:
            score = self._similarity(vec, face.get("vector", []))
            if score > best_score:
                best_score = score
                best_label = str(face.get("label", "tanıdık"))
        if faces and best_score >= threshold:
            return True, f"{best_label} ({best_score:.2f})"
        return False, f"unknown ({best_score:.2f}, faces={face_count})"

    def identify_jpeg(self, jpeg: bytes, threshold: float) -> str:
        trusted, detail = self.is_trusted_jpeg(jpeg, threshold)
        if trusted:
            label = detail.split("(", 1)[0].strip()
            return f"Bu yüz tanıdık: {label}."
        if detail == "face_not_found":
            return "Yüz göremedim."
        return "Bu yüz kayıtlı tanıdık yüzlerde yok; sahibinin adını bilmiyorum."


CONTROL_TOKEN_RE = re.compile(r"<ctrl\d+>", re.IGNORECASE)

# ── Model ───────────────────────────────────────────────────────────────────
LIVE_MODEL = "models/gemini-2.5-flash-native-audio-latest"

# ── Audio ───────────────────────────────────────────────────────────────────
FORMAT           = pyaudio.paInt16
CHANNELS         = 1
SEND_SAMPLE_RATE = 16000
RECV_SAMPLE_RATE = 24000
CHUNK_SIZE       = 1024
pya              = pyaudio.PyAudio()


def _audio_device_name(info: dict) -> str:
    try:
        return str(info.get("name", "") or "")
    except Exception:
        return ""


def _find_output_device_index(preference: str = "") -> int | None:
    wanted = str(preference or "").strip().lower()
    output_devices = []

    try:
        for idx in range(pya.get_device_count()):
            info = pya.get_device_info_by_index(idx)
            if int(info.get("maxOutputChannels", 0) or 0) > 0:
                output_devices.append((idx, _audio_device_name(info), info))
    except Exception:
        return None

    if not output_devices:
        return None

    if wanted and wanted not in {"default", "system", "speaker", "hoparlor", "hoparlör"}:
        for idx, name, _ in output_devices:
            if wanted in name.lower():
                return idx

    if wanted in {"speaker", "hoparlor", "hoparlör", ""}:
        speaker_words = (
            "speaker",
            "speakers",
            "hoparlor",
            "hoparlör",
            "built-in output",
            "macbook",
            "internal",
        )
        avoid_words = ("airpods", "headphone", "headphones", "kulaklık", "kulaklik", "hdmi", "display")
        for idx, name, _ in output_devices:
            lowered = name.lower()
            if any(word in lowered for word in speaker_words) and not any(word in lowered for word in avoid_words):
                return idx

    try:
        default_info = pya.get_default_output_device_info()
        return int(default_info.get("index"))
    except Exception:
        return output_devices[0][0]


def _describe_output_devices() -> str:
    lines = []
    try:
        default_index = int(pya.get_default_output_device_info().get("index"))
    except Exception:
        default_index = -1

    try:
        for idx in range(pya.get_device_count()):
            info = pya.get_device_info_by_index(idx)
            channels = int(info.get("maxOutputChannels", 0) or 0)
            if channels <= 0:
                continue
            mark = " varsayılan" if idx == default_index else ""
            lines.append(f"{idx}: {_audio_device_name(info)} ({channels} kanal){mark}")
    except Exception as exc:
        return f"Ses çıkışları okunamadı: {exc}"
    return "\n".join(lines) if lines else "Ses çıkış cihazı bulunamadı."


def _find_input_device_index(preference: str = "") -> int | None:
    wanted = str(preference or "").strip().lower()
    input_devices = []

    try:
        for idx in range(pya.get_device_count()):
            info = pya.get_device_info_by_index(idx)
            if int(info.get("maxInputChannels", 0) or 0) > 0:
                input_devices.append((idx, _audio_device_name(info), info))
    except Exception:
        return None

    if not input_devices:
        return None

    if wanted:
        for idx, name, _ in input_devices:
            if wanted in name.lower():
                return idx

    try:
        default_info = pya.get_default_input_device_info()
        return int(default_info.get("index"))
    except Exception:
        return input_devices[0][0]


def _describe_input_devices() -> str:
    lines = []
    try:
        default_index = int(pya.get_default_input_device_info().get("index"))
    except Exception:
        default_index = -1

    try:
        for idx in range(pya.get_device_count()):
            info = pya.get_device_info_by_index(idx)
            channels = int(info.get("maxInputChannels", 0) or 0)
            if channels <= 0:
                continue
            mark = " varsayılan" if idx == default_index else ""
            lines.append(f"{idx}: {_audio_device_name(info)} ({channels} kanal){mark}")
    except Exception as exc:
        return f"Mikrofonlar okunamadı: {exc}"
    return "\n".join(lines) if lines else "Mikrofon bulunamadı."


def _set_system_input_volume() -> None:
    try:
        subprocess.run(
            ["osascript", "-e", "set volume input volume 100"],
            capture_output=True,
            text=True,
            timeout=3,
        )
    except Exception:
        pass


def _pcm16_rms(data: bytes) -> int:
    if not data:
        return 0
    try:
        samples = array("h")
        samples.frombytes(data)
        if not samples:
            return 0
        total = sum(int(s) * int(s) for s in samples)
        return int((total / len(samples)) ** 0.5)
    except Exception:
        return 0


def _boost_pcm16(data: bytes, gain: float) -> bytes:
    if not data or gain <= 1.01:
        return data
    try:
        samples = array("h")
        samples.frombytes(data)
        limit = 32767
        for idx, sample in enumerate(samples):
            boosted = int(sample * gain)
            if boosted > limit:
                boosted = limit
            elif boosted < -limit:
                boosted = -limit
            samples[idx] = boosted
        return samples.tobytes()
    except Exception:
        return data


def _set_system_output_volume() -> None:
    try:
        volume = int(get_app_config_value("audio_output_volume", 80) or 80)
        volume = max(0, min(100, volume))
        subprocess.run(
            ["osascript", "-e", f"set volume output volume {volume}"],
            capture_output=True,
            text=True,
            timeout=3,
        )
    except Exception:
        pass

# ── Tool tanımları — paylaşılan modülden ────────────────────────────────────
from tool_defs import TOOL_DECLARATIONS


def get_api_key() -> str:
    return str(get_app_config_value("gemini_api_key", "") or "")


def load_system_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except Exception:
        return (
            "Sen JARVIS'sin — macOS'ta çalışan kişisel AI asistanı. "
            "Türkçe konuş. Kısa ve net yanıtlar ver. "
            "Araçları kullanarak görevleri tamamla, asla taklit etme."
        )


class JarvisLive:
    def __init__(self, ui: JarvisUI):
        self.ui             = ui
        self.session        = None
        self.audio_in_queue = None
        self.out_queue      = None
        self._loop          = None
        self._is_speaking   = False
        self._speaking_lock = threading.Lock()
        self._music_proc    = None
        self._webcam_streamer = WebcamStreamer()
        self._trusted_faces = TrustedFaceStore(TRUSTED_FACES_PATH)
        self._webcam_ai_vision = bool(get_app_config_value("webcam_ai_vision", True))
        self._home_security_enabled = False
        self._home_security_last_alert = 0.0
        self._last_sound_log = 0.0
        self._wake_listener = None
        self._voice_focus_until = 0.0
        self._guardian_locked = False
        self._guardian_wrong_attempts = 0
        self._chrome_bridge = None

        self.ui.on_text_command  = self._on_text_command
        self.ui.on_pause_toggle  = self._on_pause_toggle
        self.ui.on_effects_state_change = self._on_effects_state_change
        self.ui.on_webcam_toggle = self._on_webcam_toggle_ui
        self._paused             = False
        self._start_wake_listener()
        self._start_chrome_bridge()

    def _start_wake_listener(self):
        if WakeWordListener is None:
            return
        try:
            self._wake_listener = WakeWordListener(self._on_wake_word, self.ui)
            self._wake_listener.start()
            self.ui.write_debug("Hey JARVIS arka plan uyandırma aktif.", level="INFO")
        except Exception as exc:
            self.ui.write_debug(f"Hey JARVIS uyandırma başlatılamadı: {exc}", level="WARN")

    def _start_chrome_bridge(self):
        if not bool(get_app_config_value("chrome_bridge_enabled", True)):
            return
        try:
            port = int(get_app_config_value("chrome_bridge_port", 8787) or 8787)
            token = get_or_create_chrome_bridge_token()
            self._chrome_bridge = ChromeBridgeServer(
                port=port,
                token=token,
                status_provider=self._chrome_bridge_status,
                on_content_event=self._on_chrome_content_event,
                on_command=self._on_chrome_bridge_command,
            )
            status = self._chrome_bridge.start()
            if status == "ok":
                self.ui.write_debug(f"Chrome içerik filtresi köprüsü aktif: 127.0.0.1:{port}", level="INFO")
        except Exception as exc:
            self.ui.write_debug(f"Chrome köprüsü başlatılamadı: {exc}", level="WARN")

    def _chrome_bridge_status(self) -> dict:
        return {
            "content_filter_enabled": bool(get_app_config_value("content_filter_enabled", False)),
            "bridge_port": int(get_app_config_value("chrome_bridge_port", 8787) or 8787),
            "shield_on_event": bool(get_app_config_value("chrome_bridge_show_shield", False)),
            "guardian_lock_enabled": bool(get_app_config_value("guardian_lock_enabled", True)),
        }

    def _on_chrome_content_event(self, payload: dict) -> dict:
        category = str(payload.get("category", "risk") or "risk")
        reason = str(payload.get("reason", "") or "").strip()
        title = str(payload.get("title", "") or "").strip()
        url = str(payload.get("url", "") or "").strip()
        details = reason or f"{category} içerik işareti yakalandı."
        self.ui.write_log(f"SYS: Chrome filtresi uyardı: {category} - {title or url or details}")
        should_shield = bool(get_app_config_value("content_filter_enabled", False)) or bool(
            get_app_config_value("chrome_bridge_show_shield", False)
        )
        if should_shield:
            self.ui.show_content_shield(
                "JARVIS CHROME FİLTRE\n"
                f"{details}\n"
                f"{title or url or 'Chrome sayfası'}"
            )
        return {"ok": True, "message": "JARVIS Chrome uyarısını aldı."}

    def _on_chrome_bridge_command(self, payload: dict) -> dict:
        action = str(payload.get("action", "status") or "status").strip().lower()
        if action in {"status", "durum"}:
            return {"ok": True, **self._chrome_bridge_status()}
        if action in {"content_filter_on", "filter_on", "on", "ac", "aç"}:
            message = content_filter_control("on")
            return {"ok": True, "message": message}
        if action in {"content_filter_off", "filter_off", "off", "kapat"}:
            message = content_filter_control("off")
            self.ui.hide_content_shield()
            return {"ok": True, "message": message}
        if action == "show_shield":
            reason = str(payload.get("reason", "Chrome içeriği gizlendi.") or "Chrome içeriği gizlendi.")
            self.ui.show_content_shield(reason)
            return {"ok": True, "message": "Kalkan açıldı."}
        if action == "hide_shield":
            self.ui.hide_content_shield()
            return {"ok": True, "message": "Kalkan kapatıldı."}
        if action == "bring_front":
            self._bring_jarvis_front()
            return {"ok": True, "message": "JARVIS öne getirildi."}
        if action == "open_app":
            app_name = str(payload.get("app_name", "") or "").strip()
            return {"ok": True, "message": open_app(app_name)}
        if action == "lock_screen":
            threading.Thread(target=self._lock_macos_screen, daemon=True).start()
            return {"ok": True, "message": "macOS kilit ekranına geçiliyor."}
        return {"ok": False, "error": "Bu Chrome köprü komutu desteklenmiyor."}

    def _bring_jarvis_front(self):
        try:
            self.ui.bring_to_front()
        except Exception:
            pass

    def _on_wake_word(self, text: str = ""):
        try:
            hold = float(get_app_config_value("voice_focus_hold_seconds", 14) or 14)
        except Exception:
            hold = 14.0
        self._voice_focus_until = time.time() + max(5.0, min(60.0, hold))
        self._bring_jarvis_front()
        try:
            self.ui.resume_from_wake()
        except Exception:
            pass
        self._paused = False
        command = (text or "").strip()
        if command:
            # Live session yeniden baglanana kadar kisa bir gecikme ver.
            def delayed_send():
                deadline = time.time() + 8.0
                while (not self.session or not self._loop) and time.time() < deadline:
                    time.sleep(0.3)
                self._on_text_command(command)
            threading.Thread(target=delayed_send, daemon=True).start()

    def _on_pause_toggle(self, paused: bool):
        self._paused = paused
        if paused:
            self._stop_music()

    def _on_effects_state_change(self, enabled: bool):
        if not enabled:
            self._stop_music()

    def _on_webcam_toggle_ui(self, activate: bool):
        if activate:
            status = self._webcam_streamer.start()
            self.ui.set_webcam_active(status == "ok" or status == "already_active")
            if status == "ok":
                self.ui.write_log("SYS: Kamera açıldı. Kayıt yapılmıyor.")
        else:
            self._webcam_streamer.stop()
            self.ui.set_webcam_active(False)
            self._home_security_enabled = False
            self.ui.write_log("SYS: Kamera kapandı ve gizlilik modu aktif.")

    def _send_emergency_sms(self, text: str) -> str:
        phone = str(get_app_config_value("home_security_phone", "") or get_app_config_value("owner_phone", "") or "")
        if not phone:
            return "Acil SMS numarası ayarlı değil. İlk girişte kendi telefon numaranı yazarsan uyarı oraya gider."
        compact_phone = "".join(ch for ch in phone if ch.isdigit() or ch == "+")
        if compact_phone.startswith("0") and len(compact_phone) == 11:
            compact_phone = "+90" + compact_phone[1:]
        elif compact_phone.startswith("5") and len(compact_phone) == 10:
            compact_phone = "+90" + compact_phone

        script = f'''
tell application "Messages"
    set targetAddress to "{compact_phone}"
    set targetMessage to "{text}"
    repeat with svc in services
        try
            set targetBuddy to buddy targetAddress of svc
            send targetMessage to targetBuddy
            return "sent"
        end try
    end repeat
end tell
'''
        try:
            result = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                text=True,
                timeout=12,
            )
            if result.returncode == 0 and "sent" in (result.stdout or ""):
                return f"Acil SMS/Mesaj gönderildi: {compact_phone}"
            # Fallback: Mesajlar penceresini hazır açar; otomatik gönderim Mac ayarına bağlıdır.
            body = urllib.parse.quote(text)
            subprocess.run(["open", f"sms:{compact_phone}&body={body}"], capture_output=True, timeout=5)
            return f"Mesaj gönderimi otomatik tamamlanamadı; SMS taslağı açıldı: {compact_phone}"
        except Exception as exc:
            return f"Acil SMS gönderilemedi: {exc}"

    def _trigger_home_security_alert(self, reason: str = "Kamera yüz/hareket algıladı") -> str:
        now = time.time()
        cooldown = 60
        if now - self._home_security_last_alert < cooldown:
            return "Acil uyarı yakın zamanda gönderildi; tekrar bekletiliyor."
        self._home_security_last_alert = now
        message = f"ACİL DURUM: JARVIS ev kamerası uyarısı. {reason}. Saat: {datetime.datetime.now().strftime('%H:%M:%S')}"
        try:
            subprocess.Popen(["say", "Acil durum. Acil durum. Eve yabancı girişi algılandı."])
        except Exception:
            pass
        self.ui.write_log("ACİL DURUM: Kamera yüz/hareket algıladı.")
        if bool(get_app_config_value("home_security_sms_enabled", True)):
            sms_result = self._send_emergency_sms(message)
            self.ui.write_log("SYS: " + sms_result)
            return sms_result
        return "Acil durum algılandı; SMS ayarı kapalı."

    @staticmethod
    def _lock_macos_screen() -> None:
        commands = [
            ["/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession", "-suspend"],
            ["pmset", "displaysleepnow"],
        ]
        for command in commands:
            try:
                subprocess.run(command, capture_output=True, timeout=5)
                return
            except Exception:
                continue

    def _activate_guardian_lock(self, reason: str = "Tanıdık olmayan yüz algılandı") -> str:
        if self._guardian_locked:
            return "Güvenli kilit zaten aktif."
        self._guardian_locked = True
        self._guardian_wrong_attempts = 0
        self._paused = True
        self.ui.show_content_shield(
            "JARVIS GÜVENLİ KİLİT\n"
            f"{reason}\n"
            "Açmak için: 'kilidi çıkar <güvenlik kodu>'"
        )
        self.ui.write_log("SYS: Güvenli kilit açıldı. " + reason)
        try:
            subprocess.Popen(["say", "Güvenli kilit açıldı. Tanıdık olmayan yüz algılandı."])
        except Exception:
            pass
        if bool(get_app_config_value("guardian_lock_screen_on_intruder", True)):
            threading.Thread(target=self._lock_macos_screen, daemon=True).start()
        return "Güvenli kilit açıldı."

    def _guardian_wrong_code(self) -> str:
        self._guardian_wrong_attempts += 1
        try:
            max_attempts = int(get_app_config_value("guardian_max_wrong_attempts", 3) or 3)
        except Exception:
            max_attempts = 3
        if self._guardian_wrong_attempts >= max_attempts and bool(get_app_config_value("guardian_wrong_code_lock_screen", True)):
            threading.Thread(target=self._lock_macos_screen, daemon=True).start()
            return "Kod yanlış. Güvenlik için macOS kilit ekranına geçiyorum."
        return f"Kod yanlış. Güvenli kilit açık kalıyor. Deneme: {self._guardian_wrong_attempts}/{max_attempts}."

    def _unlock_guardian(self, code: str) -> str:
        expected = str(get_app_config_value("security_unlock_code", "") or "").strip()
        if not expected:
            return "Güvenlik kodu ayarlı değil. API ayarlarından güvenlik kodu belirle."
        if str(code or "").strip() == expected:
            self._guardian_locked = False
            self._guardian_wrong_attempts = 0
            self._paused = False
            self.ui.hide_content_shield()
            self.ui.write_log("SYS: Güvenli kilit çözüldü.")
            return "Güvenli kilit çözüldü."
        return self._guardian_wrong_code()

    def _try_guardian_unlock_from_text(self, text: str) -> bool:
        lowered = str(text or "").lower()
        if not any(token in lowered for token in ("kilidi çıkar", "kilidi cikar", "kilit çıkar", "kilit cikar", "kilidi aç", "kilidi ac")):
            return False
        expected = str(get_app_config_value("security_unlock_code", "") or "").strip()
        supplied = re.sub(r"[^0-9A-Za-z]", "", text)
        expected_clean = re.sub(r"[^0-9A-Za-z]", "", expected)
        if expected_clean and expected_clean in supplied:
            self._unlock_guardian(expected)
        else:
            result = self._guardian_wrong_code()
            self.ui.write_log("SYS: " + result)
        return True

    def _enroll_trusted_face(self, label: str = "") -> str:
        status = self._webcam_streamer.start()
        self.ui.set_webcam_active(status == "ok" or status == "already_active")
        try:
            enroll_seconds = float(get_app_config_value("face_enroll_seconds", 10) or 10)
        except Exception:
            enroll_seconds = 10.0
        enroll_seconds = max(5.0, min(20.0, enroll_seconds))
        deadline = time.time() + 4.0
        jpeg = self._webcam_streamer.get_latest_frame()
        while jpeg is None and time.time() < deadline:
            time.sleep(0.2)
            jpeg = self._webcam_streamer.get_latest_frame()
        if jpeg is None:
            return "Yüz eklenemedi: kamera karesi alamadım. Kamera iznini kontrol et."
        best_jpeg = jpeg
        best_faces = 0
        best_quality = 0.0
        deadline = time.time() + enroll_seconds
        while time.time() < deadline:
            current = self._webcam_streamer.get_latest_frame()
            if current:
                face_count, quality = self._trusted_faces._face_quality_from_jpeg(current)
                if face_count > best_faces or (face_count == best_faces and quality > best_quality):
                    best_jpeg = current
                    best_faces = face_count
                    best_quality = quality
            time.sleep(0.25)
        if best_faces <= 0:
            return (
                "Yüz eklenemedi: net yüz yakalayamadım. "
                "Gece görüşü de, yüzünü kameraya yaklaştır, ışığı yüzüne al ve tekrar 'yüz ekle' de."
            )
        result = self._trusted_faces.enroll_from_jpeg(best_jpeg, label)
        self.ui.write_log("SYS: " + result)
        return result

    def _test_face_detection(self) -> str:
        status = self._webcam_streamer.start()
        self.ui.set_webcam_active(status == "ok" or status == "already_active")
        deadline = time.time() + 8.0
        best_faces = 0
        best_quality = 0.0
        while time.time() < deadline:
            jpeg = self._webcam_streamer.get_latest_frame()
            if jpeg:
                face_count, quality = self._trusted_faces._face_quality_from_jpeg(jpeg)
                if face_count > best_faces or quality > best_quality:
                    best_faces = max(best_faces, face_count)
                    best_quality = max(best_quality, quality)
            time.sleep(0.25)
        if best_faces > 0:
            return f"Yüz algılama çalışıyor: {best_faces} yüz gördüm. Netlik puanı: {best_quality:.1f}."
        return "Yüz göremedim. 'Gece görüşü' de, yüzünü kameraya yaklaştır, kameraya düz bak ve tekrar 'yüz test' de."

    def _set_night_vision(self, enabled: bool) -> str:
        self._webcam_streamer.set_night_vision(enabled)
        state = "açıldı" if enabled else "kapatıldı"
        self.ui.write_log(f"SYS: Gece görüşü {state}.")
        return f"Gece görüşü {state}. Bu mod sadece görüntüyü yazılımsal aydınlatır; kayıt yapmaz."

    def _import_to_photos(self, path: Path) -> str:
        try:
            subprocess.run(["open", "-a", "Photos", str(path)], capture_output=True, timeout=8)
            return " Photos uygulamasına aktarmayı denedim."
        except Exception as exc:
            return f" Photos aktarımı denenemedi: {exc}"

    def _capture_photo(self) -> str:
        status = self._webcam_streamer.start()
        self.ui.set_webcam_active(status == "ok" or status == "already_active")
        deadline = time.time() + 4.0
        jpeg = self._webcam_streamer.get_latest_frame()
        while jpeg is None and time.time() < deadline:
            time.sleep(0.2)
            jpeg = self._webcam_streamer.get_latest_frame()
        if jpeg is None:
            return "Fotoğraf çekemedim: kamera karesi alamadım."
        folder = Path.home() / "Pictures" / "JARVIS"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"jarvis-foto-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.jpg"
        path.write_bytes(jpeg)
        return f"Fotoğraf kaydedildi: {path}." + self._import_to_photos(path)

    def _capture_face_frame(self) -> str:
        try:
            import cv2
            import numpy as np
        except Exception:
            return "Yüz karesi için opencv-python gerekiyor."
        status = self._webcam_streamer.start()
        self.ui.set_webcam_active(status == "ok" or status == "already_active")
        deadline = time.time() + 5.0
        best_jpeg = None
        best_quality = 0.0
        while time.time() < deadline:
            jpeg = self._webcam_streamer.get_latest_frame()
            if jpeg:
                count, quality = self._trusted_faces._face_quality_from_jpeg(jpeg)
                if count > 0 and quality > best_quality:
                    best_jpeg = jpeg
                    best_quality = quality
            time.sleep(0.2)
        if not best_jpeg:
            return "Yüz karesi alamadım: net yüz göremedim."
        arr = np.frombuffer(best_jpeg, dtype=np.uint8)
        frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = TrustedFaceStore._detect_faces(gray)
        if not faces:
            return "Yüz karesi alamadım: yüz kutusu bulunamadı."
        h, w = gray.shape[:2]
        x, y, fw, fh = max(faces, key=lambda item: item[2] * item[3])
        pad = int(max(fw, fh) * 0.35)
        x1, y1 = max(0, x - pad), max(0, y - pad)
        x2, y2 = min(w, x + fw + pad), min(h, y + fh + pad)
        crop = frame[y1:y2, x1:x2]
        folder = Path.home() / "Pictures" / "JARVIS"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"jarvis-yuz-karesi-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.jpg"
        cv2.imwrite(str(path), crop)
        return f"Yüz karesi kaydedildi: {path}." + self._import_to_photos(path)

    def _capture_video_frame(self) -> str:
        status = self._webcam_streamer.start()
        self.ui.set_webcam_active(status == "ok" or status == "already_active")
        deadline = time.time() + 4.0
        jpeg = self._webcam_streamer.get_latest_frame()
        while jpeg is None and time.time() < deadline:
            time.sleep(0.2)
            jpeg = self._webcam_streamer.get_latest_frame()
        if jpeg is None:
            return "Video karesi alamadım: kamera karesi yok."
        folder = Path.home() / "Pictures" / "JARVIS"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"jarvis-video-karesi-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.jpg"
        path.write_bytes(jpeg)
        return f"Video karesi kaydedildi: {path}." + self._import_to_photos(path)

    def _identify_current_face(self) -> str:
        status = self._webcam_streamer.start()
        self.ui.set_webcam_active(status == "ok" or status == "already_active")
        deadline = time.time() + 5.0
        best_jpeg = None
        best_quality = 0.0
        while time.time() < deadline:
            jpeg = self._webcam_streamer.get_latest_frame()
            if jpeg:
                count, quality = self._trusted_faces._face_quality_from_jpeg(jpeg)
                if count > 0 and quality > best_quality:
                    best_jpeg = jpeg
                    best_quality = quality
            time.sleep(0.2)
        if not best_jpeg:
            return "Yüz göremedim."
        try:
            threshold = float(get_app_config_value("trusted_face_match_threshold", 0.68) or 0.68)
        except Exception:
            threshold = 0.68
        return self._trusted_faces.identify_jpeg(best_jpeg, threshold)

    def _record_video(self, seconds: int = 10) -> str:
        try:
            import cv2
            import numpy as np
        except Exception:
            return "Video kaydı için opencv-python gerekiyor."
        seconds = max(2, min(60, int(seconds or 10)))
        status = self._webcam_streamer.start()
        self.ui.set_webcam_active(status == "ok" or status == "already_active")
        folder = Path.home() / "Movies" / "JARVIS"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"jarvis-kayit-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.mp4"

        first_frame = None
        deadline = time.time() + 4.0
        while first_frame is None and time.time() < deadline:
            jpeg = self._webcam_streamer.get_latest_frame()
            if jpeg:
                arr = np.frombuffer(jpeg, dtype=np.uint8)
                first_frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            time.sleep(0.1)
        if first_frame is None:
            return "Video kaydı başlatılamadı: kamera karesi alamadım."

        h, w = first_frame.shape[:2]
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(path), fourcc, 12.0, (w, h))
        started = time.time()
        frames = 0
        try:
            while time.time() - started < seconds:
                jpeg = self._webcam_streamer.get_latest_frame()
                if jpeg:
                    arr = np.frombuffer(jpeg, dtype=np.uint8)
                    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                    if frame is not None:
                        if frame.shape[1] != w or frame.shape[0] != h:
                            frame = cv2.resize(frame, (w, h))
                        writer.write(frame)
                        frames += 1
                time.sleep(1 / 12)
        finally:
            writer.release()
        if frames <= 0:
            return "Video kaydı alınamadı."
        return f"{seconds} saniyelik video kaydedildi: {path}." + self._import_to_photos(path)

    def _security_face_allowed(self, jpeg: bytes) -> bool:
        if not bool(get_app_config_value("trusted_faces_enabled", True)):
            return False
        try:
            threshold = float(get_app_config_value("trusted_face_match_threshold", 0.74) or 0.74)
        except Exception:
            threshold = 0.74
        trusted, detail = self._trusted_faces.is_trusted_jpeg(jpeg, threshold)
        if trusted:
            self.ui.write_log(f"SYS: Tanıdık yüz algılandı; alarm verilmedi: {detail}")
            return True
        if detail != "face_not_found":
            self.ui.write_log(f"SYS: Tanınmayan yüz: {detail}")
        return False

    @staticmethod
    def _jpeg_has_face(jpeg: bytes) -> bool:
        try:
            import cv2
            import numpy as np
        except Exception:
            return False
        try:
            arr = np.frombuffer(jpeg, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if frame is None:
                return False
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = TrustedFaceStore._detect_faces(gray)
            return len(faces) > 0
        except Exception:
            return False

    def _focus_ui_section_for_tool(self, tool_name: str, args: dict):
        if tool_name == "sys_info":
            query = str(args.get("query", "")).strip().lower()
            if query in {"time", "saat", "zaman", "date", "tarih"}:
                self.ui.focus_panel("time", duration_ms=5200)
            else:
                self.ui.focus_panel("system", duration_ms=5200)
        elif tool_name == "get_weather":
            self.ui.focus_panel("weather", duration_ms=5600)

    def _on_text_command(self, text: str):
        if self._guardian_locked:
            if self._try_guardian_unlock_from_text(text):
                return
            self.ui.write_log("SYS: Güvenli kilit aktif. 'Kilidi çıkar <kod>' demen gerekiyor.")
            return
        if self._paused:
            return
        self.ui.write_log(f"Siz: {text}")
        if not self._loop or not self.session:
            self.ui.write_log("ERR: JARVIS bağlantısı henüz hazır değil.")
            return
        asyncio.run_coroutine_threadsafe(
            self.session.send_client_content(
                turns={"parts": [{"text": text}]},
                turn_complete=True
            ),
            self._loop
        )

    async def _interrupt_audio(self):
        try:
            if self.audio_in_queue:
                while not self.audio_in_queue.empty():
                    try:
                        self.audio_in_queue.get_nowait()
                    except Exception:
                        break
            if self.session:
                await self.session.send_realtime_input(audio_stream_end=True)
            self.set_speaking(False)
        except Exception:
            pass

    def _stop_music(self):
        proc = self._music_proc
        if proc and proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
        self._music_proc = None

    def set_speaking(self, value: bool):
        with self._speaking_lock:
            self._is_speaking = value
        if value:
            self.ui.set_state("SPEAKING")
        else:
            self.ui.set_state("LISTENING")

    def speak_error(self, tool_name: str, error: str):
        short = str(error)[:120]
        self.ui.write_log(f"ERR: {tool_name} — {short}")
        self.ui.write_debug(f"{tool_name}: {short}", level="ERROR")
        self.ui.set_state("ERROR")

    @staticmethod
    def _result_looks_like_error(result) -> bool:
        text = str(result or "").strip().lower()
        if not text:
            return False
        error_markers = (
            "hata",
            "error",
            "alinamadi",
            "alınamadı",
            "bulunamadi",
            "bulunamadı",
            "acilamadi",
            "açılamadı",
            "tamamlanamadi",
            "tamamlanamadı",
            "gecersiz",
            "geçersiz",
            "izin gerekiyor",
            "izin gerekli",
            "baglanti",
            "bağlantı",
            "gerekli.",
        )
        return any(marker in text for marker in error_markers)

    @staticmethod
    def _should_play_success_sfx(tool_name: str, args: dict, result) -> bool:
        action_tools = {
            "open_app",
            "add_calendar_event",
            "add_reminder",
            "delete_calendar_event",
            "remove_calendar_event",
        }
        if tool_name in action_tools:
            return True

        if tool_name == "send_whatsapp_message":
            text = str(result or "").lower()
            if bool(args.get("send_now", False)):
                return "gönderildi" in text or "gonderildi" in text
            return False

        return False

    @staticmethod
    def _clean_transcript_text(text: str) -> tuple[str, bool]:
        raw = str(text or "")
        had_noise = False
        if CONTROL_TOKEN_RE.search(raw):
            had_noise = True
            raw = CONTROL_TOKEN_RE.sub(" ", raw)
        cleaned = []
        for ch in raw:
            if ch in "\n\r\t" or ord(ch) >= 32:
                cleaned.append(ch)
            else:
                had_noise = True
        normalized = " ".join("".join(cleaned).split())
        return normalized.strip(), had_noise

    def _build_config(self) -> types.LiveConnectConfig:
        import datetime
        memory  = load_memory()
        mem_str = format_memory_for_prompt(memory)
        sys_p   = load_system_prompt()
        now     = datetime.datetime.now()
        time_ctx = f"[ŞU ANKİ ZAMAN]\n{now.strftime('%A, %d %B %Y — %H:%M')}\n\n"

        parts = [time_ctx]
        if mem_str:
            parts.append(mem_str + "\n\n")
        parts.append(sys_p)

        return types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            output_audio_transcription={},
            input_audio_transcription={},
            system_instruction="\n".join(parts),
            tools=[{"function_declarations": TOOL_DECLARATIONS}],
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(
                        voice_name=str(get_app_config_value("voice", "Charon") or "Charon")
                    )
                )
            ),
        )

    async def _execute_tool(self, fc) -> types.FunctionResponse:
        name = fc.name
        args = dict(fc.args or {})
        print(f"[JARVIS] 🔧 {name} {args}")
        self.ui.set_state("THINKING")

        loop   = asyncio.get_event_loop()
        result = "Tamam."
        had_exception = False

        try:
            if name == "save_memory":
                cat = args.get("category", "notes")
                key = args.get("key", "")
                val = args.get("value", "")
                if key and val:
                    update_memory({cat: {key: {"value": val}}})
                    print(f"[Memory] 💾 {cat}/{key} = {val}")
                result = "ok"

            elif name == "delete_memory":
                result = delete_memory(
                    args.get("category", ""),
                    args.get("key", ""),
                    args.get("match_text", ""),
                )

            elif name == "open_app":
                r = await loop.run_in_executor(
                    None, lambda: open_app(args.get("app_name", "")))
                result = r or f"{args.get('app_name')} açıldı."

            elif name == "sys_info":
                self._focus_ui_section_for_tool(name, args)
                r = await loop.run_in_executor(
                    None, lambda: sys_info(args.get("query", "all")))
                result = r or "Bilgi alındı."

            elif name == "get_weather":
                self._focus_ui_section_for_tool(name, args)
                r = await loop.run_in_executor(
                    None, lambda: get_weather_summary(args.get("location") or None))
                result = r or "Hava durumu bilgisi alindi."

            elif name == "get_calendar_events":
                r = await loop.run_in_executor(
                    None,
                    lambda: get_calendar_events(
                        args.get("query", "today"),
                        int(args.get("limit", 6) or 6),
                    ),
                )
                result = r or "Takvim bilgisi alindi."

            elif name == "add_calendar_event":
                r = await loop.run_in_executor(
                    None,
                    lambda: add_calendar_event(
                        args.get("title", ""),
                        args.get("start_iso", ""),
                        args.get("end_iso", ""),
                        args.get("notes", ""),
                        args.get("location", ""),
                        args.get("calendar_name", ""),
                        bool(args.get("all_day", False)),
                    ),
                )
                result = r or "Takvim etkinligi eklendi."

            elif name == "delete_calendar_event":
                r = await loop.run_in_executor(
                    None,
                    lambda: delete_calendar_event(
                        args.get("title", ""),
                        args.get("start_iso", ""),
                        args.get("calendar_name", ""),
                        bool(args.get("delete_all_matches", False)),
                    ),
                )
                result = r or "Takvim etkinligi silindi."

            elif name == "get_reminders":
                r = await loop.run_in_executor(
                    None,
                    lambda: get_reminders(
                        args.get("query", "upcoming"),
                        int(args.get("limit", 8) or 8),
                        args.get("list_name", ""),
                    ),
                )
                result = r or "Animsatici bilgisi alindi."

            elif name == "add_reminder":
                r = await loop.run_in_executor(
                    None,
                    lambda: add_reminder(
                        args.get("title", ""),
                        args.get("due_iso", ""),
                        args.get("notes", ""),
                        args.get("list_name", ""),
                        args.get("priority", ""),
                        bool(args.get("all_day", False)),
                    ),
                )
                result = r or "Animsatici eklendi."

            elif name == "delete_reminder":
                r = await loop.run_in_executor(
                    None,
                    lambda: delete_reminder(
                        args.get("title", ""),
                        args.get("list_name", ""),
                        bool(args.get("delete_all_matches", False)),
                        bool(args.get("complete_only", False)),
                    ),
                )
                result = r or "Animsatici silindi."

            elif name == "browser_control":
                r = await loop.run_in_executor(
                    None, lambda: browser_control(
                        args.get("action"),
                        args.get("url"),
                        args.get("query")
                    ))
                result = r or "Tamam."

            elif name == "shell_run":
                r = await loop.run_in_executor(
                    None, lambda: shell_run(args.get("command", "")))
                result = r or "Komut çalıştırıldı."

            elif name == "toggle_webcam":
                action = str(args.get("action", "start")).strip().lower()
                label = str(args.get("label", "") or "").strip()
                if action in {"start", "open", "aç", "ac", "look", "see"}:
                    status = self._webcam_streamer.start()
                    self.ui.set_webcam_active(status == "ok" or status == "already_active")
                    result = "Kamera açıldı. Kayıt yapılmıyor; canlı görüntü sadece oturum içinde kullanılır."
                elif action in {"night_vision_on", "night_on", "gece_gorusu", "gece_görüşü", "gece görüşü", "gece gorusu"}:
                    status = self._webcam_streamer.start()
                    self.ui.set_webcam_active(status == "ok" or status == "already_active")
                    result = self._set_night_vision(True)
                elif action in {"night_vision_off", "night_off", "gece_gorusu_kapat", "gece_görüşü_kapat", "gece görüşü kapat", "gece gorusu kapat"}:
                    result = self._set_night_vision(False)
                elif action in {"capture_photo", "take_photo", "photo", "fotoğraf çek", "fotograf cek", "foto çek", "foto cek"}:
                    result = await loop.run_in_executor(None, self._capture_photo)
                elif action in {"capture_face_frame", "face_frame", "yüz karesi al", "yuz karesi al"}:
                    result = await loop.run_in_executor(None, self._capture_face_frame)
                elif action in {"capture_video_frame", "video_frame", "video karesi al"}:
                    result = await loop.run_in_executor(None, self._capture_video_frame)
                elif action in {"record_video", "video_record", "video kaydı al", "video kaydi al", "kayıt al", "kayit al"}:
                    duration = int(args.get("duration_seconds", 10) or 10)
                    result = await loop.run_in_executor(None, lambda: self._record_video(duration))
                elif action in {"identify_face", "who_face", "kim_bu_yuz", "kim bu yüz", "yüz kim"}:
                    result = await loop.run_in_executor(None, self._identify_current_face)
                elif action in {"enroll_face", "face_add", "yüz ekle", "yuz ekle", "tanidik_yuz_ekle", "tanıdık_yüz_ekle"}:
                    result = await loop.run_in_executor(None, lambda: self._enroll_trusted_face(label))
                elif action in {"test_face", "face_test", "yüz test", "yuz test", "yüz algıla", "yuz algila"}:
                    result = await loop.run_in_executor(None, self._test_face_detection)
                elif action in {"clear_faces", "faces_clear", "yüzleri sil", "yuzleri sil", "tanidik_yuzleri_sil", "tanıdık_yüzleri_sil"}:
                    result = self._trusted_faces.clear()
                elif action in {"list_faces", "faces_list", "yüzleri listele", "yuzleri listele"}:
                    result = self._trusted_faces.list_labels()
                elif action in {"security_on", "intruder_on", "ev_guvenlik", "ev_güvenlik"}:
                    status = self._webcam_streamer.start()
                    self._home_security_enabled = True
                    self.ui.set_webcam_active(status == "ok" or status == "already_active")
                    result = "Ev güvenlik modu açıldı. Yüz algılanırsa acil uyarı ve SMS denenecek."
                elif action in {"security_off", "intruder_off"}:
                    self._home_security_enabled = False
                    result = "Ev güvenlik modu kapatıldı."
                elif action in {"privacy", "gizlilik", "stop", "close", "kapat", "artık bakma", "artik bakma"}:
                    self._home_security_enabled = False
                    self._webcam_streamer.stop()
                    self.ui.set_webcam_active(False)
                    result = "Gizlilik modu açıldı. Kamera kapandı ve son görüntü bellekten temizlendi."
                else:
                    result = "Kamera komutu: start, capture_photo, record_video, night_vision_on/off, stop/privacy, security_on, security_off, enroll_face, test_face, list_faces veya clear_faces kullan."

            elif name == "apple_integration":
                r = await loop.run_in_executor(
                    None,
                    lambda: apple_integration(
                        args.get("action", "open_shortcuts"),
                        args.get("shortcut_name", ""),
                        args.get("input_text", ""),
                    ),
                )
                result = r or "Apple entegrasyonu tamam."

            elif name == "security_scan":
                r = await loop.run_in_executor(
                    None,
                    lambda: security_scan(
                        args.get("action", "scan"),
                        args.get("path", ""),
                        bool(args.get("quarantine", True)),
                        int(args.get("max_files", 800) or 800),
                    ),
                )
                result = r or "Güvenlik taraması tamam."

            elif name == "daily_spending":
                r = await loop.run_in_executor(
                    None,
                    lambda: daily_spending(
                        args.get("action", "summary"),
                        float(args.get("amount", 0) or 0),
                        args.get("category", ""),
                        args.get("note", ""),
                        args.get("date", ""),
                        float(args.get("budget", 0) or 0),
                    ),
                )
                result = r or "Harcama hesabı tamam."

            elif name == "system_mode":
                r = await loop.run_in_executor(None, lambda: system_mode(args.get("action", "low_power_on")))
                result = r or "Sistem modu güncellendi."

            elif name == "app_file_manager":
                r = await loop.run_in_executor(
                    None,
                    lambda: app_file_manager(
                        args.get("action", "app_store_search"),
                        args.get("url", ""),
                        args.get("app_name", ""),
                        bool(args.get("open_after", True)),
                    ),
                )
                result = r or "Uygulama/dosya işlemi tamam."

            elif name == "file_delete":
                r = await loop.run_in_executor(
                    None,
                    lambda: file_delete(
                        args.get("action", "trash"),
                        args.get("path", ""),
                        args.get("confirmation", ""),
                    ),
                )
                result = r or "Dosya işlemi tamam."

            elif name == "voice_focus_control":
                r = await loop.run_in_executor(
                    None,
                    lambda: voice_focus_control(
                        args.get("action", "on"),
                        int(args.get("hold_seconds", 14) or 14),
                        int(args.get("noise_gate", 650) or 650),
                    ),
                )
                result = r or "Ses odak modu güncellendi."

            elif name == "device_sync":
                r = await loop.run_in_executor(
                    None,
                    lambda: device_sync(
                        args.get("action", "status"),
                        args.get("device_name", ""),
                        args.get("device_type", ""),
                        args.get("command", ""),
                    ),
                )
                result = r or "Cihaz senkron işlemi tamam."

            elif name == "content_filter_control":
                r = await loop.run_in_executor(
                    None,
                    lambda: content_filter_control(
                        args.get("action", "on"),
                        args.get("auto_close"),
                    ),
                )
                if str(args.get("action", "")).strip().lower() in {"off", "disable", "kapat", "filtre_kapat"}:
                    self.ui.hide_content_shield()
                result = r or "İçerik filtresi güncellendi."

            elif name == "guardian_lock_control":
                action = str(args.get("action", "status") or "status").strip().lower()
                code = str(args.get("code", "") or "").strip()
                if action in {"enable", "on", "ac", "aç"}:
                    save_app_config({"guardian_lock_enabled": True, "guardian_auto_camera": True})
                    status = self._webcam_streamer.start()
                    self.ui.set_webcam_active(status == "ok" or status == "already_active")
                    result = "Güvenli kilit modu açıldı. Kamera yabancı yüzleri yerel olarak izleyecek."
                elif action in {"disable", "off", "kapat"}:
                    save_app_config({"guardian_lock_enabled": False, "guardian_auto_camera": False})
                    self._guardian_locked = False
                    self.ui.hide_content_shield()
                    result = "Güvenli kilit modu kapatıldı."
                elif action in {"lock", "kilitle"}:
                    result = self._activate_guardian_lock("Manuel güvenli kilit komutu.")
                elif action in {"unlock", "kilidi_cikar", "kilidi çıkar", "kilidi_ac", "kilidi aç"}:
                    result = self._unlock_guardian(code)
                else:
                    result = f"Güvenli kilit: {'kilitli' if self._guardian_locked else 'açık değil'}, mod {'aktif' if bool(get_app_config_value('guardian_lock_enabled', True)) else 'kapalı'}."

            elif name == "safe_extra_feature":
                r = await loop.run_in_executor(
                    None,
                    lambda: safe_extra_feature(
                        args.get("action", "menu"),
                        args.get("query", ""),
                        int(args.get("amount", 0) or 0),
                    ),
                )
                result = r or "Güvenli ekstra tamam."

            elif name == "play_media":
                r = await loop.run_in_executor(
                    None,
                    lambda: play_media(
                        args.get("query", ""),
                        args.get("provider", "auto"),
                        bool(args.get("autoplay", True)),
                    ),
                )
                result = r or "Medya oynatma başlatıldı."

            elif name == "get_youtube_channel_report":
                r = await loop.run_in_executor(
                    None,
                    lambda: get_youtube_channel_report(
                        args.get("query", "overview"),
                        args.get("handle", ""),
                        int(args.get("video_limit", 6) or 6),
                    ),
                )
                result = r or "YouTube kanal raporu alindi."

            elif name == "analyze_screen":
                r = await loop.run_in_executor(
                    None,
                    lambda: analyze_screen(
                        args.get("query", "Ekranda ne var?"),
                        args.get("target", "active_window"),
                    ),
                )
                result = r or "Ekran analizi tamamlandi."

            elif name == "smart_home_control":
                r = await loop.run_in_executor(
                    None,
                    lambda: smart_home_control(
                        args.get("action", ""),
                        args.get("device_name", ""),
                        args.get("room", ""),
                        args.get("brightness"),
                        args.get("color", ""),
                        args.get("scene_name", ""),
                        args.get("raw_command", ""),
                    ),
                )
                result = r or "Cihaz kontrol komutu tamamlandı."

            elif name == "day_assistant":
                r = await loop.run_in_executor(
                    None,
                    lambda: day_assistant(
                        args.get("action", "daily_briefing"),
                        args.get("query", ""),
                        args.get("content", ""),
                        args.get("location", ""),
                    ),
                )
                result = r or "Gün asistanı işlemi tamamlandı."

            elif name == "send_whatsapp_message":
                r = await loop.run_in_executor(
                    None,
                    lambda: send_whatsapp_message(
                        args.get("message", ""),
                        args.get("phone_number", ""),
                        args.get("recipient_name", ""),
                        bool(args.get("send_now", False)),
                        args.get("app_target", "auto"),
                    ),
                )
                result = r or "WhatsApp işlemi tamamlandı."

            elif name == "save_whatsapp_contact":
                r = await loop.run_in_executor(
                    None,
                    lambda: save_whatsapp_contact(
                        args.get("display_name", ""),
                        args.get("phone_number", ""),
                        args.get("aliases", ""),
                    ),
                )
                result = r or "WhatsApp kişisi kaydedildi."

            else:
                result = f"Bilinmeyen araç: {name}"

        except Exception as e:
            result = f"Hata: {e}"
            had_exception = True
            traceback.print_exc()
            self.speak_error(name, e)

        tool_failed = self._result_looks_like_error(result)
        if tool_failed:
            if not had_exception:
                self.ui.set_state("ERROR")
        elif self._should_play_success_sfx(name, args, result):
            self.ui.play_success_sfx()

        if not tool_failed and not self.ui.muted:
            self.ui.set_state("LISTENING")

        print(f"[JARVIS] 📤 {name} → {str(result)[:80]}")
        return types.FunctionResponse(
            id=fc.id, name=name,
            response={"result": result}
        )

    async def _send_realtime(self):
        while True:
            msg = await self.out_queue.get()
            await self.session.send_realtime_input(media=msg)

    async def _stream_webcam_frames(self):
        """
        Webcam aktifken her 1.5s'de EN GÜNCEL kareyi session'a gönderir.
        Queue'suz 'latest frame' yaklaşımı: model hep şimdiki görüntüyü görür.
        """
        _last_sent: bytes | None = None
        while True:
            if not self._webcam_streamer.is_active:
                await asyncio.sleep(0.2)
                continue

            jpeg = self._webcam_streamer.get_latest_frame()
            if jpeg is None or jpeg is _last_sent:
                await asyncio.sleep(0.2)
                continue

            _last_sent = jpeg
            if self._home_security_enabled and self._jpeg_has_face(jpeg) and not self._security_face_allowed(jpeg):
                self._trigger_home_security_alert("Odada yüz algılandı")
            if (
                bool(get_app_config_value("guardian_lock_enabled", True))
                and not self._guardian_locked
                and self._jpeg_has_face(jpeg)
                and not self._security_face_allowed(jpeg)
            ):
                self._activate_guardian_lock("Tanıdık olmayan yüz kamerada göründü.")

            guardian_local_only = (
                bool(get_app_config_value("guardian_lock_enabled", True))
                and bool(get_app_config_value("guardian_auto_camera", True))
                and bool(get_app_config_value("guardian_local_camera_only", True))
            )
            if not self._webcam_ai_vision or guardian_local_only:
                await asyncio.sleep(1.5)
                continue

            try:
                await self.session.send_realtime_input(
                    media={"data": jpeg, "mime_type": "image/jpeg"}
                )
            except Exception as e:
                print(f"[Webcam] Frame gönderilemedi: {e}")

            # 1.5 saniye bekle — model her zaman taze kare alır
            await asyncio.sleep(1.5)

    async def _update_ui_webcam_preview(self):
        """UI önizlemesini ~24 FPS günceller. AI akışından bağımsız."""
        frame_interval = 1.0 / 24.0   # ~0.0417 sn → 24 FPS
        while True:
            if self._webcam_streamer.is_active:
                jpeg = self._webcam_streamer.get_latest_frame()
                if jpeg:
                    self.ui.update_webcam_preview(jpeg)
            await asyncio.sleep(frame_interval)

    async def _content_filter_monitor(self):
        last_block = 0.0
        while True:
            if not bool(get_app_config_value("content_filter_enabled", False)):
                self.ui.hide_content_shield()
                await asyncio.sleep(1.5)
                continue
            try:
                interval = float(get_app_config_value("content_filter_interval_seconds", 5) or 5)
            except Exception:
                interval = 5.0
            interval = max(2.5, min(30.0, interval))
            try:
                result = await asyncio.to_thread(check_active_content)
                if result.get("block"):
                    now = time.time()
                    reason = str(result.get("reason") or "Riskli içerik algılandı.")
                    category = str(result.get("category") or "risk")
                    title = " / ".join(
                        part for part in (
                            str(result.get("owner_name", "") or ""),
                            str(result.get("window_title", "") or ""),
                        ) if part
                    )
                    message = f"Riskli içerik gizlendi: {category}. {reason}"
                    if title:
                        message += f"\nPencere: {title}"
                    self.ui.show_content_shield(message)
                    if now - last_block > 20:
                        last_block = now
                        self.ui.write_log("SYS: " + message.replace("\n", " "))
                        try:
                            subprocess.Popen(["say", "Riskli içerik gizlendi."])
                        except Exception:
                            pass
                    if bool(get_app_config_value("content_filter_auto_close", False)):
                        await asyncio.to_thread(close_active_window)
                else:
                    self.ui.hide_content_shield()
            except Exception as exc:
                self.ui.write_debug(f"İçerik filtresi hatası: {exc}", level="WARN")
            await asyncio.sleep(interval)

    async def _listen_audio(self):
        print("[JARVIS] 🎤 Mikrofon başladı")
        if bool(get_app_config_value("far_field_microphone", True)):
            _set_system_input_volume()

        input_preference = str(get_app_config_value("audio_input_device", "") or "")
        input_device_index = _find_input_device_index(input_preference)
        stream_kwargs = {
            "format": FORMAT,
            "channels": CHANNELS,
            "rate": SEND_SAMPLE_RATE,
            "input": True,
            "frames_per_buffer": CHUNK_SIZE,
        }
        if input_device_index is not None:
            stream_kwargs["input_device_index"] = input_device_index
            try:
                info = pya.get_device_info_by_index(input_device_index)
                print(f"[JARVIS] 🎤 Mikrofon: {_audio_device_name(info)}")
            except Exception:
                pass
        try:
            stream = await asyncio.to_thread(pya.open, **stream_kwargs)
        except Exception:
            stream_kwargs.pop("input_device_index", None)
            print("[JARVIS] 🎤 Seçili mikrofon açılamadı, sistem varsayılan mikrofon deneniyor.")
            stream = await asyncio.to_thread(pya.open, **stream_kwargs)

        try:
            input_gain = float(get_app_config_value("audio_input_gain", 2.2) or 1.0)
        except Exception:
            input_gain = 1.0
        sound_detection = bool(get_app_config_value("sound_detection_enabled", True))
        try:
            sound_threshold = int(get_app_config_value("sound_detection_threshold", 450) or 450)
        except Exception:
            sound_threshold = 450
        try:
            voice_focus_gate = int(get_app_config_value("voice_focus_noise_gate", 650) or 650)
        except Exception:
            voice_focus_gate = 650
        try:
            voice_focus_max_rms = int(get_app_config_value("voice_focus_max_rms", 26000) or 26000)
        except Exception:
            voice_focus_max_rms = 26000
        try:
            while True:
                data = await asyncio.to_thread(
                    stream.read, CHUNK_SIZE, exception_on_overflow=False)
                if bool(get_app_config_value("far_field_microphone", True)):
                    data = _boost_pcm16(data, input_gain)
                level = _pcm16_rms(data)
                if sound_detection:
                    now = time.time()
                    if level >= sound_threshold and now - self._last_sound_log > 8:
                        self._last_sound_log = now
                        self.ui.write_debug(f"Ses algılandı. Mikrofon seviyesi: {level}", level="INFO")
                with self._speaking_lock:
                    jarvis_speaking = self._is_speaking
                voice_focus = bool(get_app_config_value("voice_focus_enabled", False))
                if voice_focus:
                    if bool(get_app_config_value("voice_focus_requires_wake", True)) and time.time() > self._voice_focus_until:
                        await asyncio.sleep(0)
                        continue
                    if level < voice_focus_gate:
                        await asyncio.sleep(0)
                        continue
                    if level > voice_focus_max_rms:
                        self.ui.write_debug("Aşırı yüksek ses kırpıldı; ses odak modu korumada.", level="WARN")
                        await asyncio.sleep(0)
                        continue
                if not jarvis_speaking and not self.ui.muted and not self._paused and not self._guardian_locked:
                    await self.out_queue.put({"data": data, "mime_type": "audio/pcm"})
        except Exception as e:
            print(f"[JARVIS] ❌ Mikrofon: {e}")
            raise
        finally:
            stream.close()

    async def _receive_audio(self):
        print("[JARVIS] 👂 Alım başladı")
        out_buf, in_buf = [], []
        output_noise = False
        output_noise_samples = []
        try:
            while True:
                async for response in self.session.receive():
                    if response.data:
                        self.audio_in_queue.put_nowait(response.data)

                    if response.server_content:
                        sc = response.server_content

                        if sc.output_transcription and sc.output_transcription.text:
                            self.set_speaking(True)
                            raw_txt = sc.output_transcription.text.strip()
                            if raw_txt:
                                txt, had_noise = self._clean_transcript_text(raw_txt)
                                if had_noise:
                                    output_noise = True
                                    if len(output_noise_samples) < 4:
                                        output_noise_samples.append(raw_txt)
                                if txt:
                                    out_buf.append(txt)

                        if sc.input_transcription and sc.input_transcription.text:
                            txt = sc.input_transcription.text.strip()
                            if txt:
                                in_buf.append(txt)
                                self.ui.mark_user_activity(True)

                        if sc.turn_complete:
                            self.set_speaking(False)

                            full_in = " ".join(in_buf).strip()
                            if full_in:
                                self.ui.write_log(f"Siz: {full_in}")
                            in_buf = []

                            full_out = " ".join(out_buf).strip()
                            if full_out:
                                self.ui.write_log(f"JARVIS: {full_out}")
                                if output_noise_samples:
                                    self.ui.write_debug(
                                        "Kısmen filtrelenen ses transcripti: " + " | ".join(output_noise_samples),
                                        level="WARN",
                                    )
                            elif output_noise:
                                self.ui.write_log("ERR: JARVIS sesli yanıtını çözümlerken bir hata oluştu.")
                                if output_noise_samples:
                                    self.ui.write_debug(
                                        "Filtrelenen ham transcript: " + " | ".join(output_noise_samples),
                                        level="WARN",
                                    )
                                self.ui.set_state("ERROR")
                            out_buf = []
                            output_noise = False
                            output_noise_samples = []

                    if response.tool_call:
                        fn_responses = []
                        for fc in response.tool_call.function_calls:
                            print(f"[JARVIS] 📞 {fc.name}")
                            fr = await self._execute_tool(fc)
                            fn_responses.append(fr)
                        await self.session.send_tool_response(
                            function_responses=fn_responses)

        except Exception as e:
            print(f"[JARVIS] ❌ Alım: {e}")
            traceback.print_exc()
            raise

    async def _play_audio(self):
        print("[JARVIS] 🔊 Ses çalma başladı")
        _set_system_output_volume()
        output_preference = str(get_app_config_value("audio_output_device", "speaker") or "speaker")
        output_device_index = _find_output_device_index(output_preference)
        stream_kwargs = {
            "format": FORMAT,
            "channels": CHANNELS,
            "rate": RECV_SAMPLE_RATE,
            "output": True,
        }
        if output_device_index is not None:
            stream_kwargs["output_device_index"] = output_device_index
            try:
                info = pya.get_device_info_by_index(output_device_index)
                print(f"[JARVIS] 🔊 Ses çıkışı: {_audio_device_name(info)}")
            except Exception:
                pass
        try:
            stream = await asyncio.to_thread(pya.open, **stream_kwargs)
        except Exception:
            stream_kwargs.pop("output_device_index", None)
            print("[JARVIS] 🔊 Seçili hoparlör açılamadı, sistem varsayılan çıkış deneniyor.")
            stream = await asyncio.to_thread(pya.open, **stream_kwargs)
        try:
            while True:
                chunk = await self.audio_in_queue.get()
                self.set_speaking(True)
                await asyncio.to_thread(stream.write, chunk)
        except Exception as e:
            print(f"[JARVIS] ❌ Ses: {e}")
            raise
        finally:
            self.set_speaking(False)
            stream.close()

    async def run(self):
        connect_attempts = 0
        while True:
            # Duraklatılmışsa bağlanma, bekle
            if self._paused:
                await asyncio.sleep(1)
                continue

            try:
                # Client'ı her bağlanışta yeniden oluştur ve anahtarı tazeden oku.
                # Böylece yeni girilen API anahtarı anında geçerli olur; ilk
                # deneme başarısız olsa bile otomatik tekrar (3sn) kendini onarır.
                client = genai.Client(
                    api_key=get_api_key(),
                    http_options={"api_version": "v1alpha"}
                )
                print("[JARVIS] 🔌 Bağlanıyor...")
                self.ui.set_state("THINKING")
                config = self._build_config()

                async with (
                    client.aio.live.connect(model=LIVE_MODEL, config=config) as session,
                    asyncio.TaskGroup() as tg,
                ):
                    self.session        = session
                    self._loop          = asyncio.get_event_loop()
                    self.audio_in_queue = asyncio.Queue()
                    self.out_queue      = asyncio.Queue(maxsize=10)

                    print("[JARVIS] ✅ Bağlandı.")
                    connect_attempts = 0          # başarılı bağlantı → sayaç sıfırla
                    self.ui.set_state("LISTENING")
                    self.ui.write_log("SYS: JARVIS hazır. Dinliyorum...")
                    if bool(get_app_config_value("guardian_lock_enabled", True)) and bool(get_app_config_value("guardian_auto_camera", True)):
                        status = self._webcam_streamer.start()
                        self.ui.set_webcam_active(status == "ok" or status == "already_active")
                        if status == "ok":
                            self.ui.write_log("SYS: Güvenli kilit kamera izlemesi aktif.")

                    tg.create_task(self._send_realtime())
                    tg.create_task(self._listen_audio())
                    tg.create_task(self._receive_audio())
                    tg.create_task(self._play_audio())
                    tg.create_task(self._stream_webcam_frames())
                    tg.create_task(self._update_ui_webcam_preview())
                    tg.create_task(self._content_filter_monitor())

            except Exception as e:
                print(f"[JARVIS] ⚠️ {e}")
                traceback.print_exc()
                self.set_speaking(False)
                # Webcam akışını durdur — yeni session'da yeniden başlayacak
                if self._webcam_streamer.is_active:
                    self._webcam_streamer.stop()
                    self.ui.set_webcam_active(False)

                connect_attempts += 1
                # İlk birkaç deneme sessiz: yeni girilen API anahtarı Google
                # tarafında saniyeler içinde aktifleşebilir. Kullanıcıya hemen
                # "hatalı anahtar" göstermeyip kısa aralıkla otomatik tekrar dene.
                if connect_attempts <= 3:
                    self.ui.set_state("INITIALISING")
                    print(f"[JARVIS] 🔄 Bağlanmayı tekrar deniyor ({connect_attempts}/3)...")
                    await asyncio.sleep(2)
                else:
                    self.ui.write_log(
                        f"ERR: JARVIS baglanamiyor — API anahtarini ve internet "
                        f"baglantisini kontrol et. ({e})"
                    )
                    self.ui.set_state("ERROR")
                    print("[JARVIS] 🔄 5 saniyede yeniden bağlanıyor...")
                    await asyncio.sleep(5)


def main():
    if os.environ.get("TERM_PROGRAM") == "vscode":
        print("[JARVIS] VS Code icinden baslatildi.")

    ui = JarvisUI()

    def runner():
        ui.wait_for_api_key()
        jarvis = JarvisLive(ui)
        try:
            asyncio.run(jarvis.run())
        except KeyboardInterrupt:
            print("\n🔴 Kapatılıyor...")

    threading.Thread(target=runner, daemon=True).start()
    ui.root.mainloop()


if __name__ == "__main__":
    main()
