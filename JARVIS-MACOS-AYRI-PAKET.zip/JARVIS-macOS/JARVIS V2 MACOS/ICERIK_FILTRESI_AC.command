#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.content_filter import content_filter_control
print(content_filter_control("on"))
PY
echo
echo "JARVIS'i tekrar baslatinca filtre arka planda calisir."
echo "Kapatmak icin bir tusa bas..."
read -k 1
