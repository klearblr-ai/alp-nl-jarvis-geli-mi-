#!/bin/bash

cd "$(dirname "$0")" || exit 1

if [ -d "venv" ]; then
    source venv/bin/activate
fi

PYTHON_BIN="python"
if ! command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python3"
fi

"$PYTHON_BIN" - <<'PY'
from actions.day_assistant import day_assistant

print("JARVIS Gün Asistanı")
print("")
print(day_assistant("daily_briefing"))
print("")
input("Kapatmak için Enter'a bas...")
PY
