#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from actions.security_scan import security_scan
print(security_scan("clean", "", True, 800))
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
