from __future__ import annotations

import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
CONFIG_DIR = BASE_DIR / "config"
CONFIG_PATH = CONFIG_DIR / "api_keys.json"


DEFAULT_CONFIG = {
    "gemini_api_key": "",
    "voice": "Charon",
    "audio_output_device": "speaker",
    "audio_output_volume": 80,
    "audio_input_device": "",
    "audio_input_gain": 2.2,
    "far_field_microphone": True,
    "sound_detection_enabled": True,
    "sound_detection_threshold": 450,
    "trusted_voice_phrase": "jarvis",
    "voice_focus_enabled": False,
    "voice_focus_requires_wake": True,
    "voice_focus_hold_seconds": 14,
    "voice_focus_noise_gate": 650,
    "voice_focus_max_rms": 26000,
    "device_sync_enabled": True,
    "owner_phone": "",
    "owner_email": "",
    "security_unlock_code": "",
    "guardian_lock_enabled": True,
    "guardian_auto_camera": True,
    "guardian_local_camera_only": True,
    "guardian_lock_screen_on_intruder": True,
    "guardian_wrong_code_lock_screen": True,
    "guardian_max_wrong_attempts": 3,
    "content_filter_enabled": False,
    "content_filter_interval_seconds": 5,
    "content_filter_block_adult": True,
    "content_filter_block_horror": True,
    "content_filter_block_violence": True,
    "content_filter_auto_close": False,
    "chrome_bridge_enabled": True,
    "chrome_bridge_port": 8787,
    "chrome_bridge_token": "",
    "chrome_bridge_show_shield": False,
    "webcam_ai_vision": True,
    "webcam_no_recording": True,
    "webcam_night_vision": False,
    "face_enroll_seconds": 10,
    "trusted_faces_enabled": True,
    "trusted_face_match_threshold": 0.68,
    "trusted_face_min_size": 30,
    "home_security_phone": "",
    "home_security_sms_enabled": True,
    "youtube_api_key": "",
    "youtube_channel_handle": "",
}


def load_app_config() -> dict:
    config = dict(DEFAULT_CONFIG)
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            config.update(raw)
    except Exception:
        pass
    return config


def save_app_config(updates: dict) -> dict:
    config = load_app_config()
    for key, value in (updates or {}).items():
        if value is None:
            continue
        config[key] = value
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(config, indent=4, ensure_ascii=False),
        encoding="utf-8",
    )
    return config


def get_app_config_value(key: str, default=None):
    return load_app_config().get(key, default)


def has_gemini_api_key() -> bool:
    value = str(get_app_config_value("gemini_api_key", "") or "").strip()
    return bool(value)
