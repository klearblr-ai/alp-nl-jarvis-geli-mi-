#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
from actions.safe_extras import safe_extra_feature

folder = Path(__file__).resolve().parent / "chrome_extension"
print(safe_extra_feature("chrome_extension"))
print()
print("Chrome'da chrome://extensions sayfasini ac.")
print("Developer mode'u ac, Load unpacked ile su klasoru sec:")
print(folder)
PY
open "chrome://extensions" >/dev/null 2>&1 || true
open "chrome_extension" >/dev/null 2>&1 || true
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
