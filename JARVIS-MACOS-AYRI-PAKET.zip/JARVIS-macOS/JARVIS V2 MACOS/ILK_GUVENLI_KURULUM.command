#!/bin/zsh
cd "$(dirname "$0")"
python3 - <<'PY'
from getpass import getpass
from app_config import save_app_config

print("JARVIS ilk güvenli kurulum")
print("Neden istiyorum?")
print("- Gemini API key: AI ile konuşmak için gerekir.")
print("- Telefon: sadece acil SMS/Mesaj uyarısı içindir; boş bırakabilirsin.")
print("- E-posta: güvenlik notu/acil kart için yerel tutulur; boş bırakabilirsin.")
print("- Güvenlik kodu: güvenli kilidi açmak için kullanılır.")
print("Bilgiler bu Mac'teki config/api_keys.json dosyasında kalır.")
print("Güvenli, korkma. İstersen zip'i VirusTotal'da tarat: https://www.virustotal.com/gui/home/upload")
print()
api = getpass("Gemini API key: ").strip()
phone = input("Telefon (isteğe bağlı, kendi numaranı yaz): ").strip()
email = input("E-posta: ").strip()
code = getpass("Güvenlik kodu: ").strip()
updates = {
    "owner_phone": phone,
    "owner_email": email,
    "security_unlock_code": code,
    "home_security_phone": phone,
    "guardian_lock_enabled": True,
    "guardian_auto_camera": True,
    "guardian_local_camera_only": True,
}
if api:
    updates["gemini_api_key"] = api
save_app_config(updates)
print("İlk güvenli kurulum kaydedildi. JARVIS açılınca 'yüz ekle' deyip kendi yüzünü tanıt.")
PY
echo
echo "Kapatmak icin bir tusa bas..."
read -k 1
